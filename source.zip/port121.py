import sys, os, re, shutil
root = sys.argv[1]
java = os.path.join(root, "client/java/dev/cherryblossom/client")
# 1.21.9+ shares most of the API with 26.x; these are the renames between them.
REPL = [
    ("GuiGraphicsExtractor", "GuiGraphics"),
    ("compatibilityLevel\": \"JAVA_25\"", "compatibilityLevel\": \"JAVA_21\""),
    ("\"java\": \">=25\"", "\"java\": \">=21\""),
    ("api.client.keymapping.v1.KeyMappingHelper", "api.client.keybinding.v1.KeyBindingHelper"),
    ("KeyMappingHelper.registerKeyMapping", "KeyBindingHelper.registerKeyBinding"),
    ("ScreenEvents.afterExtract(", "ScreenEvents.afterRender("),
    ("vanilla.extractRenderState(g, delta)", "vanilla.render(g, delta)"),
    ("super.extractRenderState(", "super.render("),
    ("extractPanorama(g, delta)", "renderPanorama(g, delta)"),
    ("public void extractRenderState(GuiGraphics", "public void render(GuiGraphics"),
    ("public void extractBackground(GuiGraphics", "public void renderBackground(GuiGraphics"),
    ("\"CameraMixin\"", "\"GameRendererMixin\""),
    ("VanillaHudElements.MOB_EFFECTS", "VanillaHudElements.STATUS_EFFECTS"),
]
RX = [
    (r"\bg\.text\(", "g.drawString("),
    (r"\bg\.centeredText\(", "g.drawCenteredString("),
    (r"\bg\.outline\(", "g.renderOutline("),
    (r"\bg\.item\(", "g.renderItem("),
]
for d, _, files in os.walk(root):
    for f in files:
        p = os.path.join(d, f)
        if not f.endswith((".java", ".json")): continue
        s = open(p).read(); o = s
        for a, b in REPL: s = s.replace(a, b)
        for a, b in RX: s = re.sub(a, b, s)
        if s != o: open(p, "w").write(s)
# 1.21.9 and 1.21.10 still call Identifier "ResourceLocation".
if len(sys.argv) > 2 and sys.argv[2] == "old":
    for d, _, files in os.walk(root):
        for f in files:
            if not f.endswith(".java"): continue
            p = os.path.join(d, f)
            s = open(p).read(); o = s
            s = s.replace("net.minecraft.resources.Identifier", "net.minecraft.resources.ResourceLocation")
            s = re.sub(r"\bIdentifier\b", "ResourceLocation", s)
            s = s.replace(".identifier().getPath()", ".location().getPath()")
            s = s.replace("g.renderOutline(", "g.submitOutline(")
            if s != o: open(p, "w").write(s)
# Version-specific files.
compat = open("/home/claude/cherry/mod/variants/26.1/dev/cherryblossom/client/compat/Compat.java").read().replace("(parent, mc.options, false)", "(parent, mc.options)")
if len(sys.argv) > 2 and sys.argv[2] == "old":
    compat = compat.replace("net.minecraft.resources.Identifier", "net.minecraft.resources.ResourceLocation").replace("public static Identifier", "public static ResourceLocation")
open(os.path.join(java, "compat/Compat.java"), "w").write(compat)
os.remove(os.path.join(java, "mixin/CameraMixin.java"))
open(os.path.join(java, "mixin/GameRendererMixin.java"), "w").write('''package dev.cherryblossom.client.mixin;

import dev.cherryblossom.client.feature.Zoom;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies the zoom to the world field of view (not the hand). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void cherryblossom$zoom(Camera camera, float partialTick, boolean useFovSetting, CallbackInfoReturnable<Float> cir) {
		if (useFovSetting) cir.setReturnValue(Zoom.apply(cir.getReturnValueF()));
	}
}
''')
