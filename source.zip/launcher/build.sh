#!/bin/bash
set -e
cd /home/claude/cherry/launcher
rm -rf out pkg && mkdir -p out pkg/bundled/hud
/opt/jdk25/bin/javac -Xlint:-options -d out --release 25 $(find src -name "*.java") 2>&1 | { grep -v Picked || true; }; [ -f out/dev/cherryblossom/launcher/Main.class ] || { echo BUILD FAILED; exit 1; }
cp -r out/* pkg/ && cp -r res/fonts pkg/ && mkdir -p pkg/bundled/shaders && cp res/shaders/elite.zip pkg/bundled/shaders/
cp /home/claude/cherry/hudjars/*.jar pkg/bundled/hud/
/opt/jdk25/bin/jar cfm cherry-launcher.jar manifest.txt -C pkg . 2>&1 | grep -v Picked || true
ls -la cherry-launcher.jar
