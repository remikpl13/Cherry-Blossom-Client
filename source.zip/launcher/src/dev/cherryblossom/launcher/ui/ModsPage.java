package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.Installer;
import dev.cherryblossom.launcher.core.ModCatalog;
import dev.cherryblossom.launcher.core.Presets;
import dev.cherryblossom.launcher.core.VersionList;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Mods: the Cherry HUD plus a curated set from Modrinth, with what's available for the selected version. */
final class ModsPage extends Controls.Page {
	private static final int PAD = 24;
	private static final int ROW_H = 64;

	private final App app;
	private final Body body;
	private final Controls.ScrollArea scroll;

	ModsPage(App app) {
		this.app = app;
		this.body = new Body();
		this.scroll = new Controls.ScrollArea(body);
		put(scroll);
		app.listen(() -> { body.refresh(); body.repaint(); });
	}

	@Override
	public void doLayout() {
		scroll.setBounds(0, 0, getWidth(), getHeight());
		scroll.doLayout();
	}

	private static String groupTitle(ModCatalog.Group g) {
		return switch (g) {
			case PERFORMANCE -> Lang.t("PERFORMANCE");
			case LOW_END -> Lang.t("EXTRA HELP FOR LOW-END PCS");
			case HIGH_END -> Lang.t("EXTRAS FOR HIGH-END PCS");
			case UTILITY -> Lang.t("UTILITY");
		};
	}

	private final class Body extends Controls.Page {
		private final Controls.Toggle hud;
		private final Controls.Toggle shaders;
		private final List<Controls.Toggle> toggles = new ArrayList<>();
		private final List<ModCatalog.Mod> mods = ModCatalog.ALL;
		private final Controls.GhostButton openFolder;
		private int height = 600;

		Body() {
			hud = new Controls.Toggle("Cherry HUD", Lang.t("FPS, ping, keystrokes, armour, potions, zoom and more. Right Shift in game."),
					app.settings.cherryHud, v -> { app.settings.cherryHud = v; app.settings.save(); app.changed(); });
			put(hud);
			shaders = new Controls.Toggle("E-LITE shaders 5.1.1", Lang.t("Built-in shader pack: shadows, godrays, reflections. Runs on Iris, switch with K in game."),
					app.settings.builtInShaders, v -> { app.settings.builtInShaders = v; app.settings.save(); app.changed(); });
			put(shaders);
			for (ModCatalog.Mod m : mods) {
				Controls.Toggle t = new Controls.Toggle(m.name(), m.about(), app.settings.enabledMods.contains(m.slug()), v -> {
					if (v) app.settings.enabledMods.add(m.slug());
					else app.settings.enabledMods.remove(m.slug());
					app.settings.preset = Presets.Preset.CUSTOM;
					app.settings.save();
					app.changed();
				});
				toggles.add(t);
				put(t);
			}
			openFolder = new Controls.GhostButton(Lang.t("Open mods folder"), this::openFolder).icon(Icons.FOLDER);
			put(openFolder);
		}

		void refresh() {
			for (int i = 0; i < mods.size(); i++) toggles.get(i).setOn(app.settings.enabledMods.contains(mods.get(i).slug()));
			hud.setOn(app.settings.cherryHud);
			shaders.setOn(app.settings.builtInShaders);
		}

		private void openFolder() {
			VersionList.Version v = app.selected();
			if (v == null) return;
			try {
				Path p = app.installer.modsDir(v.id());
				Files.createDirectories(p);
				Desktop.getDesktop().open(p.toFile());
			} catch (Exception e) {
				app.setStatus(Lang.t("Couldn't open the folder: ") + e.getMessage(), true);
			}
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(getWidth(), height);
		}

		private int cardW() { return Math.min(940, getWidth() - PAD * 2); }

		@Override
		public void doLayout() {
			int cw = cardW();
			openFolder.setBounds(PAD + cw - 180, 30, 180, 42);
			int y = 150;
			hud.setBounds(PAD + 22, y + 14, cw - 44 - 140, 40);
			shaders.setBounds(PAD + 22, y + 14 + ROW_H, cw - 44 - 140, 40);
			y += ROW_H * 2 + 30;
			ModCatalog.Group last = null;
			for (int i = 0; i < mods.size(); i++) {
				ModCatalog.Mod m = mods.get(i);
				if (m.group() != last) { y += 38; last = m.group(); }
				toggles.get(i).setBounds(PAD + 22, y + 14, cw - 44 - 140, 40);
				y += ROW_H;
			}
			height = y + 40;
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int cw = cardW();
			VersionList.Version v = app.selected();
			String id = v == null ? "…" : v.id();
			Boolean fab = v == null ? null : app.fabricSupport(id);

			g.setFont(Style.display(30f));
			g.setColor(Style.TEXT);
			g.drawString(Lang.t("Mods"), PAD, 58);
			g.setFont(Style.regular(13f));
			g.setColor(Style.TEXT_DIM);
			g.drawString(Lang.t("For Minecraft ") + id + Lang.t(". Downloaded from Modrinth for the exact version you play,"), PAD, 86);
			g.drawString(Lang.t("with anything they need. Your own .jar mods can go in the mods folder too."), PAD, 106);
			if (fab != null && !fab) {
				g.setColor(Style.DANGER);
				g.drawString(Lang.t("Mods need Fabric, which starts at 1.14. Minecraft ") + id + Lang.t(" runs vanilla."), PAD, 130);
			} else if (!app.settings.useFabric) {
				g.setColor(Style.DANGER);
				g.drawString(Lang.t("You picked Vanilla for this version, so mods are off. Switch to Fabric on the Versions page."), PAD, 130);
			}

			int y = 150;
			Style.card(g, PAD, y, cw, ROW_H * 2 + 4);
			status(g, Installer.hasCherryHud(id) ? 1 : -1, PAD + cw - 22, y + 30,
					Installer.hasCherryHud(id) ? Lang.t("Built in") : Lang.t("1.21.9 to 26.3"));
			g.setColor(new Color(255, 255, 255, 12));
			g.fillRect(PAD + 20, y + ROW_H, cw - 40, 1);
			Boolean iris = v == null || fab == null || !fab ? null : app.modAvailable("iris", id);
			int ss = fab != null && !fab ? -1 : iris == null ? 2 : iris ? 1 : -1;
			status(g, ss, PAD + cw - 22, y + ROW_H + 30, ss == 1 ? Lang.t("Built in") : ss == 2 ? Lang.t("Checking…") : Lang.t("Not for ") + id);
			y += ROW_H * 2 + 30;

			ModCatalog.Group last = null;
			int groupTop = 0;
			List<int[]> cards = new ArrayList<>();
			for (int i = 0; i < mods.size(); i++) {
				ModCatalog.Mod m = mods.get(i);
				if (m.group() != last) {
					if (last != null) cards.add(new int[] {groupTop, y});
					y += 38;
					Style.label(g, groupTitle(m.group()), PAD + 4, y - 12);
					groupTop = y;
					last = m.group();
				}
				y += ROW_H;
			}
			cards.add(new int[] {groupTop, y});
			for (int[] c : cards) Style.card(g, PAD, c[0], cw, c[1] - c[0]);

			// separators and availability
			y = 150 + ROW_H * 2 + 30;
			last = null;
			for (int i = 0; i < mods.size(); i++) {
				ModCatalog.Mod m = mods.get(i);
				if (m.group() != last) { y += 38; last = m.group(); }
				else { g.setColor(new Color(255, 255, 255, 12)); g.fillRect(PAD + 20, y, cw - 40, 1); }
				Boolean avail = v == null || fab == null || !fab ? null : app.modAvailable(m.slug(), id);
				int state = fab != null && !fab ? -1 : avail == null ? 2 : avail ? 1 : -1;
				status(g, state, PAD + cw - 22, y + 30, state == 1 ? Lang.t("For ") + id : state == 2 ? Lang.t("Checking…") : Lang.t("Not for ") + id);
				y += ROW_H;
			}
			g.dispose();
		}

		/** Right-aligned availability note at {@code right}. */
		private void status(Graphics2D g, int state, int right, int y, String text) {
			Color c = state == 1 ? new Color(0xA8E6C1) : state == 2 ? Style.TEXT_MUTED : Style.alpha(Style.TEXT_MUTED, 0.75f);
			g.setFont(Style.medium(11.5f));
			int x = right - g.getFontMetrics().stringWidth(text);
			if (state == 1) Icons.CHECK.paint(g, x - 19, y - 12, 15, c);
			g.setColor(c);
			g.drawString(text, x, y);
		}
	}
}
