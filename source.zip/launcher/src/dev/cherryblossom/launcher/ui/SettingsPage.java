package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.Presets;
import dev.cherryblossom.launcher.core.Settings;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** Settings: performance preset, memory, account, game window and launcher behaviour. */
final class SettingsPage extends Controls.Page {
	private static final int PAD = 24;

	private final App app;
	private final Runnable signIn;
	private final Body body;
	private final Controls.ScrollArea scroll;

	SettingsPage(App app, Runnable signIn) {
		this.app = app;
		this.signIn = signIn;
		this.body = new Body();
		this.scroll = new Controls.ScrollArea(body);
		put(scroll);
		app.listen(body::refresh);
	}

	@Override
	public void doLayout() {
		scroll.setBounds(0, 0, getWidth(), getHeight());
		scroll.doLayout();
	}

	private final class Body extends Controls.Page {
		private final List<PresetCard> presets = new ArrayList<>();
		private final Controls.Slider ram;
		private final Controls.Toggle video, hide, fullscreen;
		private final Controls.Field name = new Controls.Field("", Lang.t("Player name"));
		private final Controls.Link microsoft;
		private final Controls.Link signOut;
		private final Controls.Field width = new Controls.Field("", Lang.t("Width"));
		private final Controls.Field heightField = new Controls.Field("", Lang.t("Height"));
		private final Controls.Field jvm = new Controls.Field("", Lang.t("Extra Java arguments (advanced, optional)"));
		private final Controls.Link dataFolder;
		private final Controls.Segmented language;
		private final Controls.Toggle discord;
		private int height = 1200;
		private int yPerf, yAccount, yWindow, yLauncher, yAbout;

		Body() {
			Settings s = app.settings;
			for (Presets.Preset p : Presets.Preset.values()) {
				PresetCard c = new PresetCard(p);
				presets.add(c);
				put(c);
			}
			ram = put(new Controls.Slider(1024, Settings.maxRamMb(), 512, s.ramMb,
					mb -> String.format("%.1f GB", mb / 1024f), mb -> {
						s.ramMb = mb;
						s.preset = Presets.Preset.CUSTOM;
						s.save();
						app.changed();
					}));
			video = put(new Controls.Toggle(Lang.t("Apply the preset's video settings on next launch"),
					Lang.t("Render distance, graphics quality, particles and clouds, tuned for the preset"), s.applyVideoPreset,
					v -> { s.applyVideoPreset = v; s.save(); }));

			name.setText(s.offlineName);
			name.onChange(() -> { s.offlineName = name.getText().trim(); s.save(); });
			put(name);
			microsoft = put(new Controls.Link(Lang.t("Sign in with Microsoft instead"), () -> signIn.run()));
			signOut = put(new Controls.Link(Lang.t("Sign out"), () -> { s.signOut(); s.save(); app.changed(); }).color(Style.TEXT_DIM));

			width.setText(Integer.toString(s.gameWidth));
			heightField.setText(Integer.toString(s.gameHeight));
			width.onChange(() -> { s.gameWidth = parse(width.getText(), 1280); s.save(); });
			heightField.onChange(() -> { s.gameHeight = parse(heightField.getText(), 720); s.save(); });
			put(width);
			put(heightField);
			fullscreen = put(new Controls.Toggle(Lang.t("Start in fullscreen"), Lang.t("You can always switch with F11 in game"), s.fullscreen,
					v -> { s.fullscreen = v; s.save(); }));

			hide = put(new Controls.Toggle(Lang.t("Hide the launcher while playing"), Lang.t("It comes back when you close the game, so it uses no CPU meanwhile"),
					s.hideWhilePlaying, v -> { s.hideWhilePlaying = v; s.save(); }));
			language = put(new Controls.Segmented(new String[] {"English", "Polski"}, s.language == Lang.Language.PL ? 1 : 0, i -> {
				s.language = i == 1 ? Lang.Language.PL : Lang.Language.EN;
				s.save();
				restartLauncher();
			}));
			discord = put(new Controls.Toggle(Lang.t("Show on Discord"), Lang.t("Your Discord profile shows the client, version, server and play time"),
					s.discordEnabled, v -> { s.discordEnabled = v; s.save(); app.discord.refresh(); }));
			jvm.setText(s.extraJvmArgs);
			jvm.onChange(() -> { s.extraJvmArgs = jvm.getText().trim(); s.save(); });
			put(jvm);
			dataFolder = put(new Controls.Link(Lang.t("Open the client's data folder"), () -> {
				try {
					Files.createDirectories(app.installer.base());
					Desktop.getDesktop().open(app.installer.base().toFile());
				} catch (Exception e) {
					app.setStatus(Lang.t("Couldn't open the folder: ") + e.getMessage(), true);
				}
			}));
			refresh();
		}

		/** Starts a fresh copy of the launcher (same Java, same arguments) so every label is in the new language. */
		private void restartLauncher() {
			try {
				ProcessHandle.Info info = ProcessHandle.current().info();
				java.util.List<String> cmd = new java.util.ArrayList<>();
				cmd.add(info.command().orElseThrow());
				info.arguments().ifPresent(a -> cmd.addAll(java.util.List.of(a)));
				new ProcessBuilder(cmd).inheritIO().start();
				System.exit(0);
			} catch (Exception e) {
				app.setStatus(Lang.t("Restarts the launcher to switch") + ": " + e.getMessage(), true);
			}
		}

		private int parse(String t, int def) {
			try {
				return Math.max(320, Math.min(7680, Integer.parseInt(t.trim())));
			} catch (Exception e) {
				return def;
			}
		}

		void refresh() {
			Settings s = app.settings;
			ram.setValue(s.ramMb);
			video.setOn(s.applyVideoPreset);
			boolean signed = s.signedIn();
			name.setVisible(!signed);
			microsoft.setVisible(!signed);
			signOut.setVisible(signed);
			for (PresetCard c : presets) c.repaint();
			repaint();
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(getWidth(), height);
		}

		private int cw() { return Math.min(940, getWidth() - PAD * 2); }

		@Override
		public void doLayout() {
			int cw = cw();
			int x = PAD + 22, iw = cw - 44;
			int y = 90;
			yPerf = y;
			int n = presets.size(), gap = 12;
			int pw = (iw - gap * (n - 1)) / n;
			for (int i = 0; i < n; i++) presets.get(i).setBounds(x + i * (pw + gap), y + 48, pw, 112);
			y += 48 + 112 + 26;
			ram.setBounds(x, y, Math.min(iw, 560), 58);
			y += 58 + 26;
			video.setBounds(x, y, iw, 40);
			y += 40 + 22;

			y += 24;
			yAccount = y;
			name.setBounds(x, y + 48, Math.min(340, iw), 44);
			microsoft.setBounds(x + Math.min(340, iw) + 18, y + 60, microsoft.preferredWidth(), 20);
			signOut.setBounds(x + iw - 60, y + 60, 60, 20);
			y += 48 + 44 + 24;

			y += 24;
			yWindow = y;
			width.setBounds(x, y + 48, 110, 42);
			heightField.setBounds(x + 140, y + 48, 110, 42);
			fullscreen.setBounds(x + 290, y + 49, Math.max(200, iw - 290), 40);
			y += 48 + 42 + 24;

			y += 24;
			yLauncher = y;
			language.setBounds(x, y + 48, 240, 40);
			y += 62;
			hide.setBounds(x, y + 48, iw, 40);
			discord.setBounds(x, y + 104, iw, 40);
			y += 56;
			jvm.setBounds(x, y + 104, iw, 42);
			dataFolder.setBounds(x, y + 160, dataFolder.preferredWidth(), 20);
			y += 160 + 20 + 24;

			y += 24;
			yAbout = y;
			y += 120;
			height = y + 30;
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int cw = cw();
			g.setFont(Style.display(30f));
			g.setColor(Style.TEXT);
			g.drawString(Lang.t("Settings"), PAD, 58);

			section(g, yPerf, yAccount - 24, Lang.t("Performance"), Lang.t("This PC: ") + Math.round(Settings.systemMemoryMb() / 1024f)
					+ " GB RAM  ·  " + Lang.count(Presets.cpuThreads(), "CPU thread", "CPU threads", "wątek", "wątki", "wątków") + "  ·  " + Lang.t("we suggest") + " " + Presets.recommend().label, cw);
			section(g, yAccount, yWindow - 24, Lang.t("Account"), app.settings.signedIn()
					? Lang.t("Signed in with Microsoft") : Lang.t("Offline name works for singleplayer, LAN and offline-mode servers"), cw);
			if (app.settings.signedIn()) {
				g.setFont(Style.bold(15f));
				g.setColor(Style.TEXT);
				g.drawString(app.settings.mcName, PAD + 22, yAccount + 76);
			}
			section(g, yWindow, yLauncher - 24, Lang.t("Game window"), Lang.t("Starting size of the Minecraft window"), cw);
			g.setFont(Style.medium(14f));
			g.setColor(Style.TEXT_DIM);
			g.drawString("×", PAD + 22 + 120, yWindow + 75);
			section(g, yLauncher, yAbout - 24, Lang.t("Launcher"), null, cw);
			g.setFont(Style.medium(13f));
			g.setColor(Style.TEXT);
			g.drawString(Lang.t("Language"), PAD + 22 + 260, yLauncher + 66);
			g.setFont(Style.regular(11.5f));
			g.setColor(Style.TEXT_MUTED);
			g.drawString(Lang.t("Restarts the launcher to switch"), PAD + 22 + 260, yLauncher + 84);
			section(g, yAbout, yAbout + 120, Lang.t("About"), null, cw);
			g.setFont(Style.regular(12.5f));
			g.setColor(Style.TEXT_DIM);
			g.drawString(Lang.t("Cherry Blossom Client 2.0  ·  every Minecraft version from Alpha to ") + latest(), PAD + 22, yAbout + 66);
			g.drawString(Lang.t("Mods come from Modrinth, Minecraft and Java from Mojang. Fonts: DM Serif Display and Plus Jakarta Sans (OFL)."), PAD + 22, yAbout + 88);
			g.dispose();
		}

		private String latest() {
			return app.versions == null ? "today" : app.versions.latestRelease();
		}

		private void section(Graphics2D g, int top, int bottom, String title, String sub, int cw) {
			Style.card(g, PAD, top, cw, bottom - top);
			g.setFont(Style.bold(16f));
			g.setColor(Style.TEXT);
			g.drawString(title, PAD + 22, top + 32);
			if (sub != null) {
				g.setFont(Style.regular(12f));
				g.setColor(Style.TEXT_MUTED);
				FontMetrics fm = g.getFontMetrics(Style.bold(16f));
				g.drawString(sub, PAD + 22 + fm.stringWidth(title) + 14, top + 32);
			}
		}
	}

	/** One of Low-end / Balanced / High-end / Custom. */
	private final class PresetCard extends Controls.Base {
		private final Presets.Preset preset;

		PresetCard(Presets.Preset p) {
			this.preset = p;
		}

		@Override void clicked(MouseEvent e) {
			if (preset == Presets.Preset.CUSTOM) {
				app.settings.preset = Presets.Preset.CUSTOM;
			} else {
				app.settings.applyPreset(preset);
			}
			app.settings.save();
			app.changed();
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			boolean sel = app.settings.preset == preset;
			RoundRectangle2D r = new RoundRectangle2D.Float(1, 1, w - 2, h - 2, 18, 18);
			g.setColor(sel ? Style.alpha(Style.ACCENT, 0.16f) : new Color(255, 255, 255, Math.round(10 + hover * 10)));
			g.fill(r);
			g.setColor(sel ? Style.ACCENT : Style.mix(Style.CARD_BORDER, Style.alpha(Style.ACCENT, 0.5f), hover));
			g.setStroke(new BasicStroke(sel ? 2f : 1f));
			g.draw(r);
			Icons.Glyph icon = switch (preset) {
				case LOW -> Icons.PETAL;
				case BALANCED -> Icons.BOLT;
				case HIGH -> Icons.CPU;
				default -> Icons.SETTINGS;
			};
			icon.paint(g, 16, 16, 20, sel ? Style.ACCENT : Style.TEXT_DIM);
			g.setFont(Style.bold(14f));
			g.setColor(Style.TEXT);
			g.drawString(preset.label, 16, 58);
			g.setFont(Style.regular(11.5f));
			g.setColor(Style.TEXT_MUTED);
			FontMetrics fm = g.getFontMetrics();
			int y = 78;
			for (String line : Style.wrap(preset.about, fm, w - 30)) {
				g.drawString(line, 16, y);
				y += 15;
			}
			if (preset == Presets.recommend()) {
				g.setFont(Style.bold(10f));
				String t = Lang.t("SUGGESTED");
				int tw = g.getFontMetrics().stringWidth(t) + 14;
				g.setColor(Style.alpha(Style.ACCENT, 0.9f));
				g.fill(new RoundRectangle2D.Float(w - tw - 12, 16, tw, 18, 18, 18));
				g.setColor(Style.ACCENT_INK);
				g.drawString(t, w - tw - 5, 29);
			}
			g.dispose();
		}
	}
}
