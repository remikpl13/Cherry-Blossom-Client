package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.VersionInfo;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Original artwork drawn in code: blocky hills under a tinted sky for each version,
 * and a cherry branch for the home banner. No borrowed images.
 */
public final class Art {
	private Art() {}

	private static final Map<String, BufferedImage> CACHE = new HashMap<>();

	/** Version cover, cached per size. */
	public static BufferedImage cover(String key, int w, int h) {
		return cover(key, key, w, h);
	}

	/** Version cover with a custom big label (e.g. a year for snapshot groups). */
	public static BufferedImage cover(String key, String label, int w, int h) {
		return CACHE.computeIfAbsent(key + "|" + label + "@" + w + "x" + h, k -> {
			BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = Style.smooth(img.getGraphics());
			paintCover(g, key, label, w, h);
			g.dispose();
			return img;
		});
	}

	private static void paintCover(Graphics2D g, String key, String label, int w, int h) {
		VersionInfo.Info info = VersionInfo.of(key);
		Color a = new Color(info.colorA()), b = new Color(info.colorB());
		g.clip(new RoundRectangle2D.Float(0, 0, w, h, 18, 18));
		g.setPaint(new GradientPaint(0, 0, Style.mix(a, Color.WHITE, 0.15f), 0, h, b));
		g.fillRect(0, 0, w, h);
		Random rnd = new Random(key.hashCode());

		// a soft sun
		float sx = w * (0.25f + rnd.nextFloat() * 0.5f), sy = h * (0.18f + rnd.nextFloat() * 0.12f);
		g.setPaint(new RadialGradientPaint(sx, sy, w * 0.5f, new float[] {0, 1},
				new Color[] {new Color(255, 250, 240, 120), new Color(255, 250, 240, 0)}));
		g.fillRect(0, 0, w, h);
		g.setColor(new Color(255, 252, 245, 190));
		float sr = w * 0.07f;
		g.fill(new Ellipse2D.Float(sx - sr, sy - sr, sr * 2, sr * 2));

		// three layers of blocky hills, nearer ones darker
		int block = Math.max(6, w / 18);
		for (int layer = 0; layer < 3; layer++) {
			float base = h * (0.52f + layer * 0.11f);
			float amp = h * (0.10f - layer * 0.02f);
			double phase = rnd.nextDouble() * 10;
			Color c = Style.mix(Style.mix(a, b, 0.55f + layer * 0.15f), new Color(0x1A0E14), 0.25f + layer * 0.2f);
			g.setColor(c);
			for (int x = 0; x < w + block; x += block) {
				double n = Math.sin(x * 0.025 + phase) * 0.6 + Math.sin(x * 0.061 + phase * 2) * 0.4;
				int top = Math.round((float) (base - n * amp) / block) * block;
				g.fillRect(x, top, block, h - top);
				// a lighter grass edge on the top block
				g.setColor(Style.mix(c, a, 0.35f));
				g.fillRect(x, top, block, Math.max(2, block / 4));
				g.setColor(c);
			}
		}

		// a few drifting petals
		for (int i = 0; i < 6; i++) {
			Graphics2D p = (Graphics2D) g.create();
			p.translate(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.6f);
			p.rotate(rnd.nextFloat() * 6.28);
			p.setColor(new Color(255, 230, 238, 90 + rnd.nextInt(80)));
			p.fill(Blossom.petal(4 + rnd.nextFloat() * 5));
			p.dispose();
		}

		// darken the bottom so text reads well
		g.setPaint(new GradientPaint(0, h * 0.55f, new Color(16, 8, 12, 0), 0, h, new Color(16, 8, 12, 200)));
		g.fillRect(0, 0, w, h);

		if (label.isEmpty()) return;
		float size = Math.min(w * 0.27f, h * 0.36f);
		g.setFont(Style.display(size));
		while (g.getFontMetrics().stringWidth(label) > w - 24 && size > 10) g.setFont(Style.display(size -= 2));
		g.setColor(new Color(255, 248, 251, 240));
		g.drawString(label, 12, h - (info.name().isEmpty() ? 14 : 30));
		if (!info.name().isEmpty()) {
			g.setFont(Style.medium(Math.max(10f, w * 0.068f)));
			FontMetrics nf = g.getFontMetrics();
			String name = info.name();
			while (nf.stringWidth(name) > w - 24 && name.length() > 4) name = name.substring(0, name.length() - 2);
			if (!name.equals(info.name())) name = name + "…";
			g.setColor(new Color(255, 235, 242, 210));
			g.drawString(name, 13, h - 13);
		}
	}

	/** The home banner: dusky sky, hills, and a cherry branch reaching in from the corner. */
	public static void hero(Graphics2D g, int w, int h, double time) {
		g.setPaint(new GradientPaint(0, 0, new Color(0x3B1F35), 0, h, new Color(0x6E3553)));
		g.fillRect(0, 0, w, h);
		g.setPaint(new RadialGradientPaint(w * 0.72f, h * 0.35f, w * 0.45f, new float[] {0, 1},
				new Color[] {new Color(255, 196, 214, 110), new Color(255, 196, 214, 0)}));
		g.fillRect(0, 0, w, h);
		// moon
		g.setColor(new Color(255, 240, 230, 220));
		g.fill(new Ellipse2D.Float(w * 0.72f - 26, h * 0.3f - 26, 52, 52));

		// stars
		Random rnd = new Random(11);
		for (int i = 0; i < 40; i++) {
			float x = rnd.nextFloat() * w, y = rnd.nextFloat() * h * 0.5f;
			float tw = (float) (0.5 + 0.5 * Math.sin(time * 1.3 + i));
			g.setColor(new Color(255, 240, 248, Math.round(40 + 90 * tw)));
			g.fill(new Ellipse2D.Float(x, y, 2, 2));
		}

		// hills
		int block = 14;
		Color[] layers = {new Color(0x5A2C47), new Color(0x452238), new Color(0x2E1726)};
		for (int l = 0; l < 3; l++) {
			float base = h * (0.62f + l * 0.12f);
			g.setColor(layers[l]);
			for (int x = 0; x < w + block; x += block) {
				double n = Math.sin(x * 0.012 + l * 2.1) * 0.6 + Math.sin(x * 0.031 + l) * 0.4;
				int top = Math.round((float) (base - n * h * 0.08f) / block) * block;
				g.fillRect(x, top, block, h - top);
			}
		}

		// branch from the top-right corner
		g.setColor(new Color(0x2A1520));
		g.setStroke(new java.awt.BasicStroke(9, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
		Path2D br = new Path2D.Float();
		br.moveTo(w + 10, -10);
		br.curveTo(w - 120, 40, w - 220, 60, w - 330, 140);
		g.draw(br);
		g.setStroke(new java.awt.BasicStroke(5, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
		Path2D tw2 = new Path2D.Float();
		tw2.moveTo(w - 160, 46);
		tw2.curveTo(w - 200, 100, w - 230, 130, w - 260, 210);
		g.draw(tw2);
		Path2D tw3 = new Path2D.Float();
		tw3.moveTo(w - 70, 14);
		tw3.curveTo(w - 60, 70, w - 90, 110, w - 110, 150);
		g.draw(tw3);

		float[][] flowers = {{w - 335, 140, 20}, {w - 300, 118, 15}, {w - 255, 205, 18}, {w - 225, 150, 13},
				{w - 110, 150, 17}, {w - 90, 104, 13}, {w - 180, 70, 16}, {w - 40, 30, 14}, {w - 140, 40, 11}};
		for (int i = 0; i < flowers.length; i++) {
			float[] f = flowers[i];
			double sway = Math.sin(time * 0.8 + i) * 0.06;
			Blossom.draw(g, f[0], f[1], f[2], 1f, sway + i, 1f);
		}
	}
}
