package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.Http;
import dev.cherryblossom.launcher.core.Installer;
import dev.cherryblossom.launcher.core.Json;
import dev.cherryblossom.launcher.core.MicrosoftAuth;
import dev.cherryblossom.launcher.core.Settings;
import dev.cherryblossom.launcher.core.VersionList;

import javax.swing.SwingUtilities;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Everything the pages share: settings, the selected version, background lookups and the launch itself. */
public final class App {
	public interface Host {
		void gameStarted();
		void gameStopped(int exitCode);
	}

	public final Settings settings;
	public final Installer installer;
	public volatile VersionList versions;
	private Host host;

	private final List<Runnable> listeners = new ArrayList<>();
	private final ExecutorService background = Executors.newFixedThreadPool(4, r -> {
		Thread t = new Thread(r, "cherry-lookup");
		t.setDaemon(true);
		return t;
	});
	private final Map<String, Boolean> fabric = new ConcurrentHashMap<>();
	private final Map<String, Boolean> modrinth = new ConcurrentHashMap<>();
	private final Map<String, Boolean> pending = new ConcurrentHashMap<>();

	// Launch state, read by the UI.
	public volatile String status = "";
	public volatile boolean statusError;
	public volatile float progress;
	public volatile boolean busy;
	public volatile boolean running;

	public final dev.cherryblossom.launcher.core.DiscordPresence discord;

	public final dev.cherryblossom.launcher.core.Friends friends;
	public final dev.cherryblossom.launcher.core.FriendsBridge bridge;
	public final dev.cherryblossom.launcher.core.Updater updater;

	public App(Settings settings, Installer installer) {
		this.settings = settings;
		this.installer = installer;
		this.discord = new dev.cherryblossom.launcher.core.DiscordPresence(settings);
		discord.idle();
		friends = new dev.cherryblossom.launcher.core.Friends(installer.base().resolve("friends.json"), settings);
		friends.listen(this::changed);
		friends.onNotice((title, text) -> { if (!running) setStatus(title + ": " + text, false); });
		bridge = new dev.cherryblossom.launcher.core.FriendsBridge(friends);
		bridge.start();
		friends.start();
		updater = new dev.cherryblossom.launcher.core.Updater(installer.base().toAbsolutePath().getParent().resolve("launcher"));
		updater.onChange(this::changed);
		updater.start();
	}

	public void setHost(Host host) {
		this.host = host;
	}

	public void listen(Runnable r) {
		listeners.add(r);
	}

	/** Tells every page to refresh. Safe to call from any thread. */
	public void changed() {
		if (!SwingUtilities.isEventDispatchThread()) {
			SwingUtilities.invokeLater(this::changed);
			return;
		}
		for (Runnable r : new ArrayList<>(listeners)) r.run();
	}

	// ---------------------------------------------------------------- selection

	public VersionList.Version selected() {
		VersionList vl = versions;
		if (vl == null) return null;
		VersionList.Version v = vl.find(settings.selectedVersion);
		if (v == null) v = vl.find(vl.latestRelease());
		return v;
	}

	public void select(String id) {
		settings.selectedVersion = id;
		settings.save();
		changed();
	}

	/** Whether this launch will use Fabric (it's only possible from 1.14 up). */
	public boolean willUseFabric(String id) {
		Boolean f = fabricSupport(id);
		return settings.useFabric && f != null && f;
	}

	/** Fabric support for a version: true/false, or null while we're still asking. */
	public Boolean fabricSupport(String id) {
		Boolean known = fabric.get(id);
		if (known != null) return known;
		lookup("fabric:" + id, () -> fabric.put(id, installer.fabricSupports(id)));
		return null;
	}

	/** Whether a Modrinth mod exists for this version: true/false, or null while checking. */
	public Boolean modAvailable(String slug, String version) {
		String key = slug + "@" + version;
		Boolean known = modrinth.get(key);
		if (known != null) return known;
		lookup("mod:" + key, () -> {
			String q = "?loaders=" + URLEncoder.encode("[\"fabric\"]", StandardCharsets.UTF_8)
					+ "&game_versions=" + URLEncoder.encode("[\"" + version + "\"]", StandardCharsets.UTF_8);
			try {
				modrinth.put(key, !Json.arr(Http.getJsonAny("https://api.modrinth.com/v2/project/" + slug + "/version" + q)).isEmpty());
			} catch (Exception e) {
				modrinth.put(key, false);
			}
		});
		return null;
	}

	private void lookup(String key, Runnable work) {
		if (pending.putIfAbsent(key, Boolean.TRUE) != null) return;
		background.submit(() -> {
			try {
				work.run();
			} finally {
				pending.remove(key);
				changed();
			}
		});
	}

	public String playerName() {
		String n = settings.playerName();
		return n == null || n.isBlank() ? Lang.t("Player") : n;
	}

	public Path gameDir() {
		VersionList.Version v = selected();
		return installer.gameDir(v == null ? "26" : v.id());
	}

	// ---------------------------------------------------------------- launching

	public void setStatus(String text, boolean error) {
		status = text;
		statusError = error;
		changed();
	}

	/** Installs whatever's missing and starts the selected version, optionally joining a server. */
	public void launch(String server) {
		if (busy || running) return;
		VersionList.Version v = selected();
		if (v == null) {
			setStatus(Lang.t("Still loading the version list. One moment."), true);
			return;
		}
		if (!settings.signedIn()) {
			String name = settings.offlineName.trim();
			if (!name.matches("[A-Za-z0-9_]{3,16}")) {
				setStatus(Lang.t("Set a player name first (Settings, 3 to 16 letters, numbers or _)."), true);
				return;
			}
		}
		busy = true;
		progress = 0;
		setStatus(Lang.t("Getting ready"), false);
		Thread t = new Thread(() -> {
			try {
				if (settings.signedIn() && !MicrosoftAuth.refresh(settings)) {
					throw new IllegalStateException(Lang.t("Your Microsoft sign-in expired. Please sign in again in Settings."));
				}
				Installer.Account acc;
				if (settings.signedIn()) {
					acc = new Installer.Account(settings.mcName, settings.mcUuid, settings.mcAccessToken, "msa", "");
				} else {
					String name = settings.offlineName.trim();
					UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
					acc = new Installer.Account(name, uuid.toString().replace("-", ""), "0", "legacy", "");
				}
				boolean useFabric = settings.useFabric && installer.fabricSupports(v.id());
				List<String> cmd = installer.prepare(settings, v, useFabric, acc, server, (s, f) -> {
					status = s;
					statusError = false;
					progress = (float) f;
					changed();
				});
				String link = bridge.jvmArg();
				if (link != null) cmd.add(1, link);
				friends.setActivity("playing", v.id(), server);
				settings.markPlayed(v.id());
				settings.save();
				discord.playing(v.id(), useFabric, useFabric && settings.cherryHud && Installer.hasCherryHud(v.id()), server);
				runGame(v.id(), cmd);
			} catch (Exception e) {
				e.printStackTrace();
				String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
				busy = false;
				discord.idle();
				friends.setActivity("online", "", "");
				setStatus(Lang.t("Couldn't start: ") + msg, true);
			}
		}, "cherry-launch");
		t.setDaemon(true);
		t.start();
	}

	private void runGame(String id, List<String> cmd) throws Exception {
		Path dir = installer.gameDir(id);
		Path logs = dir.resolve("logs");
		Files.createDirectories(logs);
		Process p = new ProcessBuilder(cmd)
				.directory(dir.toFile())
				.redirectErrorStream(true)
				.redirectOutput(logs.resolve("launcher-output.log").toFile())
				.start();
		busy = false;
		running = true;
		progress = 1;
		setStatus("Minecraft " + id + Lang.t(" is starting. Have fun!"), false);
		if (host != null) SwingUtilities.invokeLater(host::gameStarted);
		int code = p.waitFor();
		running = false;
		discord.idle();
		friends.setActivity("online", "", "");
		if (code == 0) setStatus(Lang.t("Welcome back."), false);
		else setStatus(Lang.t("Minecraft closed with an error (code ") + code + Lang.t("). Check the logs in the game folder."), true);
		if (host != null) SwingUtilities.invokeLater(() -> host.gameStopped(code));
	}
}
