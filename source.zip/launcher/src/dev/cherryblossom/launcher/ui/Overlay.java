package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import javax.swing.JComponent;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/** A centred dialog card drawn inside the window (no ugly system dialogs). */
public final class Overlay extends JComponent implements Controls.Animated {
	private static final int W = 440;

	private String title = "";
	private String body = "";
	private String code;
	private boolean busy;
	private float shown, target;
	private float spin;
	private final List<JComponent> parts = new ArrayList<>();

	public Overlay() {
		setOpaque(false);
		setLayout(null);
		setVisible(false);
		// swallow clicks so nothing behind the dialog reacts
		addMouseListener(new MouseAdapter() {});
		addMouseMotionListener(new MouseAdapter() {});
	}

	public boolean isOpen() {
		return target > 0;
	}

	/** Shows the dialog. Components (buttons, a field) are laid out under the text, last row = buttons. */
	public void open(String title, String body, String code, boolean busy, Controls.Field field,
					 Controls.PrimaryButton primary, Controls.GhostButton secondary) {
		this.title = title;
		this.body = body;
		this.code = code;
		this.busy = busy;
		for (JComponent c : parts) remove(c);
		parts.clear();

		int cardH = cardHeight(field != null, primary != null || secondary != null);
		int x = (getWidth() - W) / 2 + 28;
		int y = (getHeight() - cardH) / 2 + textBlockHeight() + 28;
		if (field != null) {
			field.setBounds(x, y, W - 56, 42);
			add(field);
			parts.add(field);
			y += 56;
		}
		int bx = x + W - 56;
		if (primary != null) {
			int bw = Math.min(W - 56 - 110, Math.max(130, labelWidth(primary) + 48));
			bx -= bw;
			primary.setBounds(bx, y, bw, 40);
			add(primary);
			parts.add(primary);
			bx -= 10;
		}
		if (secondary != null) {
			secondary.setBounds(bx - 100, y, 100, 40);
			add(secondary);
			parts.add(secondary);
		}
		setVisible(true);
		target = 1;
		if (field != null) field.requestFocusInWindow();
	}

	private int labelWidth(Controls.PrimaryButton b) {
		return getFontMetrics(Style.bold(13f)).stringWidth(b.label());
	}

	public void close() {
		target = 0;
	}

	public void setBody(String body) {
		this.body = body;
		repaint();
	}

	private List<String> wrap(String text, FontMetrics fm, int width) {
		List<String> lines = new ArrayList<>();
		for (String para : text.split("\n")) {
			StringBuilder line = new StringBuilder();
			for (String word : para.split(" ")) {
				String tryLine = line.isEmpty() ? word : line + " " + word;
				if (fm.stringWidth(tryLine) > width && !line.isEmpty()) {
					lines.add(line.toString());
					line = new StringBuilder(word);
				} else {
					line = new StringBuilder(tryLine);
				}
			}
			lines.add(line.toString());
		}
		return lines;
	}

	private int textBlockHeight() {
		FontMetrics fm = getFontMetrics(Style.regular(13.5f));
		int h = 34 + wrap(body, fm, W - 56).size() * 21;
		if (code != null) h += 64;
		if (busy) h += 26;
		return h;
	}

	private int cardHeight(boolean field, boolean buttons) {
		return 28 + textBlockHeight() + (field ? 56 : 0) + (buttons ? 40 : 0) + 28;
	}

	@Override public void addNotify() { super.addNotify(); Controls.Anim.add(this); }

	@Override public void removeNotify() { Controls.Anim.remove(this); super.removeNotify(); }

	@Override
	public void tick(float dt) {
		if (!isVisible()) return;
		float before = shown;
		shown = Style.approach(shown, target, 16, dt);
		spin += dt;
		if (target == 0 && shown < 0.01f) {
			setVisible(false);
			for (JComponent c : parts) remove(c);
			parts.clear();
		}
		if (busy || Math.abs(before - shown) > 0.001f) repaint();
	}

	@Override
	public void setBounds(int x, int y, int w, int h) {
		super.setBounds(x, y, w, h);
		relayout();
	}

	private void relayout() {
		// keep the dialog centred if the window is resized while it's open
		if (parts.isEmpty()) return;
		boolean hasField = parts.stream().anyMatch(c -> c instanceof Controls.Field);
		int cardH = cardHeight(hasField, true);
		int x = (getWidth() - W) / 2 + 28;
		int y = (getHeight() - cardH) / 2 + textBlockHeight() + 28;
		int bx = x + W - 56;
		for (JComponent c : parts) {
			if (c instanceof Controls.Field) { c.setLocation(x, y); }
		}
		int by = hasField ? y + 56 : y;
		for (JComponent c : parts) {
			if (c instanceof Controls.PrimaryButton) { c.setLocation(bx - c.getWidth(), by); bx -= c.getWidth() + 10; }
		}
		for (JComponent c : parts) {
			if (c instanceof Controls.GhostButton) { c.setLocation(bx - c.getWidth(), by); }
		}
	}

	@Override
	protected void paintComponent(Graphics g0) {
		Graphics2D g = Style.smooth(g0);
		float a = Style.easeOut(shown);
		g.setColor(new Color(12, 6, 9, Math.round(150 * a)));
		g.fillRect(0, 0, getWidth(), getHeight());

		boolean hasField = false, hasButtons = false;
		for (JComponent c : parts) {
			if (c instanceof Controls.Field) hasField = true; else hasButtons = true;
		}
		int h = cardHeight(hasField, hasButtons);
		int x = (getWidth() - W) / 2;
		int y = (getHeight() - h) / 2 + Math.round((1 - a) * 12);
		g.setComposite(java.awt.AlphaComposite.SrcOver.derive(a));
		g.setColor(new Color(0x2A1820));
		g.fill(new RoundRectangle2D.Float(x, y, W, h, 22, 22));
		g.setColor(Style.CARD_BORDER);
		g.draw(new RoundRectangle2D.Float(x + 0.5f, y + 0.5f, W - 1, h - 1, 22, 22));

		int tx = x + 28, ty = y + 28;
		g.setFont(Style.display(24f));
		g.setColor(Style.TEXT);
		g.drawString(title, tx, ty + 20);
		ty += 34;
		g.setFont(Style.regular(13.5f));
		FontMetrics fm = g.getFontMetrics();
		g.setColor(Style.TEXT_DIM);
		for (String line : wrap(body, fm, W - 56)) {
			ty += 21;
			g.drawString(line, tx, ty - 5);
		}
		if (code != null) {
			ty += 8;
			g.setColor(new Color(255, 255, 255, 14));
			g.fill(new RoundRectangle2D.Float(tx, ty, W - 56, 52, 14, 14));
			g.setFont(Style.bold(26f));
			FontMetrics cf = g.getFontMetrics();
			g.setColor(Style.ACCENT);
			float cw = Controls.trackedWidth(cf, code, 4);
			Style.tracked(g, code, tx + (W - 56 - cw) / 2f, ty + 26 + cf.getAscent() / 2f - 3, 4);
			ty += 56;
		}
		if (busy) {
			ty += 6;
			for (int i = 0; i < 3; i++) {
				float p = (float) (0.5 + 0.5 * Math.sin(spin * 5 - i * 0.7));
				g.setColor(Style.alpha(Style.ACCENT, 0.3f + 0.7f * p));
				g.fill(new java.awt.geom.Ellipse2D.Float(tx + i * 12, ty + 2, 6, 6));
			}
			g.setFont(Style.regular(12.5f));
			g.setColor(Style.TEXT_MUTED);
			g.drawString(Lang.t("Waiting for you to finish in the browser"), tx + 44, ty + 9);
		}
		g.dispose();
	}
}
