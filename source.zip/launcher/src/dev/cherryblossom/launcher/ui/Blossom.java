package dev.cherryblossom.launcher.ui;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;

/** The cherry blossom mark, drawn as vectors so it's crisp at any size. */
public final class Blossom {
	private Blossom() {}

	/** One petal pointing up from the origin, with the little notch real sakura petals have. */
	public static Path2D petal(double len) {
		double w = len * 0.42;
		double notch = len * 0.13;
		Path2D p = new Path2D.Double();
		p.moveTo(0, 0);
		p.curveTo(-w * 0.55, -len * 0.18, -w, -len * 0.62, -w * 0.46, -len * 0.97);
		p.quadTo(-w * 0.2, -len * 1.02, 0, -len + notch);
		p.quadTo(w * 0.2, -len * 1.02, w * 0.46, -len * 0.97);
		p.curveTo(w, -len * 0.62, w * 0.55, -len * 0.18, 0, 0);
		p.closePath();
		return p;
	}

	/**
	 * Draws the five-petal flower centred on (cx, cy).
	 * @param bloom 0..1, petals unfold one after another as it grows (used by the loading screen)
	 * @param rotation radians
	 */
	public static void draw(Graphics2D g, double cx, double cy, double radius, float bloom, double rotation, float alpha) {
		AffineTransform saved = g.getTransform();
		g.translate(cx, cy);
		g.rotate(rotation);
		for (int i = 0; i < 5; i++) {
			float local = Math.max(0f, Math.min(1f, bloom * 5f - i * 0.7f));
			float s = Style.easeOut(local);
			if (s <= 0) continue;
			AffineTransform t = g.getTransform();
			g.rotate(Math.toRadians(i * 72));
			g.scale(s, s);
			Path2D petal = petal(radius);
			g.setPaint(new GradientPaint(0, 0, Style.alpha(new Color(0xFFE3EC), alpha),
					0, (float) -radius, Style.alpha(Style.ACCENT_DEEP, alpha)));
			g.fill(petal);
			g.setTransform(t);
		}
		float core = Style.easeOut(Math.max(0f, bloom * 2f - 1f));
		if (core > 0) {
			double r = radius * 0.2 * core;
			g.setColor(Style.alpha(new Color(0xFFF1C9), alpha));
			g.fill(new Ellipse2D.Double(-r, -r, r * 2, r * 2));
			g.setColor(Style.alpha(new Color(0xE8A23F), alpha * 0.9f));
			for (int i = 0; i < 5; i++) {
				double a = Math.toRadians(i * 72 + 36);
				double d = radius * 0.34 * core;
				double dot = radius * 0.06;
				g.fill(new Ellipse2D.Double(Math.sin(a) * d - dot, -Math.cos(a) * d - dot, dot * 2, dot * 2));
			}
		}
		g.setTransform(saved);
	}
}
