package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.MicrosoftAuth;
import dev.cherryblossom.launcher.core.VersionList;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.AWTEvent;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.net.URI;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/** The launcher window: loading screen, title bar, sidebar and the four pages. */
public final class LauncherWindow extends JFrame implements App.Host {
	private static final int TITLE_H = 52, SIDE_W = 84, EDGE = 6;

	private final App app;
	private final boolean translucent;
	private final Root root = new Root();
	private final Splash splash = new Splash();
	private final Overlay overlay = new Overlay();
	private final Map<String, JComponent> pages = new LinkedHashMap<>();
	private final Controls.Link update = new Controls.Link("", this::installUpdate).color(Style.ACCENT);
	private final Map<String, Controls.NavButton> nav = new LinkedHashMap<>();
	private final AccountChip account = new AccountChip();
	private String page = "home";
	private JComponent current;
	private float pageFade = 1f;
	private long lastTick = System.nanoTime();
	private final Timer timer;
	private BufferedImage background;
	private Rectangle restoreBounds;

	public LauncherWindow(App app) {
		super("Cherry Blossom Client");
		this.app = app;
		app.setHost(this);

		setUndecorated(true);
		Rectangle screen = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
		int w = Math.min(1220, Math.round(screen.width * 0.92f)), h = Math.min(760, Math.round(screen.height * 0.9f));
		setSize(Math.max(1000, w), Math.max(640, h));
		setMinimumSize(new java.awt.Dimension(1000, 640));
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
		translucent = gd.isWindowTranslucencySupported(GraphicsDevice.WindowTranslucency.PERPIXEL_TRANSLUCENT)
				&& !Boolean.getBoolean("cherry.opaque");
		if (translucent) setBackground(new Color(0, 0, 0, 0));
		setIconImages(Icons.windowIcons());

		JLayeredPane layers = new JLayeredPane() {
			@Override
			public void doLayout() {
				int lw = getWidth(), lh = getHeight();
				root.setBounds(0, 0, lw, lh);
				overlay.setBounds(0, 0, lw, lh);
				splash.setBounds(0, 0, lw, lh);
				root.doLayout();
			}
		};
		layers.setOpaque(false);
		setContentPane(layers);
		root.setLayout(null);
		layers.add(root, JLayeredPane.DEFAULT_LAYER);
		layers.add(overlay, JLayeredPane.MODAL_LAYER);
		layers.add(splash, JLayeredPane.DRAG_LAYER);

		// title bar
		root.add(new Controls.WindowButton(Controls.WindowButton.Kind.MIN, () -> setState(ICONIFIED)));
		root.add(new Controls.WindowButton(Controls.WindowButton.Kind.MAX, this::toggleMaximized));
		root.add(new Controls.WindowButton(Controls.WindowButton.Kind.CLOSE, this::dispose));
		root.add(account);
		root.add(update);

		// pages and sidebar
		pages.put("home", new HomePage(app, this::show, this::addServerDialog));
		pages.put("versions", new VersionsPage(app));
		pages.put("mods", new ModsPage(app));
		pages.put("server", new ServerPage(app));
		pages.put("friends", new FriendsPage(app));
		pages.put("settings", new SettingsPage(app, this::microsoftSignIn));
		addNav("home", Icons.HOME, Lang.t("Home"));
		addNav("versions", Icons.VERSIONS, Lang.t("Versions"));
		addNav("mods", Icons.MODS, Lang.t("Mods"));
		addNav("friends", Icons.FRIENDS, Lang.t("Friends"));
		addNav("server", Icons.SERVER, Lang.t("Server"));
		addNav("settings", Icons.SETTINGS, Lang.t("Settings"));
		for (JComponent p : pages.values()) { p.setVisible(false); root.add(p); }
		Controls.NavButton folder = new Controls.NavButton(Icons.FOLDER, Lang.t("Folder"), this::openGameFolder);
		root.add(folder);
		nav.put("_folder", folder);
		current = pages.get("home");
		current.setVisible(true);
		nav.get("home").setSelected(true);

		installWindowDragAndResize();

		// One timer drives every animation; it stops whenever the window can't be seen.
		timer = new Timer(16, e -> frame());
		timer.setCoalesce(true);
		addWindowListener(new WindowAdapter() {
			@Override public void windowIconified(WindowEvent e) { timer.stop(); }
			@Override public void windowDeiconified(WindowEvent e) { lastTick = System.nanoTime(); timer.start(); }
		});
		app.listen(() -> { account.repaint(); refreshUpdate(); root.repaint(0, 0, getWidth(), TITLE_H); });
		timer.start();
	}

	private void addNav(String key, Icons.Glyph icon, String label) {
		Controls.NavButton b = new Controls.NavButton(icon, label, () -> show(key));
		nav.put(key, b);
		root.add(b);
	}

	/** Switches page with a quick fade. */
	void show(String key) {
		if (key.equals(page)) return;
		page = key;
		for (Map.Entry<String, Controls.NavButton> e : nav.entrySet()) e.getValue().setSelected(e.getKey().equals(key));
		current.setVisible(false);
		current = pages.get(key);
		if (current instanceof VersionsPage v) v.showSelected();
		current.setVisible(true);
		pageFade = 0f;
		root.doLayout();
		root.repaint();
	}

	private void frame() {
		long now = System.nanoTime();
		float dt = Math.min(0.05f, (now - lastTick) / 1e9f);
		lastTick = now;
		Controls.Anim.tickAll(dt);
		if (splash.isVisible()) splash.tick(dt);
		if (pageFade < 1f) {
			pageFade = Math.min(1f, pageFade + dt / 0.18f);
			root.repaint(SIDE_W, TITLE_H, getWidth() - SIDE_W, getHeight() - TITLE_H);
		}
	}

	// ---------------------------------------------------------------- loading screen

	public void start() {
		setVisible(true);
		Thread t = new Thread(() -> {
			long started = System.currentTimeMillis();
			splash.status = Lang.t("Loading the version list");
			try {
				app.versions = VersionList.load(app.installer.base().resolve("versions"));
			} catch (Exception e) {
				SwingUtilities.invokeLater(() -> app.setStatus(Lang.t("Couldn't reach Mojang. Check your internet connection."), true));
			}
			if (app.settings.signedIn()) {
				splash.status = Lang.t("Signing you in");
				if (!MicrosoftAuth.refresh(app.settings)) {
					app.setStatus(Lang.t("Your Microsoft sign-in expired. Sign in again in Settings."), true);
				}
			}
			VersionList.Version v = app.selected();
			if (v != null) app.fabricSupport(v.id());
			splash.status = Lang.t("Ready");
			long wait = 1800 - (System.currentTimeMillis() - started);
			if (wait > 0) try { Thread.sleep(wait); } catch (InterruptedException ignored) {}
			SwingUtilities.invokeLater(() -> {
				if (app.settings.offlineName.isBlank() && !app.settings.signedIn()) {
					app.setStatus(Lang.t("Set your player name in Settings, then press Launch."), false);
				}
				app.changed();
				splash.leaving = true;
			});
		}, "cherry-startup");
		t.setDaemon(true);
		t.start();
	}

	private final class Splash extends JComponent {
		private float bloomTime, fade = 1f;
		volatile boolean leaving;
		volatile String status = Lang.t("Loading");
		private double time;

		Splash() {
			setOpaque(false);
			addMouseListener(new MouseAdapter() {});
		}

		void tick(float dt) {
			bloomTime += dt;
			time += dt;
			if (leaving) {
				fade -= dt / 0.45f;
				if (fade <= 0) {
					fade = 0;
					setVisible(false);
					root.repaint();
				}
			}
			repaint();
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			float a = Style.easeInOut(fade);
			g.setComposite(AlphaComposite.SrcOver.derive(a));
			g.drawImage(background(), 0, 0, null);
			float cy = h / 2f - 60;
			float bloom = Math.min(1f, bloomTime / 1.2f);
			double rot = Math.toRadians(-18) * (1 - Style.easeOut(bloom)) + Math.sin(time * 0.8) * 0.04;
			float lift = leaving ? (1 - a) * -14 : 0;
			Blossom.draw(g, w / 2.0, cy + lift, 52, bloom, rot, 1f);

			float textIn = Style.easeOut((bloomTime - 0.35f) / 0.8f);
			g.setComposite(AlphaComposite.SrcOver.derive(a * textIn));
			g.setFont(Style.display(40f));
			FontMetrics fm = g.getFontMetrics();
			String title = "Cherry Blossom Client";
			g.setColor(Style.TEXT);
			g.drawString(title, (w - fm.stringWidth(title)) / 2f, cy + 124 + (1 - textIn) * 8 + lift);

			int bw = 200, bx = (w - bw) / 2, by = Math.round(cy + 162);
			g.setColor(new Color(255, 255, 255, 22));
			g.fill(new RoundRectangle2D.Float(bx, by, bw, 3, 3, 3));
			float p = (float) ((time * 0.7) % 1.0);
			float seg = 70, sx = bx - seg + p * (bw + seg);
			Graphics2D clip = (Graphics2D) g.create();
			clip.clip(new RoundRectangle2D.Float(bx, by, bw, 3, 3, 3));
			clip.setPaint(new GradientPaint(sx, 0, Style.alpha(Style.ACCENT, 0), sx + seg / 2, 0, Style.ACCENT, true));
			clip.fillRect(Math.round(sx), by, Math.round(seg), 3);
			clip.dispose();
			g.setFont(Style.medium(12.5f));
			fm = g.getFontMetrics();
			g.setColor(Style.TEXT_MUTED);
			g.drawString(status, (w - fm.stringWidth(status)) / 2f, by + 32);
			g.dispose();
		}
	}

	// ---------------------------------------------------------------- frame painting

	/** Background gradient, glow and a few still petals, rendered once per window size. */
	private BufferedImage background() {
		int w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
		if (background != null && background.getWidth() == w && background.getHeight() == h) return background;
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D b = Style.smooth(img.getGraphics());
		boolean max = (getExtendedState() & MAXIMIZED_BOTH) != 0;
		float arc = max || !translucent ? 0 : 20;
		b.clip(new RoundRectangle2D.Float(0, 0, w, h, arc, arc));
		b.setPaint(new GradientPaint(0, 0, Style.BG_TOP, 0, h, Style.BG_BOTTOM));
		b.fillRect(0, 0, w, h);
		b.setPaint(new RadialGradientPaint(w * 0.8f, -60, Math.max(w, h) * 0.55f, new float[] {0f, 1f},
				new Color[] {new Color(247, 168, 196, 40), new Color(247, 168, 196, 0)}));
		b.fillRect(0, 0, w, h);
		b.setPaint(new RadialGradientPaint(60, h + 80, 520, new float[] {0f, 1f},
				new Color[] {new Color(201, 120, 160, 30), new Color(201, 120, 160, 0)}));
		b.fillRect(0, 0, w, h);
		Random rnd = new Random(7);
		AffineTransform saved = b.getTransform();
		for (int i = 0; i < 26; i++) {
			b.translate(rnd.nextFloat() * w, rnd.nextFloat() * h);
			b.rotate(rnd.nextFloat() * 6.28);
			b.setColor(Style.alpha(Style.ACCENT, 0.05f + rnd.nextFloat() * 0.08f));
			b.fill(Blossom.petal(5 + rnd.nextFloat() * 8));
			b.setTransform(saved);
		}
		b.setColor(new Color(255, 255, 255, 18));
		b.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, arc, arc));
		b.dispose();
		background = img;
		return img;
	}

	private final class Root extends JComponent {
		@Override
		public void doLayout() {
			int w = getWidth(), h = getHeight();
			int i = 0;
			for (java.awt.Component c : getComponents()) {
				if (c instanceof Controls.WindowButton) {
					c.setBounds(w - 140 + i * 44, 9, 40, 34);
					i++;
				}
			}
			account.setBounds(w - 150 - account.preferredWidth(), 10, account.preferredWidth(), 32);
			refreshUpdate();
			int y = TITLE_H + 10;
			for (Map.Entry<String, Controls.NavButton> e : nav.entrySet()) {
				if (e.getKey().equals("_folder")) e.getValue().setBounds(0, h - 82, SIDE_W, 64);
				else { e.getValue().setBounds(0, y, SIDE_W, 64); y += 70; }
			}
			for (JComponent p : pages.values()) {
				p.setBounds(SIDE_W, TITLE_H, w - SIDE_W, h - TITLE_H);
				if (p.isVisible()) p.doLayout();
			}
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			g.drawImage(background(), 0, 0, null);
			// sidebar separator
			g.setColor(new Color(255, 255, 255, 12));
			g.fillRect(SIDE_W, TITLE_H, 1, getHeight() - TITLE_H - 16);
			// title
			Blossom.draw(g, 32, 26, 9, 1f, 0, 1f);
			g.setFont(Style.bold(13f));
			g.setColor(Style.TEXT);
			g.drawString("Cherry Blossom", 50, 31);
			int tw = g.getFontMetrics().stringWidth("Cherry Blossom");
			g.setFont(Style.medium(13f));
			g.setColor(Style.TEXT_MUTED);
			String crumb = switch (page) {
				case "versions" -> Lang.t("Versions");
				case "mods" -> Lang.t("Mods");
				case "settings" -> Lang.t("Settings");
				case "server" -> Lang.t("Server");
				case "friends" -> Lang.t("Friends");
				default -> Lang.t("Home");
			};
			g.drawString("/   " + crumb, 50 + tw + 12, 31);
			g.dispose();
		}

		@Override
		protected void paintChildren(Graphics g) {
			if (pageFade >= 1f) {
				super.paintChildren(g);
				return;
			}
			// fade the incoming page in
			Graphics2D g2 = (Graphics2D) g;
			for (java.awt.Component c : getComponents()) {
				if (!c.isVisible()) continue;
				Graphics2D cg = (Graphics2D) g2.create(c.getX(), c.getY(), c.getWidth(), c.getHeight());
				if (c == current) {
					cg.setComposite(AlphaComposite.SrcOver.derive(Style.easeOut(pageFade)));
					cg.translate(0, Math.round((1 - Style.easeOut(pageFade)) * 8));
				}
				c.paint(cg);
				cg.dispose();
			}
		}
	}

	/** Player name chip in the title bar; opens Settings. */
	private final class AccountChip extends Controls.Base {
		int preferredWidth() {
			return getFontMetrics(Style.bold(12.5f)).stringWidth(app.playerName()) + 60;
		}

		@Override void clicked(MouseEvent e) { LauncherWindow.this.show("settings"); }

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			g.setColor(new Color(255, 255, 255, Math.round(10 + hover * 12)));
			g.fill(new RoundRectangle2D.Float(0, 0, w, h, h, h));
			g.setPaint(new GradientPaint(4, 4, new Color(0xFBC2D6), 28, 28, Style.ACCENT_DEEP));
			g.fill(new Ellipse2D.Float(4, 4, h - 8, h - 8));
			String n = app.playerName();
			g.setFont(Style.display(14f));
			g.setColor(Style.ACCENT_INK);
			Controls.centerText(g, n.substring(0, 1).toUpperCase(), h / 2f, h / 2f);
			g.setFont(Style.bold(12.5f));
			g.setColor(Style.TEXT);
			FontMetrics fm = g.getFontMetrics();
			g.drawString(n, h + 4, (h - fm.getHeight()) / 2f + fm.getAscent());
			g.setColor(app.settings.signedIn() ? new Color(0xA8E6C1) : Style.TEXT_MUTED);
			g.fill(new Ellipse2D.Float(w - 16, h / 2f - 3, 6, 6));
			g.dispose();
			if (getWidth() != preferredWidth()) SwingUtilities.invokeLater(root::doLayout);
		}
	}

	// ---------------------------------------------------------------- window behaviour

	private void toggleMaximized() {
		if ((getExtendedState() & MAXIMIZED_BOTH) != 0 || restoreBounds != null) {
			setExtendedState(NORMAL);
			if (restoreBounds != null) setBounds(restoreBounds);
			restoreBounds = null;
		} else {
			restoreBounds = getBounds();
			setBounds(GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds());
		}
		background = null;
		getContentPane().doLayout();
		repaint();
	}

	/** Drag by the title bar, double-click it to maximise, drag any edge to resize. */
	private void installWindowDragAndResize() {
		Toolkit.getDefaultToolkit().addAWTEventListener(new java.awt.event.AWTEventListener() {
			Point start;
			Rectangle startBounds;
			int edges;
			boolean moving;

			private int edgesAt(Point p) {
				if (restoreBounds != null) return 0;
				int e = 0;
				if (p.x < EDGE) e |= 1;
				if (p.x > getWidth() - EDGE) e |= 2;
				if (p.y < EDGE) e |= 4;
				if (p.y > getHeight() - EDGE) e |= 8;
				return e;
			}

			@Override
			public void eventDispatched(AWTEvent ev) {
				if (!(ev instanceof MouseEvent me) || !(me.getSource() instanceof java.awt.Component src)) return;
				if (SwingUtilities.getWindowAncestor(src) != LauncherWindow.this) return;
				if (overlay.isOpen() || splash.isVisible()) return;
				Point p = SwingUtilities.convertPoint(src, me.getPoint(), getRootPane());
				switch (me.getID()) {
					case MouseEvent.MOUSE_MOVED -> {
						int e = edgesAt(p);
						Cursor c = switch (e) {
							case 1, 2 -> Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR);
							case 4, 8 -> Cursor.getPredefinedCursor(Cursor.N_RESIZE_CURSOR);
							case 5, 10 -> Cursor.getPredefinedCursor(Cursor.NW_RESIZE_CURSOR);
							case 6, 9 -> Cursor.getPredefinedCursor(Cursor.NE_RESIZE_CURSOR);
							default -> null;
						};
						if (c != null) root.setCursor(c);
						else if (src == root) root.setCursor(Cursor.getDefaultCursor());
					}
					case MouseEvent.MOUSE_PRESSED -> {
						edges = edgesAt(p);
						moving = edges == 0 && src == root && p.y < TITLE_H;
						start = me.getLocationOnScreen();
						startBounds = getBounds();
						if (moving && me.getClickCount() == 2) { toggleMaximized(); moving = false; }
					}
					case MouseEvent.MOUSE_DRAGGED -> {
						if (start == null) return;
						Point now = me.getLocationOnScreen();
						int dx = now.x - start.x, dy = now.y - start.y;
						if (moving) {
							if (restoreBounds != null) return;
							setLocation(startBounds.x + dx, startBounds.y + dy);
						} else if (edges != 0) {
							Rectangle r = new Rectangle(startBounds);
							int minW = getMinimumSize().width, minH = getMinimumSize().height;
							if ((edges & 2) != 0) r.width = Math.max(minW, startBounds.width + dx);
							if ((edges & 8) != 0) r.height = Math.max(minH, startBounds.height + dy);
							if ((edges & 1) != 0) { r.width = Math.max(minW, startBounds.width - dx); r.x = startBounds.x + startBounds.width - r.width; }
							if ((edges & 4) != 0) { r.height = Math.max(minH, startBounds.height - dy); r.y = startBounds.y + startBounds.height - r.height; }
							setBounds(r);
							background = null;
							getContentPane().doLayout();
						}
					}
					case MouseEvent.MOUSE_RELEASED -> { start = null; moving = false; edges = 0; }
					default -> {}
				}
			}
		}, AWTEvent.MOUSE_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK);
	}

	@Override
	public void gameStarted() {
		if (app.settings.hideWhilePlaying) {
			new Timer(3000, e -> {
				((Timer) e.getSource()).stop();
				if (app.running) { setVisible(false); timer.stop(); }
			}).start();
		}
	}

	@Override
	public void gameStopped(int code) {
		if (!isVisible()) {
			setVisible(true);
			lastTick = System.nanoTime();
			timer.start();
		}
		setState(NORMAL);
		toFront();
		app.changed();
	}

	private void refreshUpdate() {
		var u = app.updater;
		String label = switch (u.state) {
			case READY -> Lang.t("Update ") + u.latest + Lang.t(" ready: restart");
			case DOWNLOADING -> Lang.t("Downloading update ") + Math.round(u.progress * 100) + "%";
			default -> "";
		};
		update.setLabel(label);
		update.setVisible(!label.isEmpty());
		int w = update.preferredWidth();
		update.setBounds(account.getX() - w - 18, account.getY() + (account.getHeight() - 20) / 2, w, 20);
	}

	private void installUpdate() {
		if (app.updater.state != dev.cherryblossom.launcher.core.Updater.State.READY) return;
		if (app.running || app.busy) { app.setStatus(Lang.t("The update installs when you close the game and restart the launcher."), false); return; }
		if (app.updater.restart()) System.exit(0);
		else app.setStatus(Lang.t("Close and reopen Cherry Blossom Client to finish the update."), false);
	}

	private void openGameFolder() {
		try {
			Files.createDirectories(app.gameDir());
			Desktop.getDesktop().open(app.gameDir().toFile());
		} catch (Exception e) {
			app.setStatus(Lang.t("Couldn't open the folder: ") + e.getMessage(), true);
		}
	}

	// ---------------------------------------------------------------- dialogs

	private void addServerDialog(Runnable done) {
		Controls.Field field = new Controls.Field("", Lang.t("Server address, e.g. play.example.net"));
		Runnable add = () -> {
			String addr = field.getText().trim();
			if (addr.isEmpty()) return;
			app.settings.servers.add(addr + "|" + addr);
			app.settings.save();
			overlay.close();
			done.run();
		};
		field.addActionListener(e -> add.run());
		overlay.open(Lang.t("Add a server"), Lang.t("It appears in Quick join. Click it to launch your selected version straight into that server."),
				null, false, field, new Controls.PrimaryButton(Lang.t("Add server"), 13f, add), new Controls.GhostButton(Lang.t("Cancel"), overlay::close));
	}

	private void microsoftSignIn() {
		if (app.settings.microsoftClientId.isBlank()) {
			Controls.Field idField = new Controls.Field("", Lang.t("Azure application (client) ID"));
			Controls.PrimaryButton next = new Controls.PrimaryButton(Lang.t("Continue"), 13f, () -> {
				String id = idField.getText().trim();
				if (id.isEmpty()) return;
				app.settings.microsoftClientId = id;
				app.settings.save();
				startDeviceCode();
			});
			overlay.open(Lang.t("Sign in with Microsoft"),
					Lang.t("Microsoft sign-in needs an Azure app ID that Mojang has approved for Minecraft. ")
							+ Lang.t("Paste yours below (README.txt explains how). Or just play offline with a player name."),
					null, false, idField, next, new Controls.GhostButton(Lang.t("Cancel"), overlay::close));
			return;
		}
		startDeviceCode();
	}

	private void startDeviceCode() {
		AtomicBoolean cancelled = new AtomicBoolean();
		overlay.open(Lang.t("Sign in with Microsoft"), Lang.t("Contacting Microsoft…"), null, true, null, null,
				new Controls.GhostButton(Lang.t("Cancel"), () -> { cancelled.set(true); overlay.close(); }));
		Thread t = new Thread(() -> {
			try {
				MicrosoftAuth.DeviceCode code = MicrosoftAuth.start(app.settings.microsoftClientId);
				SwingUtilities.invokeLater(() -> {
					Controls.PrimaryButton open = new Controls.PrimaryButton(Lang.t("Copy code & open"), 13f, () -> {
						Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(code.userCode()), null);
						try { Desktop.getDesktop().browse(URI.create(code.verificationUri())); } catch (Exception ignored) {}
					});
					overlay.open(Lang.t("Sign in with Microsoft"),
							Lang.t("Go to ") + code.verificationUri().replace("https://", "") + Lang.t(" and enter this code. ")
									+ Lang.t("You sign in on Microsoft's own page; Cherry Blossom never sees your password."),
							code.userCode(), true, null, open,
							new Controls.GhostButton(Lang.t("Cancel"), () -> { cancelled.set(true); overlay.close(); }));
				});
				MicrosoftAuth.finish(app.settings.microsoftClientId, code, app.settings, cancelled::get);
				if (cancelled.get()) return;
				SwingUtilities.invokeLater(() -> {
					overlay.close();
					app.setStatus(Lang.t("Signed in as ") + app.settings.mcName + ".", false);
				});
			} catch (Exception e) {
				if (cancelled.get()) return;
				String msg = e.getMessage() == null ? e.toString() : e.getMessage();
				SwingUtilities.invokeLater(() -> overlay.open(Lang.t("Couldn't sign in"), msg, null, false, null,
						new Controls.PrimaryButton(Lang.t("OK"), 13f, overlay::close), null));
			}
		}, "cherry-msa");
		t.setDaemon(true);
		t.start();
	}
}
