package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.ServerManager;
import dev.cherryblossom.launcher.core.Settings;
import dev.cherryblossom.launcher.core.VersionList;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** Host a Minecraft server on this PC: pick a version and memory, start it, watch the console, join. */
final class ServerPage extends Controls.Page {
	private static final int PAD = 24, LEFT_W = 470;
	private static final String[] DIFF = {"peaceful", "easy", "normal", "hard"};
	private static final String[] MODES = {"survival", "creative", "adventure"};

	private final App app;
	private final ServerManager server;
	private final Body body;
	private final Controls.ScrollArea scroll;
	private final Controls.PrimaryButton startStop;
	private final Controls.GhostButton join;
	private final Controls.Link folder;
	private final Controls.Field command = new Controls.Field("", Lang.t("Type a command, e.g. op YourName, then Enter"));
	private List<String> releases = List.of();

	ServerPage(App app) {
		this.app = app;
		this.server = new ServerManager(app.installer, app.installer.base().resolve("servers"));
		Settings s = app.settings;
		if (s.serverRamMb < 1024) s.serverRamMb = ServerManager.suggestedRamMb(s.ramMb);
		if (s.serverMotd.isBlank()) s.serverMotd = app.playerName() + "'s Cherry server";
		this.body = new Body();
		this.scroll = new Controls.ScrollArea(body);
		put(scroll);
		startStop = put(new Controls.PrimaryButton(Lang.t("START SERVER"), 15f, this::toggle));
		join = put(new Controls.GhostButton(Lang.t("Join"), this::joinOwn).icon(Icons.SERVER));
		folder = put(new Controls.Link(Lang.t("Open server folder"), this::openFolder).color(Style.TEXT_DIM));
		command.addActionListener(e -> { server.command(command.getText()); command.setText(""); });
		put(command);
		server.onChange(() -> javax.swing.SwingUtilities.invokeLater(this::refresh));
		app.listen(this::refresh);
		refresh();
	}

	private VersionList.Version serverVersion() {
		VersionList vl = app.versions;
		if (vl == null) return null;
		VersionList.Version v = vl.find(app.settings.serverVersion);
		if (v == null || v.kind() != VersionList.Kind.RELEASE) {
			VersionList.Version sel = app.selected();
			v = sel != null && sel.kind() == VersionList.Kind.RELEASE ? sel : vl.find(vl.latestRelease());
		}
		return v;
	}

	private void refresh() {
		VersionList vl = app.versions;
		if (vl != null && releases.isEmpty()) {
			List<String> ids = new ArrayList<>();
			for (VersionList.Family f : vl.families())
				if (f.kind() == VersionList.Kind.RELEASE) for (VersionList.Version v : f.versions()) ids.add(v.id());
			ids.removeIf(id -> id.startsWith("1.0") || id.startsWith("1.1") && id.length() == 3 || id.startsWith("1.2.") && !id.equals("1.2.5"));
			releases = ids;
		}
		VersionList.Version v = serverVersion();
		if (v != null) body.version.setItems(releases, Math.max(0, releases.indexOf(v.id())));
		ServerManager.State st = server.state();
		boolean running = st != ServerManager.State.STOPPED;
		startStop.setLabel(st == ServerManager.State.STOPPING ? Lang.t("STOPPING") : running ? Lang.t("STOP SERVER") : Lang.t("START SERVER"));
		startStop.setActive(st != ServerManager.State.STOPPING && st != ServerManager.State.PREPARING);
		join.setActive(st == ServerManager.State.ONLINE && !app.busy && !app.running);
		command.setEnabled(st == ServerManager.State.STARTING || st == ServerManager.State.ONLINE);
		body.version.setActive(!running);
		repaint();
	}

	private void toggle() {
		if (server.state() != ServerManager.State.STOPPED) {
			server.stop();
			return;
		}
		Settings s = app.settings;
		if (!s.serverEula) {
			app.setStatus(Lang.t("Accept the EULA first."), true);
			body.status = Lang.t("Accept the EULA first.");
			repaint();
			return;
		}
		VersionList.Version v = serverVersion();
		if (v == null) return;
		s.serverVersion = v.id();
		s.save();
		server.start(v, new ServerManager.Options(s.serverRamMb, s.serverMotd, s.serverMaxPlayers, s.serverPort,
				s.serverDifficulty, s.serverGamemode, s.serverOnlineMode, s.serverPvp), (text, f) -> {
			body.status = text;
			javax.swing.SwingUtilities.invokeLater(this::repaint);
		});
	}

	private void joinOwn() {
		String id = server.runningVersion();
		if (id == null) return;
		app.select(id);
		app.launch("localhost:" + app.settings.serverPort);
	}

	private void openFolder() {
		VersionList.Version v = serverVersion();
		if (v == null) return;
		try {
			Files.createDirectories(server.dir(v.id()));
			Desktop.getDesktop().open(server.dir(v.id()).toFile());
		} catch (Exception e) {
			app.setStatus(Lang.t("Couldn't open the folder: ") + e.getMessage(), true);
		}
	}

	private int consoleX() { return PAD + LEFT_W + 16; }

	@Override
	public void doLayout() {
		int w = getWidth(), h = getHeight();
		scroll.setBounds(0, 0, PAD + LEFT_W + 8, h - 96);
		scroll.doLayout();
		int gp = Controls.PrimaryButton.GLOW;
		startStop.setBounds(PAD - gp, h - 82 - gp, 250 + gp * 2, 52 + gp * 2);
		join.setBounds(PAD + 262, h - 78, 110, 44);
		folder.setBounds(PAD + 384, h - 66, folder.preferredWidth(), 20);
		int cx = consoleX(), cw = w - cx - PAD;
		command.setBounds(cx + 16, h - 30 - 46, cw - 32, 42);
	}

	@Override
	protected void paintComponent(Graphics g0) {
		Graphics2D g = Style.smooth(g0);
		int w = getWidth(), h = getHeight();
		int cx = consoleX(), cw = w - cx - PAD, top = 16;
		Style.card(g, cx, top, cw, h - top - 16);

		ServerManager.State st = server.state();
		String label = switch (st) {
			case STOPPED -> Lang.t("Stopped");
			case PREPARING -> Lang.t("Preparing");
			case STARTING -> Lang.t("Starting");
			case ONLINE -> Lang.t("Online");
			case STOPPING -> Lang.t("Stopping");
		};
		Color dot = st == ServerManager.State.ONLINE ? new Color(0xA8E6C1) : st == ServerManager.State.STOPPED ? Style.TEXT_MUTED : new Color(0xF3D98B);
		g.setFont(Style.bold(15f));
		g.setColor(Style.TEXT);
		g.drawString(Lang.t("Console"), cx + 18, top + 30);
		int lx = cx + 18 + g.getFontMetrics().stringWidth(Lang.t("Console")) + 16;
		g.setFont(Style.medium(12.5f));
		int pw = g.getFontMetrics().stringWidth(label) + 30;
		g.setColor(new Color(255, 255, 255, 14));
		g.fill(new RoundRectangle2D.Float(lx, top + 13, pw, 24, 24, 24));
		g.setColor(dot);
		g.fill(new Ellipse2D.Float(lx + 10, top + 22, 7, 7));
		g.setColor(Style.TEXT);
		g.drawString(label, lx + 22, top + 30);

		List<String> players = server.players();
		g.setFont(Style.regular(12f));
		g.setColor(Style.TEXT_MUTED);
		String who = st == ServerManager.State.ONLINE
				? (players.isEmpty() ? Lang.t("No one online yet") : players.size() + " online: " + String.join(", ", players))
				+ "   ·   " + Lang.t("Address for this PC: localhost:") + app.settings.serverPort
				: body.status == null ? "" : body.status;
		FontMetrics wf = g.getFontMetrics();
		while (wf.stringWidth(who) > cw - 40 && who.length() > 10) who = who.substring(0, who.length() - 4) + "…";
		g.drawString(who, cx + 18, top + 58);

		// console text
		int boxY = top + 72, boxH = h - 16 - boxY - 66;
		g.setColor(new Color(10, 5, 8, 120));
		g.fill(new RoundRectangle2D.Float(cx + 16, boxY, cw - 32, boxH, 14, 14));
		g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		FontMetrics fm = g.getFontMetrics();
		List<String> lines = server.console();
		int lineH = fm.getHeight();
		int max = Math.max(1, (boxH - 16) / lineH);
		int start = Math.max(0, lines.size() - max);
		int y = boxY + 10 + fm.getAscent();
		Graphics2D clip = (Graphics2D) g.create();
		clip.clip(new RoundRectangle2D.Float(cx + 16, boxY, cw - 32, boxH, 14, 14));
		if (lines.isEmpty()) {
			clip.setColor(Style.TEXT_MUTED);
			clip.drawString(Lang.t("The server log will show up here."), cx + 28, y);
		}
		for (int i = start; i < lines.size(); i++) {
			String line = lines.get(i);
			clip.setColor(line.startsWith(">") ? Style.ACCENT : line.contains("WARN") ? new Color(0xF3D98B)
					: line.contains("ERROR") ? Style.DANGER : new Color(0xD8C8D0));
			clip.drawString(line, cx + 28, y);
			y += lineH;
		}
		clip.dispose();
		g.dispose();
	}

	/** The scrolling settings column. */
	private final class Body extends Controls.Page {
		final Controls.Dropdown version;
		private final Controls.Slider ram;
		private final Controls.Field motd = new Controls.Field("", Lang.t("Server name (shown in the server list)"));
		private final Controls.Field players = new Controls.Field("", Lang.t("Max players"));
		private final Controls.Field port = new Controls.Field("", Lang.t("Port"));
		private final Controls.Segmented difficulty, gamemode;
		private final Controls.Toggle online, pvp, eula;
		volatile String status;
		private int height = 900;

		Body() {
			Settings s = app.settings;
			version = put(new Controls.Dropdown(i -> {
				if (i < releases.size()) { s.serverVersion = releases.get(i); s.save(); ServerPage.this.repaint(); }
			}));
			ram = put(new Controls.Slider(1024, Settings.maxRamMb(), 512, s.serverRamMb,
					mb -> String.format("%.1f GB", mb / 1024f), mb -> { s.serverRamMb = mb; s.save(); }));
			motd.setText(s.serverMotd);
			motd.onChange(() -> { s.serverMotd = motd.getText(); s.save(); });
			put(motd);
			players.setText(Integer.toString(s.serverMaxPlayers));
			players.onChange(() -> { s.serverMaxPlayers = parse(players.getText(), 10, 1, 500); s.save(); });
			put(players);
			port.setText(Integer.toString(s.serverPort));
			port.onChange(() -> { s.serverPort = parse(port.getText(), 25565, 1024, 65535); s.save(); });
			put(port);
			difficulty = put(new Controls.Segmented(new String[] {Lang.t("Peaceful"), Lang.t("Easy"), Lang.t("Normal"), Lang.t("Hard")},
					Math.max(0, java.util.Arrays.asList(DIFF).indexOf(s.serverDifficulty)), i -> { s.serverDifficulty = DIFF[i]; s.save(); }));
			gamemode = put(new Controls.Segmented(new String[] {Lang.t("Survival"), Lang.t("Creative"), Lang.t("Adventure")},
					Math.max(0, java.util.Arrays.asList(MODES).indexOf(s.serverGamemode)), i -> { s.serverGamemode = MODES[i]; s.save(); }));
			online = put(new Controls.Toggle(Lang.t("Microsoft accounts only"), Lang.t("Off lets offline players join. Keep it on for public servers."),
					s.serverOnlineMode, v -> { s.serverOnlineMode = v; s.save(); }));
			pvp = put(new Controls.Toggle(Lang.t("PvP"), Lang.t("Players can hurt each other"), s.serverPvp, v -> { s.serverPvp = v; s.save(); }));
			eula = put(new Controls.Toggle(Lang.t("I agree to the Minecraft EULA"), Lang.t("Required by Mojang to run a server. Read it at aka.ms/MinecraftEULA"),
					s.serverEula, v -> { s.serverEula = v; s.save(); status = null; ServerPage.this.repaint(); }));
		}

		private int parse(String t, int def, int min, int max) {
			try { return Math.max(min, Math.min(max, Integer.parseInt(t.trim()))); } catch (Exception e) { return def; }
		}

		@Override
		public Dimension getPreferredSize() { return new Dimension(getWidth(), height); }

		@Override
		public void doLayout() {
			int x = PAD + 20, iw = LEFT_W - 40, y = 16 + 92;
			version.setBounds(x, y + 20, iw, 42); y += 20 + 42 + 18;
			ram.setBounds(x, y, iw, 58); y += 58 + 30;
			motd.setBounds(x, y, iw, 42); y += 42 + 12;
			players.setBounds(x, y, (iw - 12) / 2, 42);
			port.setBounds(x + (iw - 12) / 2 + 12, y, iw - (iw - 12) / 2 - 12, 42); y += 42 + 18;
			difficulty.setBounds(x, y + 20, iw, 38); y += 20 + 38 + 14;
			gamemode.setBounds(x, y + 20, iw, 38); y += 20 + 38 + 22;
			online.setBounds(x, y, iw, 40); y += 52;
			pvp.setBounds(x, y, iw, 40); y += 52;
			eula.setBounds(x, y, iw, 40); y += 52;
			height = y + 20;
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			Style.card(g, PAD, 16, LEFT_W, height - 16);
			g.setFont(Style.display(24f));
			g.setColor(Style.TEXT);
			g.drawString(Lang.t("Your own server"), PAD + 20, 50);
			g.setFont(Style.regular(11.5f));
			g.setColor(Style.TEXT_MUTED);
			FontMetrics fm = g.getFontMetrics();
			int ty = 70;
			for (String line : Style.wrap(Lang.t("Runs on this PC. Friends on your Wi-Fi can join with your local IP; for others, forward the port on your router."), fm, LEFT_W - 40)) {
				g.drawString(line, PAD + 20, ty);
				ty += 15;
			}
			Style.label(g, Lang.t("VERSION"), PAD + 20, version.getY() - 8);
			g.setFont(Style.regular(11.5f));
			g.setColor(Style.TEXT_MUTED);
			g.drawString(Lang.t("Suggested for this PC: ") + String.format("%.1f GB", ServerManager.suggestedRamMb(app.settings.ramMb) / 1024f)
					+ "  ·  " + Lang.count(dev.cherryblossom.launcher.core.Presets.cpuThreads(), "CPU thread", "CPU threads", "wątek", "wątki", "wątków"),
					PAD + 20, ram.getY() + 76);
			Style.label(g, Lang.t("DIFFICULTY"), PAD + 20, difficulty.getY() - 8);
			Style.label(g, Lang.t("GAME MODE"), PAD + 20, gamemode.getY() - 8);
			g.dispose();
		}
	}
}
