package dev.cherryblossom.launcher.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Colours, fonts and drawing helpers. One place to tune the whole look. */
public final class Style {
	private Style() {}

	public static final Color BG_TOP = new Color(0x1C1217);
	public static final Color BG_BOTTOM = new Color(0x26141D);
	public static final Color ACCENT = new Color(0xF7A8C4);
	public static final Color ACCENT_DEEP = new Color(0xE9789E);
	public static final Color ACCENT_INK = new Color(0x2B1420);
	public static final Color TEXT = new Color(0xF8EEF2);
	public static final Color TEXT_DIM = new Color(0xBDA7B1);
	public static final Color TEXT_MUTED = new Color(0x85707A);
	public static final Color CARD = new Color(255, 255, 255, 12);
	public static final Color CARD_BORDER = new Color(255, 255, 255, 20);
	public static final Color FIELD = new Color(255, 255, 255, 14);
	public static final Color FIELD_FOCUS = new Color(255, 255, 255, 22);
	public static final Color DANGER = new Color(0xF29B9B);

	private static final Map<String, Font> BASE = new HashMap<>();

	private static Font base(String file, String fallback, int style) {
		return BASE.computeIfAbsent(file, f -> {
			try (InputStream in = Style.class.getResourceAsStream("/fonts/" + f)) {
				return Font.createFont(Font.TRUETYPE_FONT, in);
			} catch (Exception e) {
				return new Font(fallback, style, 12);
			}
		});
	}

	public static Font display(float size) {
		return base("DisplaySerif.ttf", Font.SERIF, Font.PLAIN).deriveFont(size);
	}

	public static Font regular(float size) {
		return base("Sans-Regular.ttf", Font.SANS_SERIF, Font.PLAIN).deriveFont(size);
	}

	public static Font medium(float size) {
		return base("Sans-Medium.ttf", Font.SANS_SERIF, Font.PLAIN).deriveFont(size);
	}

	public static Font bold(float size) {
		return base("Sans-Bold.ttf", Font.SANS_SERIF, Font.BOLD).deriveFont(size);
	}

	public static Graphics2D smooth(java.awt.Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
		g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		return g2;
	}

	public static Color alpha(Color c, float a) {
		a = Math.max(0f, Math.min(1f, a));
		return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.round(c.getAlpha() * a));
	}

	public static Color mix(Color a, Color b, float t) {
		t = Math.max(0f, Math.min(1f, t));
		return new Color(
				Math.round(a.getRed() + (b.getRed() - a.getRed()) * t),
				Math.round(a.getGreen() + (b.getGreen() - a.getGreen()) * t),
				Math.round(a.getBlue() + (b.getBlue() - a.getBlue()) * t),
				Math.round(a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t));
	}

	/** A soft glassy card, the base of every panel. */
	public static void card(Graphics2D g, float x, float y, float w, float h) {
		java.awt.geom.RoundRectangle2D r = new java.awt.geom.RoundRectangle2D.Float(x, y, w, h, 22, 22);
		g.setColor(CARD);
		g.fill(r);
		g.setColor(CARD_BORDER);
		g.draw(new java.awt.geom.RoundRectangle2D.Float(x + 0.5f, y + 0.5f, w - 1, h - 1, 22, 22));
	}

	/** Small spaced-out uppercase label. */
	public static void label(Graphics2D g, String s, float x, float y) {
		g.setFont(bold(11f));
		g.setColor(TEXT_DIM);
		tracked(g, s, x, y, 1.4f);
	}

	/** Wraps text into lines that fit {@code width}. */
	public static java.util.List<String> wrap(String text, FontMetrics fm, int width) {
		java.util.List<String> lines = new java.util.ArrayList<>();
		for (String para : text.split("\n")) {
			StringBuilder line = new StringBuilder();
			for (String word : para.split(" ")) {
				String t = line.isEmpty() ? word : line + " " + word;
				if (fm.stringWidth(t) > width && !line.isEmpty()) {
					lines.add(line.toString());
					line = new StringBuilder(word);
				} else {
					line = new StringBuilder(t);
				}
			}
			lines.add(line.toString());
		}
		return lines;
	}

	/** Draw text with letter spacing, for the small uppercase labels. */
	public static void tracked(Graphics2D g, String s, float x, float y, float tracking) {
		FontMetrics fm = g.getFontMetrics();
		for (int i = 0; i < s.length(); i++) {
			String ch = String.valueOf(s.charAt(i));
			g.drawString(ch, x, y);
			x += fm.stringWidth(ch) + tracking;
		}
	}

	public static float easeOut(float t) {
		t = Math.max(0f, Math.min(1f, t));
		float inv = 1f - t;
		return 1f - inv * inv * inv;
	}

	public static float easeInOut(float t) {
		t = Math.max(0f, Math.min(1f, t));
		return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;
	}

	/** Frame-rate independent approach, used for hover fades. */
	public static float approach(float current, float target, float speed, float dt) {
		return current + (target - current) * (1f - (float) Math.exp(-speed * dt));
	}
}
