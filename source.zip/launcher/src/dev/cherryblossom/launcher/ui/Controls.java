package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import javax.swing.JComponent;
import javax.swing.JLayeredPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;

/** The custom controls the launcher is built from. All hand-drawn, all animated the same way. */
public final class Controls {
	private Controls() {}

	public interface Animated {
		void tick(float dt);
	}

	/** Every on-screen animated control registers itself here; one timer ticks them all. */
	public static final class Anim {
		private static final Set<Animated> LIVE = Collections.newSetFromMap(new IdentityHashMap<>());

		static void add(Animated a) { LIVE.add(a); }

		static void remove(Animated a) { LIVE.remove(a); }

		public static void tickAll(float dt) {
			for (Animated a : new ArrayList<>(LIVE)) a.tick(dt);
		}
	}

	/** Moves {@code v} towards {@code target}; returns the new value. */
	static float ease(float v, float target, float speed, float dt) {
		float n = Style.approach(v, target, speed, dt);
		return Math.abs(n - target) < 0.002f ? target : n;
	}

	/** Shared hover/press tracking. Repaints only while something is actually moving. */
	abstract static class Base extends JComponent implements Animated {
		boolean hovered, pressed;
		float hover, press;
		boolean enabledState = true;

		Base() {
			setOpaque(false);
			setFocusable(false);
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			MouseAdapter m = new MouseAdapter() {
				@Override public void mouseEntered(MouseEvent e) { hovered = true; }
				@Override public void mouseExited(MouseEvent e) { hovered = false; pressed = false; }
				@Override public void mousePressed(MouseEvent e) { if (enabledState && e.getButton() == MouseEvent.BUTTON1) pressed = true; }
				@Override public void mouseReleased(MouseEvent e) {
					boolean fire = pressed && hovered && enabledState;
					pressed = false;
					if (fire) clicked(e);
					else if (e.getButton() == MouseEvent.BUTTON3 && hovered) rightClicked(e);
				}
				@Override public void mouseDragged(MouseEvent e) { dragged(e); }
				@Override public void mouseMoved(MouseEvent e) { moved(e); }
			};
			addMouseListener(m);
			addMouseMotionListener(m);
		}

		@Override public void addNotify() { super.addNotify(); Anim.add(this); }

		@Override public void removeNotify() { Anim.remove(this); super.removeNotify(); }

		void clicked(MouseEvent e) {}

		void rightClicked(MouseEvent e) {}

		void dragged(MouseEvent e) {}

		void moved(MouseEvent e) {}

		public void setActive(boolean on) {
			enabledState = on;
			setCursor(Cursor.getPredefinedCursor(on ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
			repaint();
		}

		@Override
		public void tick(float dt) {
			float h = ease(hover, hovered && enabledState ? 1 : 0, 14, dt);
			float p = ease(press, pressed ? 1 : 0, 22, dt);
			if (h != hover || p != press) {
				hover = h;
				press = p;
				repaint();
			}
		}
	}

	static float trackedWidth(FontMetrics fm, String s, float tracking) {
		return fm.stringWidth(s) + tracking * Math.max(0, s.length() - 1);
	}

	static void centerText(Graphics2D g, String s, float cx, float cy) {
		FontMetrics fm = g.getFontMetrics();
		g.drawString(s, cx - fm.stringWidth(s) / 2f, cy - fm.getHeight() / 2f + fm.getAscent());
	}

	// ---------------------------------------------------------------- buttons

	/** Pink primary button. Large ones carry a soft glow inside a reserved margin. */
	public static final class PrimaryButton extends Base {
		public static final int GLOW = 14;
		private String label;
		private String sub;
		private final Runnable action;
		private final float fontSize;

		public PrimaryButton(String label, float fontSize, Runnable action) {
			this.label = label;
			this.action = action;
			this.fontSize = fontSize;
		}

		public void setLabel(String label) { this.label = label; repaint(); }

		public void setSub(String sub) { this.sub = sub; repaint(); }

		public String label() { return label; }

		@Override void clicked(MouseEvent e) { action.run(); }

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int pad = fontSize > 14 ? GLOW : 0;
			int w = getWidth() - pad * 2, h = getHeight() - pad * 2;
			g.translate(pad, pad);
			float shrink = press * 1.5f;
			float arc = Math.min(h, 22);
			RoundRectangle2D r = new RoundRectangle2D.Float(shrink, shrink, w - shrink * 2, h - shrink * 2, arc, arc);
			if (enabledState) {
				if (pad > 0) {
					for (int i = GLOW; i >= 1; i -= 2) {
						float a = (0.022f + hover * 0.02f) * (1f - i / (float) (GLOW + 2));
						g.setColor(Style.alpha(Style.ACCENT, a * 2.2f));
						g.fill(new RoundRectangle2D.Float(-i, -i + 4, w + i * 2, h + i * 2, arc + i * 2, arc + i * 2));
					}
				}
				Color top = Style.mix(new Color(0xFBC2D6), new Color(0xFFD3E2), hover);
				Color bottom = Style.mix(Style.ACCENT_DEEP, new Color(0xF28DB0), hover);
				g.setPaint(new GradientPaint(0, 0, top, 0, h, bottom));
			} else {
				g.setColor(new Color(255, 255, 255, 26));
			}
			g.fill(r);
			g.setFont(Style.bold(fontSize));
			FontMetrics fm = g.getFontMetrics();
			Color ink = enabledState ? Style.ACCENT_INK : Style.TEXT_DIM;
			float tracking = fontSize > 14 ? 1.6f : 0.4f;
			float tw = trackedWidth(fm, label, tracking);
			float ty = (h - fm.getHeight()) / 2f + fm.getAscent();
			if (sub != null && fontSize > 14) ty -= 7;
			g.setColor(ink);
			Style.tracked(g, label, (w - tw) / 2f, ty, tracking);
			if (sub != null && fontSize > 14) {
				g.setFont(Style.medium(11.5f));
				FontMetrics sf = g.getFontMetrics();
				g.setColor(Style.alpha(ink, 0.75f));
				g.drawString(sub, (w - sf.stringWidth(sub)) / 2f, ty + 17);
			}
			g.dispose();
		}
	}

	/** Quiet outlined button. */
	public static final class GhostButton extends Base {
		private String label;
		private final Runnable action;
		private Icons.Glyph icon;

		public GhostButton(String label, Runnable action) {
			this.label = label;
			this.action = action;
		}

		public GhostButton icon(Icons.Glyph icon) { this.icon = icon; return this; }

		public void setLabel(String label) { this.label = label; repaint(); }

		@Override void clicked(MouseEvent e) { action.run(); }

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			RoundRectangle2D r = new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, Math.min(h, 14), Math.min(h, 14));
			g.setColor(new Color(255, 255, 255, Math.round(10 + hover * 14)));
			g.fill(r);
			g.setColor(Style.mix(Style.CARD_BORDER, Style.alpha(Style.ACCENT, 0.6f), hover));
			g.draw(r);
			g.setFont(Style.medium(13f));
			FontMetrics fm = g.getFontMetrics();
			Color c = Style.mix(Style.TEXT_DIM, Style.TEXT, hover);
			int tw = fm.stringWidth(label) + (icon != null ? 22 : 0);
			float x = (w - tw) / 2f;
			if (icon != null) {
				icon.paint(g, x, h / 2f - 8, 16, c);
				x += 22;
			}
			g.setColor(c);
			g.drawString(label, x, (h - fm.getHeight()) / 2f + fm.getAscent());
			g.dispose();
		}
	}

	/** Underline-on-hover text link. */
	public static final class Link extends Base {
		private String label;
		private final Runnable action;
		private Color color = Style.ACCENT;
		private float size = 12.5f;

		public Link(String label, Runnable action) {
			this.label = label;
			this.action = action;
		}

		public void setLabel(String label) { this.label = label; repaint(); }

		public Link color(Color c) { this.color = c; return this; }

		public Link size(float s) { this.size = s; return this; }

		public int preferredWidth() { return getFontMetrics(Style.medium(size)).stringWidth(label) + 2; }

		@Override void clicked(MouseEvent e) { action.run(); }

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			g.setFont(Style.medium(size));
			FontMetrics fm = g.getFontMetrics();
			float y = (getHeight() - fm.getHeight()) / 2f + fm.getAscent();
			g.setColor(Style.mix(Style.alpha(color, 0.85f), color, hover));
			g.drawString(label, 0, y);
			int lw = Math.round(fm.stringWidth(label) * hover);
			if (lw > 0) g.fillRect(0, Math.round(y + 3), lw, 1);
			g.dispose();
		}
	}

	/** Window control: minimise, maximise or close. */
	public static final class WindowButton extends Base {
		public enum Kind { MIN, MAX, CLOSE }

		private final Kind kind;
		private final Runnable action;

		public WindowButton(Kind kind, Runnable action) {
			this.kind = kind;
			this.action = action;
		}

		@Override void clicked(MouseEvent e) { action.run(); }

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			if (hover > 0.01f) {
				g.setColor(kind == Kind.CLOSE ? Style.alpha(new Color(0xE0607E), hover * 0.85f) : new Color(255, 255, 255, Math.round(hover * 18)));
				g.fill(new RoundRectangle2D.Float(4, 4, w - 8, h - 8, 10, 10));
			}
			g.setColor(Style.mix(Style.TEXT_DIM, Color.WHITE, hover));
			g.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
			float cx = w / 2f, cy = h / 2f, s = 5f;
			switch (kind) {
				case CLOSE -> {
					g.draw(new Line2D.Float(cx - s, cy - s, cx + s, cy + s));
					g.draw(new Line2D.Float(cx + s, cy - s, cx - s, cy + s));
				}
				case MIN -> g.draw(new Line2D.Float(cx - s, cy, cx + s, cy));
				case MAX -> g.draw(new RoundRectangle2D.Float(cx - s, cy - s, s * 2, s * 2, 3, 3));
			}
			g.dispose();
		}
	}

	/** A sidebar item: icon with a small label underneath. */
	public static final class NavButton extends Base {
		private final Icons.Glyph icon;
		private final String label;
		private final Runnable action;
		private boolean selected;
		private float sel;

		public NavButton(Icons.Glyph icon, String label, Runnable action) {
			this.icon = icon;
			this.label = label;
			this.action = action;
		}

		public void setSelected(boolean s) { selected = s; }

		@Override void clicked(MouseEvent e) { action.run(); }

		@Override
		public void tick(float dt) {
			super.tick(dt);
			float n = ease(sel, selected ? 1 : 0, 14, dt);
			if (n != sel) { sel = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			float bg = Math.max(sel, hover * 0.6f);
			if (bg > 0.01f) {
				g.setColor(new Color(255, 255, 255, Math.round(6 + 10 * bg)));
				g.fill(new RoundRectangle2D.Float(8, 2, w - 16, h - 4, 14, 14));
			}
			if (sel > 0.01f) {
				g.setColor(Style.alpha(Style.ACCENT, sel));
				float bh = (h - 24) * sel;
				g.fill(new RoundRectangle2D.Float(0, (h - bh) / 2f, 3, bh, 3, 3));
			}
			Color c = Style.mix(Style.mix(Style.TEXT_MUTED, Style.TEXT_DIM, hover), Style.ACCENT, sel);
			icon.paint(g, w / 2f - 10, 10, 20, c);
			g.setFont(Style.medium(10.5f));
			g.setColor(Style.mix(Style.mix(Style.TEXT_MUTED, Style.TEXT_DIM, hover), Style.TEXT, sel));
			centerText(g, label, w / 2f, h - 14);
			g.dispose();
		}
	}

	/** Pill used for filters and quick-join servers. */
	public static final class Chip extends Base {
		private String label;
		private String sub;
		private boolean selected;
		private float sel;
		private final Runnable action;
		private Runnable onRemove;
		private Icons.Glyph icon;

		public Chip(String label, Runnable action) {
			this.label = label;
			this.action = action;
		}

		public Chip sub(String s) { this.sub = s; return this; }

		public Chip icon(Icons.Glyph i) { this.icon = i; return this; }

		public Chip removable(Runnable r) { this.onRemove = r; return this; }

		public void setSelected(boolean s) { selected = s; repaint(); }

		public boolean selected() { return selected; }

		public int preferredWidth() {
			FontMetrics fm = getFontMetrics(Style.medium(12.5f));
			int w = fm.stringWidth(label);
			if (sub != null) w = Math.max(w, getFontMetrics(Style.regular(11f)).stringWidth(sub));
			return w + 28 + (icon != null ? 24 : 0);
		}

		@Override void clicked(MouseEvent e) { action.run(); }

		@Override void rightClicked(MouseEvent e) { if (onRemove != null) onRemove.run(); }

		@Override
		public void tick(float dt) {
			super.tick(dt);
			float n = ease(sel, selected ? 1 : 0, 14, dt);
			if (n != sel) { sel = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			float arc = sub != null ? 16 : h;
			RoundRectangle2D r = new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, arc, arc);
			g.setColor(Style.mix(new Color(255, 255, 255, Math.round(12 + hover * 12)), Style.alpha(Style.ACCENT, 0.9f), sel));
			g.fill(r);
			if (sel < 0.5f) {
				g.setColor(Style.mix(Style.CARD_BORDER, Style.alpha(Style.ACCENT, 0.5f), hover));
				g.draw(r);
			}
			float x = 14;
			Color ink = Style.mix(Style.TEXT, Style.ACCENT_INK, sel);
			if (icon != null) {
				icon.paint(g, x - 2, h / 2f - 9, 18, Style.mix(Style.ACCENT, Style.ACCENT_INK, sel));
				x += 24;
			}
			if (sub == null) {
				g.setFont(Style.medium(12.5f));
				FontMetrics fm = g.getFontMetrics();
				g.setColor(ink);
				g.drawString(label, icon == null ? (w - fm.stringWidth(label)) / 2f : x, (h - fm.getHeight()) / 2f + fm.getAscent());
			} else {
				g.setFont(Style.bold(12.5f));
				g.setColor(ink);
				g.drawString(label, x, h / 2f - 2);
				g.setFont(Style.regular(11f));
				g.setColor(Style.mix(Style.TEXT_MUTED, Style.alpha(Style.ACCENT_INK, 0.8f), sel));
				g.drawString(sub, x, h / 2f + 13);
			}
			g.dispose();
		}
	}

	/** Two or three options side by side, e.g. Fabric / Vanilla. */
	public static final class Segmented extends Base {
		private final String[] options;
		private final boolean[] enabled;
		private int selected;
		private float shown;
		private final IntConsumer onChange;

		public Segmented(String[] options, int selected, IntConsumer onChange) {
			this.options = options;
			this.enabled = new boolean[options.length];
			java.util.Arrays.fill(enabled, true);
			this.selected = selected;
			this.shown = selected;
			this.onChange = onChange;
		}

		public void setEnabled(int i, boolean on) { enabled[i] = on; repaint(); }

		public void setSelected(int i) { selected = i; repaint(); }

		public int selected() { return selected; }

		@Override void clicked(MouseEvent e) {
			int i = Math.min(options.length - 1, e.getX() * options.length / Math.max(1, getWidth()));
			if (enabled[i] && i != selected) {
				selected = i;
				onChange.accept(i);
			}
		}

		@Override
		public void tick(float dt) {
			super.tick(dt);
			float n = ease(shown, selected, 16, dt);
			if (n != shown) { shown = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			g.setColor(new Color(255, 255, 255, 14));
			g.fill(new RoundRectangle2D.Float(0, 0, w, h, 14, 14));
			float sw = w / (float) options.length;
			g.setColor(Style.ACCENT);
			g.fill(new RoundRectangle2D.Float(shown * sw + 3, 3, sw - 6, h - 6, 11, 11));
			g.setFont(Style.bold(12.5f));
			for (int i = 0; i < options.length; i++) {
				float t = Math.max(0, 1 - Math.abs(shown - i));
				Color c = enabled[i] ? Style.mix(Style.TEXT_DIM, Style.ACCENT_INK, t) : Style.alpha(Style.TEXT_MUTED, 0.6f);
				g.setColor(c);
				centerText(g, options[i], i * sw + sw / 2f, h / 2f);
			}
			g.dispose();
		}
	}

	/** Animated on/off switch with a title and a quieter description. */
	public static final class Toggle extends Base {
		private final String title;
		private final String description;
		private final Consumer<Boolean> onChange;
		private boolean on;
		private float knob;

		public Toggle(String title, String description, boolean on, Consumer<Boolean> onChange) {
			this.title = title;
			this.description = description;
			this.on = on;
			this.knob = on ? 1 : 0;
			this.onChange = onChange;
		}

		public void setOn(boolean on) { this.on = on; repaint(); }

		public boolean isOn() { return on; }

		@Override void clicked(MouseEvent e) {
			on = !on;
			onChange.accept(on);
		}

		@Override
		public void tick(float dt) {
			super.tick(dt);
			float n = ease(knob, on ? 1 : 0, 16, dt);
			if (n != knob) { knob = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth();
			g.setFont(Style.medium(13.5f));
			FontMetrics fm = g.getFontMetrics();
			g.setColor(enabledState ? Style.TEXT : Style.TEXT_MUTED);
			g.drawString(title, 0, fm.getAscent());
			if (description != null) {
				g.setFont(Style.regular(11.5f));
				g.setColor(Style.TEXT_MUTED);
				g.drawString(description, 0, fm.getAscent() + 18);
			}
			int tw = 38, th = 22, tx = w - tw;
			Color track = Style.mix(new Color(255, 255, 255, 30 + Math.round(hover * 12)), Style.ACCENT_DEEP, knob);
			if (!enabledState) track = Style.alpha(track, 0.4f);
			g.setColor(track);
			g.fill(new RoundRectangle2D.Float(tx, 0, tw, th, th, th));
			float kx = tx + 3 + knob * (tw - th);
			g.setColor(Style.mix(new Color(0xD9C6CE), Color.WHITE, knob));
			g.fill(new Ellipse2D.Float(kx, 3, th - 6, th - 6));
			g.dispose();
		}
	}

	/** Memory slider. Snaps to half-gigabytes; arrow keys nudge it. */
	public static final class Slider extends Base {
		private final int min, max, step;
		private int value;
		private float shown;
		private final Consumer<Integer> onChange;
		private final IntFunction<String> format;
		private boolean dragging;
		private static final int KNOB = 18;

		public Slider(int min, int max, int step, int value, IntFunction<String> format, Consumer<Integer> onChange) {
			this.min = min;
			this.max = Math.max(min + step, max);
			this.step = step;
			this.value = value;
			this.shown = value;
			this.format = format;
			this.onChange = onChange;
			setFocusable(true);
			addMouseListener(new MouseAdapter() {
				@Override public void mousePressed(MouseEvent e) { dragging = true; requestFocusInWindow(); setFromX(e.getX()); }
				@Override public void mouseReleased(MouseEvent e) { dragging = false; }
			});
			addKeyListener(new KeyAdapter() {
				@Override public void keyPressed(KeyEvent e) {
					if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_DOWN) set(Slider.this.value - Slider.this.step);
					if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_UP) set(Slider.this.value + Slider.this.step);
				}
			});
			addFocusListener(new FocusAdapter() {
				@Override public void focusGained(FocusEvent e) { repaint(); }
				@Override public void focusLost(FocusEvent e) { repaint(); }
			});
		}

		public int value() { return value; }

		public void setValue(int v) { value = Math.max(min, Math.min(max, v)); repaint(); }

		@Override void dragged(MouseEvent e) { if (dragging) setFromX(e.getX()); }

		private void setFromX(int x) {
			float t = (x - KNOB / 2f) / (float) (getWidth() - KNOB);
			set(Math.round((min + t * (max - min)) / (float) step) * step);
		}

		private void set(int v) {
			v = Math.max(min, Math.min(max, v));
			if (v != value) {
				value = v;
				onChange.accept(v);
			}
		}

		@Override
		public void tick(float dt) {
			super.tick(dt);
			float n = ease(shown, value, dragging ? 40 : 18, dt);
			if (Math.abs(n - value) < 1) n = value;
			if (n != shown) { shown = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			float t = (shown - min) / (float) (max - min);
			int cy = h - 12;
			float trackW = w - KNOB;
			float kx = KNOB / 2f + t * trackW;

			g.setFont(Style.bold(11f));
			g.setColor(Style.TEXT_DIM);
			Style.tracked(g, Lang.t("MEMORY"), 0, 13, 1.4f);
			g.setFont(Style.display(24f));
			g.setColor(Style.TEXT);
			String v = format.apply(Math.round(shown / 64f) * 64);
			FontMetrics fm = g.getFontMetrics();
			g.drawString(v, w - fm.stringWidth(v), 20);

			g.setColor(new Color(255, 255, 255, 28));
			g.fill(new RoundRectangle2D.Float(KNOB / 2f, cy - 2.5f, trackW, 5, 5, 5));
			g.setPaint(new GradientPaint(0, 0, new Color(0xFBC2D6), w, 0, Style.ACCENT_DEEP));
			g.fill(new RoundRectangle2D.Float(KNOB / 2f, cy - 2.5f, Math.max(5, kx - KNOB / 2f), 5, 5, 5));

			float grow = Math.max(hover, dragging ? 1 : 0);
			float r = KNOB / 2f - 2 + grow * 2;
			g.setColor(Style.alpha(Style.ACCENT, 0.18f * grow));
			g.fill(new Ellipse2D.Float(kx - r - 5, cy - r - 5, (r + 5) * 2, (r + 5) * 2));
			g.setColor(Color.WHITE);
			g.fill(new Ellipse2D.Float(kx - r, cy - r, r * 2, r * 2));
			if (isFocusOwner()) {
				g.setColor(Style.alpha(Style.ACCENT, 0.9f));
				g.setStroke(new BasicStroke(1.5f));
				g.draw(new Ellipse2D.Float(kx - r - 2.5f, cy - r - 2.5f, r * 2 + 5, r * 2 + 5));
			}
			g.dispose();
		}
	}

	/** Rounded text field that matches the rest of the UI. */
	public static final class Field extends JTextField implements Animated {
		private final String placeholder;
		private float focus;
		private Icons.Glyph icon;

		public Field(String text, String placeholder) {
			super(text);
			this.placeholder = placeholder;
			setOpaque(false);
			setBorder(new EmptyBorder(0, 14, 0, 14));
			setFont(Style.medium(14f));
			setForeground(Style.TEXT);
			setCaretColor(Style.ACCENT);
			setSelectionColor(Style.alpha(Style.ACCENT, 0.35f));
			setSelectedTextColor(Style.TEXT);
			addFocusListener(new FocusAdapter() {
				@Override public void focusGained(FocusEvent e) { repaint(); }
				@Override public void focusLost(FocusEvent e) { repaint(); }
			});
		}

		public Field icon(Icons.Glyph i) {
			this.icon = i;
			setBorder(new EmptyBorder(0, 38, 0, 14));
			return this;
		}

		public void onChange(Runnable r) {
			getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
				public void insertUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
				public void removeUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
				public void changedUpdate(javax.swing.event.DocumentEvent e) { r.run(); }
			});
		}

		@Override public void addNotify() { super.addNotify(); Anim.add(this); }

		@Override public void removeNotify() { Anim.remove(this); super.removeNotify(); }

		@Override
		public void tick(float dt) {
			float n = ease(focus, isFocusOwner() ? 1 : 0, 14, dt);
			if (n != focus) { focus = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			RoundRectangle2D r = new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, 14, 14);
			g.setColor(Style.mix(Style.FIELD, Style.FIELD_FOCUS, focus));
			g.fill(r);
			g.setColor(Style.mix(Style.CARD_BORDER, Style.alpha(Style.ACCENT, 0.75f), focus));
			g.draw(r);
			if (icon != null) icon.paint(g, 13, h / 2f - 8, 16, Style.mix(Style.TEXT_MUTED, Style.ACCENT, focus));
			if (getText().isEmpty() && placeholder != null) {
				g.setFont(getFont());
				FontMetrics fm = g.getFontMetrics();
				g.setColor(Style.TEXT_MUTED);
				g.drawString(placeholder, getInsets().left, (h - fm.getHeight()) / 2f + fm.getAscent());
			}
			g.dispose();
			super.paintComponent(g0);
		}
	}

	// ---------------------------------------------------------------- dropdown

	/** A select box. The list opens as a floating card inside the window. */
	public static final class Dropdown extends Base {
		private List<String> items = List.of();
		private int selected;
		private final IntConsumer onChange;
		private float open;
		private boolean isOpen;

		public Dropdown(IntConsumer onChange) {
			this.onChange = onChange;
		}

		public void setItems(List<String> items, int selected) {
			this.items = items;
			this.selected = Math.max(0, Math.min(items.size() - 1, selected));
			repaint();
		}

		public String value() { return items.isEmpty() ? "" : items.get(selected); }

		@Override void clicked(MouseEvent e) {
			if (items.size() <= 1) return;
			JLayeredPane layers = SwingUtilities.getRootPane(this) == null ? null : SwingUtilities.getRootPane(this).getLayeredPane();
			if (layers == null) return;
			isOpen = true;
			new DropList(this, layers).open();
		}

		void choose(int i) {
			isOpen = false;
			if (i >= 0 && i != selected) {
				selected = i;
				onChange.accept(i);
			}
			repaint();
		}

		@Override
		public void tick(float dt) {
			super.tick(dt);
			float n = ease(open, isOpen ? 1 : 0, 16, dt);
			if (n != open) { open = n; repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			RoundRectangle2D r = new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, 14, 14);
			g.setColor(new Color(255, 255, 255, Math.round(14 + hover * 8)));
			g.fill(r);
			g.setColor(Style.mix(Style.CARD_BORDER, Style.alpha(Style.ACCENT, 0.7f), Math.max(hover * 0.6f, open)));
			g.draw(r);
			g.setFont(Style.bold(13.5f));
			FontMetrics fm = g.getFontMetrics();
			g.setColor(Style.TEXT);
			g.drawString(value(), 14, (h - fm.getHeight()) / 2f + fm.getAscent());
			if (items.size() > 1) {
				g.setColor(Style.TEXT_DIM);
				g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
				float cx = w - 18, cy = h / 2f, s = 4;
				float flip = 1 - 2 * open;
				g.draw(new Line2D.Float(cx - s, cy - s / 2 * flip, cx, cy + s / 2 * flip));
				g.draw(new Line2D.Float(cx, cy + s / 2 * flip, cx + s, cy - s / 2 * flip));
			}
			g.dispose();
		}

		/** The open list. A full-window catcher closes it when you click elsewhere. */
		private static final class DropList extends JComponent implements Animated {
			private static final int ROW = 30;
			private final Dropdown owner;
			private final JLayeredPane layers;
			private final JComponent catcher = new JComponent() {};
			private float appear, scroll, scrollTarget;
			private int hoverRow = -1;
			private final Rectangle box;

			DropList(Dropdown owner, JLayeredPane layers) {
				this.owner = owner;
				this.layers = layers;
				Point p = SwingUtilities.convertPoint(owner, 0, owner.getHeight() + 6, layers);
				int visible = Math.min(owner.items.size(), 9);
				int h = visible * ROW + 8;
				int y = p.y;
				if (y + h > layers.getHeight() - 10) y = SwingUtilities.convertPoint(owner, 0, -6 - h, layers).y;
				box = new Rectangle(p.x, Math.max(10, y), owner.getWidth(), h);
				setBounds(box);
				int sel = owner.selected;
				scroll = scrollTarget = clampScroll((sel - visible / 2f) * ROW);
				setOpaque(false);
				MouseAdapter m = new MouseAdapter() {
					@Override public void mouseMoved(MouseEvent e) { hoverRow = rowAt(e.getY()); repaint(); }
					@Override public void mouseExited(MouseEvent e) { hoverRow = -1; repaint(); }
					@Override public void mouseReleased(MouseEvent e) { int r = rowAt(e.getY()); if (r >= 0) close(r); }
					@Override public void mouseWheelMoved(MouseWheelEvent e) { scrollTarget = clampScroll(scrollTarget + (float) e.getPreciseWheelRotation() * ROW * 1.5f); }
				};
				addMouseListener(m);
				addMouseMotionListener(m);
				addMouseWheelListener(m);
				catcher.setBounds(0, 0, layers.getWidth(), layers.getHeight());
				catcher.addMouseListener(new MouseAdapter() {
					@Override public void mousePressed(MouseEvent e) { close(-1); }
				});
			}

			private float clampScroll(float s) {
				float max = Math.max(0, owner.items.size() * ROW + 8 - box.height);
				return Math.max(0, Math.min(max, s));
			}

			private int rowAt(int y) {
				int r = (int) ((y - 4 + scroll) / ROW);
				return r >= 0 && r < owner.items.size() ? r : -1;
			}

			void open() {
				layers.add(catcher, JLayeredPane.POPUP_LAYER);
				layers.add(this, JLayeredPane.POPUP_LAYER);
				layers.moveToFront(this);
				Anim.add(this);
				layers.repaint();
			}

			void close(int choice) {
				Anim.remove(this);
				layers.remove(this);
				layers.remove(catcher);
				layers.repaint();
				owner.choose(choice);
			}

			@Override
			public void tick(float dt) {
				float a = ease(appear, 1, 18, dt);
				float s = ease(scroll, scrollTarget, 18, dt);
				if (a != appear || s != scroll) { appear = a; scroll = s; repaint(); }
			}

			@Override
			protected void paintComponent(Graphics g0) {
				Graphics2D g = Style.smooth(g0);
				int w = getWidth(), h = getHeight();
				float a = Style.easeOut(appear);
				g.setComposite(java.awt.AlphaComposite.SrcOver.derive(a));
				g.setColor(new Color(0x2E1B24));
				g.fill(new RoundRectangle2D.Float(0, 0, w, h, 14, 14));
				g.setColor(Style.CARD_BORDER);
				g.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, 14, 14));
				g.clip(new RoundRectangle2D.Float(2, 2, w - 4, h - 4, 12, 12));
				g.setFont(Style.medium(13f));
				FontMetrics fm = g.getFontMetrics();
				for (int i = 0; i < owner.items.size(); i++) {
					float y = 4 + i * ROW - scroll;
					if (y + ROW < 0 || y > h) continue;
					if (i == hoverRow) {
						g.setColor(new Color(255, 255, 255, 18));
						g.fill(new RoundRectangle2D.Float(4, y + 1, w - 8, ROW - 2, 10, 10));
					}
					boolean sel = i == owner.selected;
					g.setColor(sel ? Style.ACCENT : Style.TEXT);
					g.drawString(owner.items.get(i), 14, y + (ROW - fm.getHeight()) / 2f + fm.getAscent());
					if (sel) g.fill(new Ellipse2D.Float(w - 20, y + ROW / 2f - 3, 6, 6));
				}
				g.dispose();
			}
		}
	}

	// ---------------------------------------------------------------- scrolling

	/** Vertical scroll container with eased wheel scrolling and a thin bar. */
	public static final class ScrollArea extends JComponent implements Animated {
		private final JComponent content;
		private float offset, target;
		private float barAlpha;
		private long lastScroll;

		public ScrollArea(JComponent content) {
			this.content = content;
			setOpaque(false);
			setLayout(null);
			add(content);
			addMouseWheelListener(e -> {
				target = clamp(target + (float) e.getPreciseWheelRotation() * 60f);
				lastScroll = System.nanoTime();
			});
		}

		/** Content height is whatever the content says its preferred height is. */
		private int contentHeight() {
			return Math.max(getHeight(), content.getPreferredSize().height);
		}

		private float clamp(float v) {
			return Math.max(0, Math.min(contentHeight() - getHeight(), v));
		}

		public void scrollToTop() {
			offset = target = 0;
			doLayout();
		}

		@Override
		public void doLayout() {
			content.setBounds(0, -Math.round(offset), getWidth(), contentHeight());
			content.doLayout();
		}

		@Override public void addNotify() { super.addNotify(); Anim.add(this); }

		@Override public void removeNotify() { Anim.remove(this); super.removeNotify(); }

		@Override
		public void tick(float dt) {
			target = clamp(target);
			float n = ease(offset, target, 16, dt);
			if (Math.abs(n - target) < 0.5f) n = target;
			boolean active = System.nanoTime() - lastScroll < 900_000_000L;
			float b = ease(barAlpha, active ? 1 : 0, 8, dt);
			if (n != offset) {
				offset = n;
				content.setLocation(0, -Math.round(offset));
				repaint();
			}
			if (b != barAlpha) { barAlpha = b; repaint(); }
		}

		@Override
		protected void paintChildren(Graphics g) {
			super.paintChildren(g);
			int ch = contentHeight();
			if (ch <= getHeight() || barAlpha < 0.01f) return;
			Graphics2D g2 = Style.smooth(g);
			float h = getHeight() * getHeight() / (float) ch;
			float y = offset / (ch - getHeight()) * (getHeight() - h);
			g2.setColor(Style.alpha(Style.ACCENT, 0.45f * barAlpha));
			g2.fill(new RoundRectangle2D.Float(getWidth() - 5, y, 3, h, 3, 3));
			g2.dispose();
		}
	}

	/** Lays children out with a function, so pages can resize freely. */
	public abstract static class Page extends JComponent {
		protected Page() {
			setOpaque(false);
			setLayout(null);
		}

		protected <T extends Component> T put(T c) {
			add(c);
			return c;
		}

		@Override
		public abstract void doLayout();
	}
}
