package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.Installer;
import dev.cherryblossom.launcher.core.VersionInfo;
import dev.cherryblossom.launcher.core.VersionList;

import javax.swing.JComponent;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Every version from Alpha to today as a grid of covers, with a details panel to pick the exact patch. */
final class VersionsPage extends Controls.Page {
	private static final int PAD = 24;
	private static final int DETAIL_W = 330;
	private static final int CARD_W = 148, CARD_H = 206, GAP = 14;

	private enum Filter { RELEASES(Lang.t("Releases")), SNAPSHOTS(Lang.t("Snapshots")), CLASSIC(Lang.t("Beta & Alpha"));
		final String label;
		Filter(String l) { label = l; }
	}

	private final App app;
	private final Controls.Field search = new Controls.Field("", Lang.t("Search versions, e.g. 1.8.9 or Trails")).icon(Icons.SEARCH);
	private final List<Controls.Chip> filterChips = new ArrayList<>();
	private Filter filter = Filter.RELEASES;
	private final Grid grid = new Grid();
	private final Controls.ScrollArea scroll = new Controls.ScrollArea(grid);
	private final Detail detail = new Detail();
	private VersionList.Family family;
	private List<VersionList.Family> shown = List.of();

	VersionsPage(App app) {
		this.app = app;
		put(search);
		search.onChange(this::rebuild);
		for (Filter f : Filter.values()) {
			Controls.Chip c = new Controls.Chip(f.label, () -> setFilter(f));
			c.setSelected(f == filter);
			filterChips.add(c);
			put(c);
		}
		put(scroll);
		put(detail);
		app.listen(() -> {
			if (shown.isEmpty() && app.versions != null) rebuild();
			detail.refresh();
			grid.repaint();
		});
	}

	private void setFilter(Filter f) {
		filter = f;
		for (int i = 0; i < filterChips.size(); i++) filterChips.get(i).setSelected(Filter.values()[i] == f);
		rebuild();
		scroll.scrollToTop();
	}

	/** Called when the page is opened: jump to the family of the selected version. */
	void showSelected() {
		VersionList.Version v = app.selected();
		if (v == null) return;
		if (v.kind() == VersionList.Kind.SNAPSHOT) filter = Filter.SNAPSHOTS;
		else if (v.kind() != VersionList.Kind.RELEASE) filter = Filter.CLASSIC;
		for (int i = 0; i < filterChips.size(); i++) filterChips.get(i).setSelected(Filter.values()[i] == filter);
		rebuild();
		for (VersionList.Family f : shown) for (VersionList.Version x : f.versions()) if (x.id().equals(v.id())) family = f;
		detail.refresh();
	}

	private void rebuild() {
		VersionList vl = app.versions;
		if (vl == null) return;
		List<VersionList.Family> all = new ArrayList<>();
		switch (filter) {
			case RELEASES -> { for (VersionList.Family f : vl.families()) if (f.kind() == VersionList.Kind.RELEASE) all.add(f); }
			case CLASSIC -> { for (VersionList.Family f : vl.families()) if (f.kind() != VersionList.Kind.RELEASE) all.add(f); }
			case SNAPSHOTS -> {
				// group snapshots by year so the list stays browsable
				java.util.Map<Integer, List<VersionList.Version>> byYear = new java.util.LinkedHashMap<>();
				for (VersionList.Version v : vl.snapshots()) byYear.computeIfAbsent(v.year(), k -> new ArrayList<>()).add(v);
				byYear.forEach((year, list) -> all.add(new VersionList.Family(Lang.t("Snapshots"), Lang.t("Snapshots ") + year, VersionList.Kind.SNAPSHOT, list)));
			}
		}
		String q = search.getText().trim().toLowerCase(Locale.ROOT);
		List<VersionList.Family> out = new ArrayList<>();
		for (VersionList.Family f : all) {
			if (q.isEmpty()) { out.add(f); continue; }
			VersionInfo.Info info = VersionInfo.of(f.key());
			boolean hit = f.title().toLowerCase(Locale.ROOT).contains(q) || info.name().toLowerCase(Locale.ROOT).contains(q);
			if (!hit) for (VersionList.Version v : f.versions()) if (v.id().toLowerCase(Locale.ROOT).contains(q)) { hit = true; break; }
			if (hit) out.add(f);
		}
		shown = out;
		if (family == null || !out.contains(family)) {
			VersionList.Version sel = app.selected();
			family = null;
			if (sel != null) for (VersionList.Family f : out) for (VersionList.Version v : f.versions()) if (v.id().equals(sel.id())) family = f;
			if (family == null && !out.isEmpty()) family = out.get(0);
		}
		grid.rebuild();
		detail.refresh();
		doLayout();
		repaint();
	}

	@Override
	public void doLayout() {
		int w = getWidth(), h = getHeight();
		search.setBounds(PAD, 16, Math.min(360, w - DETAIL_W - PAD * 3 - 360), 42);
		int x = search.getX() + search.getWidth() + 14;
		for (Controls.Chip c : filterChips) {
			int cw = c.preferredWidth();
			c.setBounds(x, 20, cw, 34);
			x += cw + 8;
		}
		int gx = PAD, gy = 74, gw = w - DETAIL_W - PAD * 2 - 20;
		scroll.setBounds(gx - 6, gy, gw + 12, h - gy);
		scroll.doLayout();
		detail.setBounds(w - DETAIL_W - PAD, 16, DETAIL_W, h - 32);
		detail.doLayout();
	}

	// ---------------------------------------------------------------- grid

	private final class Grid extends Controls.Page {
		private final List<Card> cards = new ArrayList<>();

		void rebuild() {
			for (Card c : cards) remove(c);
			cards.clear();
			for (VersionList.Family f : shown) {
				Card c = new Card(f);
				cards.add(c);
				add(c);
			}
		}

		private int columns() {
			return Math.max(1, (getWidth() - 12 + GAP) / (CARD_W + GAP));
		}

		@Override
		public Dimension getPreferredSize() {
			int cols = Math.max(1, (Math.max(1, getWidth()) - 12 + GAP) / (CARD_W + GAP));
			int rows = (cards.size() + cols - 1) / cols;
			return new Dimension(getWidth(), rows * (CARD_H + GAP) + 24);
		}

		@Override
		public void doLayout() {
			int cols = columns();
			int used = cols * CARD_W + (cols - 1) * GAP;
			int gap = cols > 1 ? GAP + (getWidth() - 12 - used) / (cols - 1) : GAP;
			gap = Math.min(gap, GAP + 14);
			for (int i = 0; i < cards.size(); i++) {
				cards.get(i).setBounds(6 + (i % cols) * (CARD_W + gap), 8 + (i / cols) * (CARD_H + GAP), CARD_W, CARD_H);
			}
		}

		@Override
		protected void paintComponent(Graphics g0) {
			if (!cards.isEmpty()) return;
			Graphics2D g = Style.smooth(g0);
			g.setFont(Style.medium(13.5f));
			g.setColor(Style.TEXT_MUTED);
			g.drawString(app.versions == null ? Lang.t("Loading versions…") : Lang.t("No versions match \"") + search.getText().trim() + "\".", 8, 30);
			g.dispose();
		}
	}

	private final class Card extends Controls.Base {
		final VersionList.Family fam;

		Card(VersionList.Family fam) {
			this.fam = fam;
		}

		@Override void clicked(MouseEvent e) {
			family = fam;
			VersionList.Version sel = app.selected();
			boolean inside = false;
			if (sel != null) for (VersionList.Version v : fam.versions()) if (v.id().equals(sel.id())) inside = true;
			if (!inside) app.select(fam.latest().id());
			else { detail.refresh(); grid.repaint(); }
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), ch = CARD_H - 44;
			boolean sel = fam == family;
			float lift = hover * 3;
			g.translate(0, 3 - lift);
			if (hover > 0.01f || sel) {
				g.setColor(Style.alpha(Style.ACCENT, (sel ? 0.22f : 0.12f * hover)));
				g.fill(new RoundRectangle2D.Float(-3, -3, w + 6, ch + 6, 22, 22));
			}
			g.drawImage(Art.cover(fam.key(), coverLabel(fam), w, ch), 0, 0, null);
			if (sel) {
				g.setColor(Style.ACCENT);
				g.setStroke(new BasicStroke(2f));
				g.draw(new RoundRectangle2D.Float(1, 1, w - 2, ch - 2, 18, 18));
			}
			g.setFont(Style.bold(13f));
			g.setColor(sel ? Style.ACCENT : Style.TEXT);
			String title = fam.title();
			g.drawString(title, 2, ch + 19);
			g.setFont(Style.regular(11f));
			g.setColor(Style.TEXT_MUTED);
			String sub = fam.kind() == VersionList.Kind.SNAPSHOT ? Lang.count(fam.versions().size(), "build", "builds", "wersja", "wersje", "wersji") : Lang.t("Latest ") + fam.latest().id();
			g.drawString(sub, 2, ch + 33);
			g.dispose();
		}
	}

	// ---------------------------------------------------------------- details

	private final class Detail extends Controls.Page {
		private final Controls.Dropdown version = new Controls.Dropdown(i -> {
			if (family != null) app.select(family.versions().get(i).id());
		});
		private final Controls.Segmented loader = new Controls.Segmented(new String[] {"Fabric", "Vanilla"}, 0, i -> {
			app.settings.useFabric = i == 0;
			app.settings.save();
			app.changed();
		});
		private final Controls.PrimaryButton launch = new Controls.PrimaryButton(Lang.t("LAUNCH"), 16f, () -> {
			VersionList.Version cur = current();
			if (cur == null) return;
			if (app.selected() == null || !app.selected().id().equals(cur.id())) app.select(cur.id());
			app.launch(null);
		});

		Detail() {
			put(version);
			put(loader);
			put(launch);
		}

		VersionList.Version current() {
			if (family == null) return null;
			VersionList.Version sel = app.selected();
			if (sel != null) for (VersionList.Version v : family.versions()) if (v.id().equals(sel.id())) return v;
			return family.latest();
		}

		void refresh() {
			if (family == null) { repaint(); return; }
			List<String> ids = new ArrayList<>();
			int idx = 0;
			VersionList.Version cur = current();
			for (int i = 0; i < family.versions().size(); i++) {
				VersionList.Version v = family.versions().get(i);
				ids.add(v.id());
				if (cur != null && v.id().equals(cur.id())) idx = i;
			}
			version.setItems(ids, idx);
			Boolean fab = cur == null ? null : app.fabricSupport(cur.id());
			loader.setEnabled(0, fab == null || fab);
			loader.setSelected(app.settings.useFabric && (fab == null || fab) ? 0 : 1);
			launch.setLabel(app.running ? Lang.t("PLAYING") : app.busy ? Lang.t("PREPARING") : Lang.t("LAUNCH ") + (cur == null ? "" : cur.id()));
			launch.setActive(cur != null && !app.busy && !app.running);
			repaint();
		}

		private int artH() { return 150; }

		@Override
		public void doLayout() {
			int w = getWidth(), h = getHeight();
			int y = artH() + 130;
			version.setBounds(22, y + 20, w - 44, 42);
			loader.setBounds(22, y + 100, w - 44, 40);
			int gp = Controls.PrimaryButton.GLOW;
			launch.setBounds(22 - gp, h - 76 - gp, w - 44 + gp * 2, 56 + gp * 2);
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			Style.card(g, 0, 0, w, h);
			if (family == null) {
				g.dispose();
				return;
			}
			VersionInfo.Info info = VersionInfo.of(family.key());
			Graphics2D a = (Graphics2D) g.create();
			a.clip(new RoundRectangle2D.Float(0, 0, w, h, 22, 22));
			a.drawImage(Art.cover(family.key(), "", w, artH()), 0, 0, null);
			a.dispose();

			int y = artH() + 34;
			g.setFont(Style.display(26f));
			g.setColor(Style.TEXT);
			g.drawString(family.title(), 22, y);
			g.setFont(Style.medium(12.5f));
			g.setColor(Style.ACCENT);
			String meta = (info.name().isEmpty() ? "" : info.name() + "  ·  ") + family.year();
			g.drawString(meta, 22, y + 22);
			g.setFont(Style.regular(12.5f));
			g.setColor(Style.TEXT_DIM);
			FontMetrics fm = g.getFontMetrics();
			int ty = y + 44;
			int lines = 0;
			for (String line : Style.wrap(info.about(), fm, w - 44)) {
				if (lines++ >= 3) break;
				g.drawString(line, 22, ty);
				ty += 18;
			}

			int sy = artH() + 130;
			Style.label(g, Lang.t("VERSION"), 22, sy + 12);
			Style.label(g, Lang.t("LOADER"), 22, sy + 92);

			VersionList.Version cur = current();
			if (cur != null) {
				Boolean fab = app.fabricSupport(cur.id());
				boolean fabricOn = app.settings.useFabric && fab != null && fab;
				g.setFont(Style.regular(11.5f));
				g.setColor(Style.TEXT_MUTED);
				String note = fab == null ? Lang.t("Checking Fabric support…")
						: !fab ? Lang.t("Fabric starts at 1.14, so this one runs vanilla.")
						: fabricOn ? Lang.t("Fabric adds the performance mods and Cherry HUD.") : Lang.t("Pure vanilla, no mods.");
				g.drawString(note, 22, sy + 158);

				// what you get with this version
				int by = sy + 182;
				boolean hud = Installer.hasCherryHud(cur.id());
				Boolean sodium = fab != null && fab ? app.modAvailable("sodium", cur.id()) : Boolean.FALSE;
				by = badge(g, "Cherry HUD", hud && fabricOn ? 1 : hud ? 0 : -1, 22, by, w);
				by = badge(g, Lang.t("Performance mods"), sodium == null ? 2 : sodium && fabricOn ? 1 : sodium ? 0 : -1, 22, by, w);
				badge(g, app.installer.isInstalled(cur.id()) ? Lang.t("Downloaded, starts instantly") : Lang.t("Downloads on first launch"),
						app.installer.isInstalled(cur.id()) ? 1 : 0, 22, by, w);
			}
			g.dispose();
		}

		/** state: 1 included, 0 available but off, -1 not for this version, 2 checking. */
		private int badge(Graphics2D g, String text, int state, int x, int y, int w) {
			if (y > getHeight() - 96) return y;
			Color c = switch (state) {
				case 1 -> new Color(0xA8E6C1);
				case 2 -> Style.TEXT_MUTED;
				case 0 -> Style.TEXT_DIM;
				default -> Style.alpha(Style.TEXT_MUTED, 0.7f);
			};
			if (state == 1) Icons.CHECK.paint(g, x - 2, y - 13, 16, c);
			else {
				g.setColor(c);
				g.setStroke(new BasicStroke(1.4f));
				g.draw(new Ellipse2D.Float(x + 2, y - 9, 8, 8));
			}
			g.setFont(Style.medium(12f));
			g.setColor(c);
			String t = state == -1 ? text + Lang.t(" (not for this one)") : state == 2 ? text + Lang.t(" (checking…)") : text;
			g.drawString(t, x + 20, y);
			return y + 22;
		}
	}

	private static String coverLabel(VersionList.Family f) {
		return f.kind() == VersionList.Kind.SNAPSHOT ? Integer.toString(f.latest().year()) : f.key();
	}

	JComponent focusTarget() {
		return search;
	}
}
