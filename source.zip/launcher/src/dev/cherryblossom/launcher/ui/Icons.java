package dev.cherryblossom.launcher.ui;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** App icon plus a small set of line icons, all drawn as vectors on a 24-unit grid. */
public final class Icons {
	private Icons() {}

	/** Paints an icon in a size x size box at (x, y). */
	public interface Glyph {
		void paint(Graphics2D g, float x, float y, float size, Color color);
	}

	private interface Body {
		void draw(Graphics2D g);
	}

	private static Glyph line(Body body) {
		return (g0, x, y, size, color) -> {
			Graphics2D g = (Graphics2D) g0.create();
			g.translate(x, y);
			g.scale(size / 24.0, size / 24.0);
			g.setColor(color);
			g.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
			body.draw(g);
			g.dispose();
		};
	}

	public static final Glyph HOME = line(g -> {
		Path2D p = new Path2D.Float();
		p.moveTo(3.5, 11);
		p.lineTo(12, 4);
		p.lineTo(20.5, 11);
		g.draw(p);
		g.draw(new RoundRectangle2D.Float(6, 10, 12, 10, 3, 3));
		g.draw(new Line2D.Float(12, 15, 12, 20));
	});

	public static final Glyph VERSIONS = line(g -> {
		g.draw(new RoundRectangle2D.Float(4, 4, 7, 7, 2.5f, 2.5f));
		g.draw(new RoundRectangle2D.Float(13, 4, 7, 7, 2.5f, 2.5f));
		g.draw(new RoundRectangle2D.Float(4, 13, 7, 7, 2.5f, 2.5f));
		g.draw(new RoundRectangle2D.Float(13, 13, 7, 7, 2.5f, 2.5f));
	});

	public static final Glyph MODS = line(g -> {
		Path2D p = new Path2D.Float();
		p.moveTo(5, 8);
		p.lineTo(9, 8);
		p.curveTo(9, 4.5, 14, 4.5, 14, 8);
		p.lineTo(18, 8);
		p.lineTo(18, 12);
		p.curveTo(21.5, 12, 21.5, 17, 18, 17);
		p.lineTo(18, 20);
		p.lineTo(5, 20);
		p.closePath();
		g.draw(p);
	});

	public static final Glyph SETTINGS = line(g -> {
		g.draw(new Ellipse2D.Float(9, 9, 6, 6));
		for (int i = 0; i < 8; i++) {
			double a = Math.toRadians(i * 45);
			g.draw(new Line2D.Double(12 + Math.cos(a) * 6.2, 12 + Math.sin(a) * 6.2, 12 + Math.cos(a) * 8.6, 12 + Math.sin(a) * 8.6));
		}
		g.draw(new Ellipse2D.Float(5.8f, 5.8f, 12.4f, 12.4f));
	});

	public static final Glyph FOLDER = line(g -> {
		Path2D p = new Path2D.Float();
		p.moveTo(3.5, 7);
		p.lineTo(9.5, 7);
		p.lineTo(11.5, 9);
		p.lineTo(20.5, 9);
		p.lineTo(20.5, 18.5);
		p.lineTo(3.5, 18.5);
		p.closePath();
		g.draw(p);
	});

	public static final Glyph SEARCH = line(g -> {
		g.draw(new Ellipse2D.Float(4.5f, 4.5f, 11, 11));
		g.draw(new Line2D.Float(14, 14, 19.5f, 19.5f));
	});

	public static final Glyph SERVER = line(g -> {
		g.draw(new RoundRectangle2D.Float(4, 5, 16, 6, 2.5f, 2.5f));
		g.draw(new RoundRectangle2D.Float(4, 13, 16, 6, 2.5f, 2.5f));
		g.fill(new Ellipse2D.Float(6.8f, 7.2f, 1.8f, 1.8f));
		g.fill(new Ellipse2D.Float(6.8f, 15.2f, 1.8f, 1.8f));
	});

	public static final Glyph FRIENDS = line(g -> {
		g.draw(new Ellipse2D.Float(5.5f, 5f, 6f, 6f));
		Path2D p = new Path2D.Float();
		p.moveTo(3, 19.5);
		p.curveTo(3.5, 15, 6, 13.5, 8.5, 13.5);
		p.curveTo(11, 13.5, 13.5, 15, 14, 19.5);
		g.draw(p);
		g.draw(new java.awt.geom.Arc2D.Float(13f, 5.5f, 5.5f, 5.5f, -60, 240, java.awt.geom.Arc2D.OPEN));
		Path2D q = new Path2D.Float();
		q.moveTo(16, 13.6);
		q.curveTo(18.5, 13.8, 20.5, 15.5, 21, 19.5);
		g.draw(q);
	});

	public static final Glyph PLUS = line(g -> {
		g.draw(new Line2D.Float(12, 6, 12, 18));
		g.draw(new Line2D.Float(6, 12, 18, 12));
	});

	public static final Glyph CHECK = line(g -> {
		Path2D p = new Path2D.Float();
		p.moveTo(5.5, 12.5);
		p.lineTo(10, 17);
		p.lineTo(18.5, 7.5);
		g.draw(p);
	});

	public static final Glyph CPU = line(g -> {
		g.draw(new RoundRectangle2D.Float(6, 6, 12, 12, 3, 3));
		g.draw(new RoundRectangle2D.Float(9.5f, 9.5f, 5, 5, 1.5f, 1.5f));
		for (int i = 0; i < 3; i++) {
			float o = 9 + i * 3;
			g.draw(new Line2D.Float(o, 3, o, 6));
			g.draw(new Line2D.Float(o, 18, o, 21));
			g.draw(new Line2D.Float(3, o, 6, o));
			g.draw(new Line2D.Float(18, o, 21, o));
		}
	});

	public static final Glyph BOLT = line(g -> {
		Path2D p = new Path2D.Float();
		p.moveTo(13, 3.5);
		p.lineTo(6, 13.5);
		p.lineTo(11.5, 13.5);
		p.lineTo(10.5, 20.5);
		p.lineTo(18, 10.5);
		p.lineTo(12.5, 10.5);
		p.closePath();
		g.draw(p);
	});

	public static final Glyph KEY = line(g -> {
		g.draw(new RoundRectangle2D.Float(3.5f, 7, 17, 10, 3, 3));
		g.draw(new Line2D.Float(7, 12, 7.2f, 12));
		g.draw(new Line2D.Float(10.5f, 12, 10.7f, 12));
		g.draw(new Line2D.Float(14, 12, 17, 12));
	});

	public static final Glyph EYE = line(g -> {
		Path2D p = new Path2D.Float();
		p.moveTo(3, 12);
		p.curveTo(7, 5.5, 17, 5.5, 21, 12);
		p.curveTo(17, 18.5, 7, 18.5, 3, 12);
		g.draw(p);
		g.draw(new Ellipse2D.Float(9.5f, 9.5f, 5, 5));
	});

	public static final Glyph PETAL = (g, x, y, size, color) -> {
		Graphics2D c = (Graphics2D) g.create();
		c.translate(x + size / 2, y + size * 0.92);
		c.setColor(color);
		c.fill(Blossom.petal(size * 0.85));
		c.dispose();
	};

	// ---------------------------------------------------------------- app icon

	/** App icon: the blossom on a soft plum tile, rendered from the same vectors as the UI. */
	public static BufferedImage render(int size) {
		BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = Style.smooth(img.getGraphics());
		float r = size * 0.24f;
		g.setPaint(new GradientPaint(0, 0, new Color(0x3A1F2C), 0, size, new Color(0x22121A)));
		g.fill(new RoundRectangle2D.Float(0, 0, size, size, r, r));
		Blossom.draw(g, size / 2.0, size / 2.0 + size * 0.03, size * 0.36, 1f, 0, 1f);
		g.dispose();
		return img;
	}

	public static List<Image> windowIcons() {
		List<Image> list = new ArrayList<>();
		for (int s : new int[] {16, 24, 32, 48, 64, 128, 256}) list.add(render(s));
		return list;
	}

	/** Build helper: java ... Icons <outDir> writes icon PNGs for the exe and the mod. */
	public static void main(String[] args) throws Exception {
		File out = new File(args.length > 0 ? args[0] : ".");
		out.mkdirs();
		for (int s : new int[] {16, 24, 32, 48, 64, 128, 256}) ImageIO.write(render(s), "png", new File(out, "icon-" + s + ".png"));
	}
}
