package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Friends;
import dev.cherryblossom.launcher.core.Lang;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/** Your friend code, adding people by name or code, requests, and who's online. */
final class FriendsPage extends Controls.Page {
	private static final int PAD = 24, LEFT_W = 400, ROW = 54;

	private final App app;
	private final Friends friends;
	private final Controls.Field add = new Controls.Field("", Lang.t("Player name or friend code"));
	private final Controls.GhostButton addButton;
	private final Controls.GhostButton copy;
	private volatile String result = "";
	private volatile boolean resultError;
	private boolean copied;

	/** Clickable bits drawn by paint: rebuilt every frame. */
	private record Hit(Rectangle r, Runnable action) {}
	private final List<Hit> hits = new ArrayList<>();
	private Rectangle hover;

	FriendsPage(App app) {
		this.app = app;
		this.friends = app.friends;
		add.icon(Icons.FRIENDS);
		add.addActionListener(e -> send());
		put(add);
		addButton = put(new Controls.GhostButton(Lang.t("Add"), this::send).icon(Icons.PLUS));
		copy = put(new Controls.GhostButton(Lang.t("Copy"), this::copyCode));
		MouseAdapter m = new MouseAdapter() {
			@Override public void mouseClicked(MouseEvent e) {
				for (Hit h : new ArrayList<>(hits)) if (h.r.contains(e.getPoint())) { h.action.run(); return; }
			}
			@Override public void mouseMoved(MouseEvent e) {
				Rectangle found = null;
				for (Hit h : new ArrayList<>(hits)) if (h.r.contains(e.getPoint())) found = h.r;
				if (found != hover) { hover = found; setCursor(java.awt.Cursor.getPredefinedCursor(found != null ? java.awt.Cursor.HAND_CURSOR : java.awt.Cursor.DEFAULT_CURSOR)); repaint(); }
			}
		};
		addMouseListener(m);
		addMouseMotionListener(m);
		app.listen(this::repaint);
		// Online/offline is time based, so look again now and then.
		new javax.swing.Timer(20_000, e -> repaint()).start();
	}

	private void copyCode() {
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(friends.prettyCode()), null);
		copied = true;
		copy.setLabel(Lang.t("Copied"));
		javax.swing.Timer t = new javax.swing.Timer(1500, e -> { copied = false; copy.setLabel(Lang.t("Copy")); });
		t.setRepeats(false);
		t.start();
	}

	private void send() {
		String q = add.getText();
		if (q.isBlank()) return;
		addButton.setActive(false);
		result = Lang.t("Sending…");
		resultError = false;
		repaint();
		Thread t = new Thread(() -> {
			String r;
			boolean err;
			try {
				r = friends.add(q);
				err = !r.startsWith(Lang.t("Friend request sent")) && !r.startsWith(Lang.t("You're now friends"));
			} catch (Exception e) {
				r = Lang.t("Couldn't reach the friends service. Check your internet.");
				err = true;
			}
			String fr = r;
			boolean fe = err;
			javax.swing.SwingUtilities.invokeLater(() -> {
				result = fr;
				resultError = fe;
				if (!fe) add.setText("");
				addButton.setActive(true);
				repaint();
			});
		}, "cherry-friend-add");
		t.setDaemon(true);
		t.start();
	}

	@Override
	public void doLayout() {
		int x = PAD + 20, iw = LEFT_W - 40;
		copy.setBounds(PAD + LEFT_W - 20 - 96, 104, 96, 40);
		add.setBounds(x, 196, iw - 104, 42);
		addButton.setBounds(x + iw - 96, 196, 96, 42);
	}

	@Override
	protected void paintComponent(Graphics g0) {
		Graphics2D g = Style.smooth(g0);
		hits.clear();
		int w = getWidth(), h = getHeight();

		// ---- left: you and requests
		Style.card(g, PAD, 16, LEFT_W, h - 32);
		int x = PAD + 20, iw = LEFT_W - 40;
		g.setFont(Style.display(24f));
		g.setColor(Style.TEXT);
		g.drawString(Lang.t("Friends"), x, 50);
		g.setFont(Style.regular(11.5f));
		g.setColor(Style.TEXT_MUTED);
		g.drawString(Lang.t("Works with offline and Microsoft accounts."), x, 70);

		Style.label(g, Lang.t("YOUR FRIEND CODE"), x, 98);
		g.setColor(new Color(255, 255, 255, 14));
		g.fill(new RoundRectangle2D.Float(x, 104, iw - 108, 40, 12, 12));
		g.setFont(Style.bold(15f));
		g.setColor(Style.ACCENT);
		g.drawString(friends.prettyCode(), x + 14, 130);

		g.setFont(Style.regular(11.5f));
		g.setColor(friends.connected() ? new Color(0xA8E6C1) : new Color(0xF3D98B));
		g.fill(new Ellipse2D.Float(x, 157, 7, 7));
		g.setColor(Style.TEXT_MUTED);
		g.drawString(friends.connected() ? Lang.t("Connected") : Lang.t("Connecting to the friends service…"), x + 14, 164);

		Style.label(g, Lang.t("ADD A FRIEND"), x, 190);
		int y = 256;
		if (!result.isEmpty()) {
			g.setFont(Style.regular(12f));
			g.setColor(resultError ? Style.DANGER : Style.TEXT_DIM);
			for (String line : Style.wrap(result, g.getFontMetrics(), iw)) { g.drawString(line, x, y); y += 16; }
			y += 6;
		}
		g.setFont(Style.regular(11.5f));
		g.setColor(Style.TEXT_MUTED);
		for (String line : Style.wrap(Lang.t("By name: they need to have opened Cherry in the last 12 hours. A friend code always works."), g.getFontMetrics(), iw)) {
			g.drawString(line, x, y); y += 15;
		}
		y += 18;

		if (!friends.incoming.isEmpty()) {
			Style.label(g, Lang.t("REQUESTS"), x, y);
			y += 10;
			for (Friends.Request r : friends.incoming) {
				row(g, x, y, iw, r.name(), Friends.pretty(r.code()), null);
				int bx = x + iw - 12;
				bx = action(g, bx, y, Lang.t("Decline"), false, () -> friends.decline(r.code()));
				action(g, bx - 8, y, Lang.t("Accept"), true, () -> friends.accept(r.code()));
				y += ROW + 6;
			}
			y += 10;
		}
		if (!friends.outgoing.isEmpty()) {
			Style.label(g, Lang.t("SENT"), x, y);
			y += 10;
			for (Friends.Request r : friends.outgoing) {
				row(g, x, y, iw, r.name(), Lang.t("Waiting for them to accept"), null);
				action(g, x + iw - 12, y, Lang.t("Cancel"), false, () -> friends.cancel(r.code()));
				y += ROW + 6;
			}
		}

		// ---- right: the list
		int rx = PAD + LEFT_W + 16, rw = w - rx - PAD;
		Style.card(g, rx, 16, rw, h - 32);
		g.setFont(Style.bold(15f));
		g.setColor(Style.TEXT);
		g.drawString(Lang.t("Your friends"), rx + 18, 46);
		int online = friends.onlineCount();
		g.setFont(Style.regular(12f));
		g.setColor(Style.TEXT_MUTED);
		String count = friends.friends.isEmpty() ? "" : online + " / " + friends.friends.size() + Lang.t(" online");
		g.drawString(count, rx + rw - 18 - g.getFontMetrics().stringWidth(count), 46);

		List<Friends.Friend> list = new ArrayList<>(friends.friends);
		list.sort((a, b) -> a.online() != b.online() ? (a.online() ? -1 : 1) : a.name.compareToIgnoreCase(b.name));
		int fy = 66;
		if (list.isEmpty()) {
			g.setFont(Style.regular(13f));
			g.setColor(Style.TEXT_MUTED);
			int ty = 96;
			for (String line : Style.wrap(Lang.t("No friends yet. Send your code to a friend, or add them by name on the left."), g.getFontMetrics(), rw - 36)) {
				g.drawString(line, rx + 18, ty); ty += 18;
			}
		}
		for (Friends.Friend f : list) {
			if (fy + ROW > h - 24) break;
			row(g, rx + 16, fy, rw - 32, f.name, f.activity(), f.online() ? new Color(0xA8E6C1) : Style.TEXT_MUTED);
			int bx = rx + rw - 16 - 12;
			bx = action(g, bx, fy, Lang.t("Remove"), false, () -> friends.remove(f.code));
			String join = f.joinable();
			if (join != null) {
				action(g, bx - 8, fy, Lang.t("Join"), true, () -> {
					if (app.versions != null && app.versions.find(f.version) != null) app.select(f.version);
					app.launch(join);
				});
			}
			fy += ROW + 6;
		}
		g.dispose();
	}

	private void row(Graphics2D g, int x, int y, int w, String name, String sub, Color dot) {
		g.setColor(new Color(255, 255, 255, 8));
		g.fill(new RoundRectangle2D.Float(x, y, w, ROW, 14, 14));
		int tx = x + 14;
		if (dot != null) {
			g.setColor(dot);
			g.fill(new Ellipse2D.Float(x + 14, y + 23, 8, 8));
			tx = x + 32;
		}
		g.setFont(Style.bold(13.5f));
		g.setColor(Style.TEXT);
		g.drawString(name, tx, y + 23);
		g.setFont(Style.regular(11.5f));
		g.setColor(Style.TEXT_MUTED);
		FontMetrics fm = g.getFontMetrics();
		String s = sub;
		while (fm.stringWidth(s) > w - (tx - x) - 170 && s.length() > 8) s = s.substring(0, s.length() - 2);
		if (!s.equals(sub)) s += "…";
		g.drawString(s, tx, y + 40);
	}

	/** A small pill button drawn right-aligned at {@code right}; returns its left edge. */
	private int action(Graphics2D g, int right, int y, String label, boolean primary, Runnable run) {
		g.setFont(Style.medium(12f));
		int bw = g.getFontMetrics().stringWidth(label) + 24, bh = 28;
		Rectangle r = new Rectangle(right - bw, y + (ROW - bh) / 2, bw, bh);
		boolean hov = r.equals(hover);
		g.setColor(primary ? (hov ? Style.ACCENT : Style.ACCENT_DEEP) : new Color(255, 255, 255, hov ? 30 : 16));
		g.fill(new RoundRectangle2D.Float(r.x, r.y, r.width, r.height, bh, bh));
		g.setColor(primary ? Style.ACCENT_INK : Style.TEXT);
		g.drawString(label, r.x + 12, r.y + 18);
		hits.add(new Hit(r, () -> { run.run(); repaint(); }));
		return r.x;
	}
}
