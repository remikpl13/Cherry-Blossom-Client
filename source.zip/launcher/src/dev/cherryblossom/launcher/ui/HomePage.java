package dev.cherryblossom.launcher.ui;

import dev.cherryblossom.launcher.core.Lang;
import dev.cherryblossom.launcher.core.Installer;
import dev.cherryblossom.launcher.core.Presets;
import dev.cherryblossom.launcher.core.Settings;
import dev.cherryblossom.launcher.core.VersionInfo;
import dev.cherryblossom.launcher.core.VersionList;

import javax.swing.JComponent;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;

/** Home: the launch banner, quick join, recently played and a summary of this PC. */
final class HomePage extends Controls.Page {
	private static final int PAD = 24;
	private static final int BOTTOM_H = 262;

	private final App app;
	private final Consumer<String> navigate;
	private final Consumer<Runnable> addServerDialog;
	private final Hero hero = new Hero();
	private final Controls.PrimaryButton launch;
	private final Controls.GhostButton change;
	private final List<Controls.Chip> serverChips = new ArrayList<>();
	private final Controls.Chip addServer;
	private final List<RecentCard> recents = new ArrayList<>();
	private final Controls.GhostButton tune;

	HomePage(App app, Consumer<String> navigate, Consumer<Runnable> addServerDialog) {
		this.app = app;
		this.navigate = navigate;
		this.addServerDialog = addServerDialog;
		put(hero);
		hero.setLayout(null);
		launch = new Controls.PrimaryButton(Lang.t("LAUNCH GAME"), 17f, () -> app.launch(null));
		hero.add(launch);
		change = new Controls.GhostButton(Lang.t("Change version"), () -> navigate.accept("versions")).icon(Icons.VERSIONS);
		hero.add(change);
		addServer = new Controls.Chip(Lang.t("Add server"), () -> addServerDialog.accept(this::rebuildServers)).icon(Icons.PLUS);
		put(addServer);
		tune = new Controls.GhostButton(Lang.t("Tune performance"), () -> navigate.accept("settings")).icon(Icons.BOLT);
		put(tune);
		rebuildServers();
		app.listen(this::refresh);
		refresh();
	}

	void rebuildServers() {
		for (Controls.Chip c : serverChips) remove(c);
		serverChips.clear();
		for (String entry : new ArrayList<>(app.settings.servers)) {
			String[] p = entry.split("\\|", 2);
			String name = p[0], address = p.length > 1 ? p[1] : p[0];
			Controls.Chip c = new Controls.Chip(name, () -> app.launch(address)).sub(address).icon(Icons.SERVER)
					.removable(() -> {
						app.settings.servers.remove(entry);
						app.settings.save();
						rebuildServers();
					});
			c.setToolTipText(Lang.t("Launch and join ") + address + Lang.t("  ·  right-click to remove"));
			serverChips.add(c);
			put(c);
		}
		revalidate();
		doLayout();
		repaint();
	}

	private void refresh() {
		VersionList.Version v = app.selected();
		boolean ready = v != null && !app.busy && !app.running;
		launch.setActive(ready);
		launch.setLabel(app.running ? Lang.t("PLAYING") : app.busy ? Lang.t("PREPARING") : Lang.t("LAUNCH GAME"));
		if (v != null) {
			boolean fabric = app.willUseFabric(v.id());
			boolean hud = fabric && app.settings.cherryHud && Installer.hasCherryHud(v.id());
			launch.setSub("Minecraft " + v.id() + (fabric ? "  ·  Fabric" : "  ·  Vanilla") + (hud ? "  ·  Cherry HUD" : ""));
		}
		for (Controls.Chip c : serverChips) c.setActive(ready);

		// recently played
		List<String> ids = new ArrayList<>(app.settings.recentVersions);
		if (ids.size() != recents.size() || !matches(ids)) {
			for (RecentCard r : recents) remove(r);
			recents.clear();
			for (String id : ids) {
				RecentCard r = new RecentCard(id);
				recents.add(r);
				put(r);
			}
			doLayout();
		}
		for (RecentCard r : recents) r.setSelected(v != null && r.id.equals(v.id()));
		repaint();
	}

	private boolean matches(List<String> ids) {
		for (int i = 0; i < ids.size(); i++) if (!recents.get(i).id.equals(ids.get(i))) return false;
		return true;
	}

	// ---- layout ----

	private int heroH() { return Math.max(236, getHeight() - PAD - 16 - BOTTOM_H - 18); }

	private int leftW() { return Math.round((getWidth() - PAD * 2 - 16) * 0.62f); }

	@Override
	public void doLayout() {
		int w = getWidth();
		int hh = heroH();
		hero.setBounds(PAD, 16, w - PAD * 2, hh);
		int gp = Controls.PrimaryButton.GLOW;
		launch.setBounds(40 - gp, hh - 118 - gp, 290 + gp * 2, 66 + gp * 2);
		change.setBounds(346, hh - 107, 168, 44);

		int top = 16 + hh + 18;
		int lw = leftW();
		// quick join card
		int x = PAD + 20, y = top + 52;
		for (Controls.Chip c : serverChips) {
			int cw = Math.min(210, c.preferredWidth());
			if (x + cw > PAD + lw - 20) { c.setVisible(false); continue; }
			c.setVisible(true);
			c.setBounds(x, y, cw, 46);
			x += cw + 10;
		}
		int aw = addServer.preferredWidth();
		addServer.setVisible(x + aw <= PAD + lw - 20);
		addServer.setBounds(x, y + 4, aw, 38);

		// recently played
		int ry = top + 128 + 16 + 46;
		int rx = PAD + 20;
		for (RecentCard r : recents) {
			boolean fits = rx + 124 <= PAD + lw - 20;
			r.setVisible(fits);
			r.setBounds(rx, ry, 124, 60);
			rx += 134;
		}

		int cx = PAD + lw + 16, cw = w - PAD - cx;
		tune.setBounds(cx + 20, top + BOTTOM_H - 64, cw - 40, 42);
	}

	// ---- painting ----

	@Override
	protected void paintComponent(Graphics g0) {
		Graphics2D g = Style.smooth(g0);
		int w = getWidth();
		int top = 16 + heroH() + 18;
		int lw = leftW();

		Style.card(g, PAD, top, lw, 128);
		g.setFont(Style.bold(15f));
		g.setColor(Style.TEXT);
		g.drawString(Lang.t("Quick join"), PAD + 20, top + 30);
		int qx = PAD + 20 + g.getFontMetrics().stringWidth(Lang.t("Quick join")) + 14;
		g.setFont(Style.regular(12f));
		g.setColor(Style.TEXT_MUTED);
		g.drawString(Lang.t("Launch straight into a server. Right-click one to remove it."), qx, top + 30);

		int ry = top + 128 + 16;
		Style.card(g, PAD, ry, lw, BOTTOM_H - 128 - 16);
		g.setFont(Style.bold(15f));
		g.setColor(Style.TEXT);
		g.drawString(Lang.t("Recently played"), PAD + 20, ry + 30);
		if (recents.isEmpty()) {
			g.setFont(Style.regular(12.5f));
			g.setColor(Style.TEXT_MUTED);
			g.drawString(Lang.t("Versions you play will show up here for one-click switching."), PAD + 20, ry + 62);
		}

		int cx = PAD + lw + 16, cw = w - PAD - cx;
		Style.card(g, cx, top, cw, BOTTOM_H);
		g.setFont(Style.bold(15f));
		g.setColor(Style.TEXT);
		g.drawString(Lang.t("Your setup"), cx + 20, top + 30);
		Settings s = app.settings;
		String[][] rows = {
				{Lang.t("Preset"), s.preset.label + (s.preset == Presets.recommend() ? Lang.t("  (recommended)") : "")},
				{Lang.t("Memory"), String.format(Lang.current() == Lang.Language.PL ? "%.1f GB z %d GB" : "%.1f GB of %d GB", s.ramMb / 1024f, Math.round(Settings.systemMemoryMb() / 1024f))},
				{Lang.t("CPU"), Lang.count(Presets.cpuThreads(), "thread", "threads", "wątek", "wątki", "wątków")},
				{Lang.t("Mods"), Lang.count(s.enabledMods.size(), "mod", "mods", "mod", "mody", "modów")},
				{Lang.t("Player"), app.playerName() + (s.signedIn() ? Lang.t("  ·  Microsoft") : Lang.t("  ·  offline"))}};
		int yy = top + 62;
		for (String[] r : rows) {
			g.setFont(Style.medium(12f));
			g.setColor(Style.TEXT_MUTED);
			g.drawString(r[0], cx + 20, yy);
			g.setFont(Style.medium(13f));
			g.setColor(Style.TEXT);
			FontMetrics fm = g.getFontMetrics();
			String val = r[1];
			while (fm.stringWidth(val) > cw - 120 && val.length() > 4) val = val.substring(0, val.length() - 2);
			if (!val.equals(r[1])) val += "…";
			g.drawString(val, cx + 96, yy);
			yy += 27;
		}
		g.dispose();
	}

	// ---- pieces ----

	/** The banner: artwork, welcome line, title and status. */
	private final class Hero extends JComponent implements Controls.Animated {
		private double time;
		private final float[] px = new float[14], py = new float[14], ps = new float[14], pv = new float[14], pr = new float[14];
		private float progressShown;

		Hero() {
			Random r = new Random(3);
			for (int i = 0; i < px.length; i++) {
				px[i] = r.nextFloat() * 1200;
				py[i] = r.nextFloat() * 400;
				ps[i] = 5 + r.nextFloat() * 7;
				pv[i] = 14 + r.nextFloat() * 16;
				pr[i] = r.nextFloat() * 6;
			}
		}

		@Override public void addNotify() { super.addNotify(); Controls.Anim.add(this); }

		@Override public void removeNotify() { Controls.Anim.remove(this); super.removeNotify(); }

		@Override
		public void tick(float dt) {
			if (!isShowing()) return;
			time += dt;
			for (int i = 0; i < px.length; i++) {
				py[i] += pv[i] * dt;
				px[i] += (10 + (float) Math.sin(time * 0.7 + i) * 12) * dt;
				if (py[i] > getHeight() + 20) { py[i] = -20; px[i] = (float) (Math.random() * getWidth()); }
				if (px[i] > getWidth() + 20) px[i] = -20;
			}
			progressShown = Style.approach(progressShown, app.progress, 10, dt);
			repaint();
		}

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight();
			g.clip(new RoundRectangle2D.Float(0, 0, w, h, 26, 26));
			Art.hero(g, w, h, time);
			// soften the left side so the text reads clearly
			g.setPaint(new GradientPaint(0, 0, new Color(28, 14, 22, 215), w * 0.6f, 0, new Color(28, 14, 22, 0)));
			g.fillRect(0, 0, w, h);
			AffineTransform saved = g.getTransform();
			for (int i = 0; i < px.length; i++) {
				g.translate(px[i], py[i]);
				g.rotate(pr[i] + time * 0.6 * (i % 2 == 0 ? 1 : -1));
				g.setColor(new Color(255, 214, 228, 120));
				g.fill(Blossom.petal(ps[i]));
				g.setTransform(saved);
			}

			g.setFont(Style.medium(14f));
			g.setColor(Style.TEXT_DIM);
			boolean named = app.settings.signedIn() || !app.settings.offlineName.isBlank();
			g.drawString(named ? Lang.t("Welcome back, ") + app.playerName() : Lang.t("Welcome! Pick a player name in Settings to start."), 42, 52);
			float size = Math.min(58f, h * 0.22f);
			g.setFont(Style.display(size));
			g.setColor(Style.TEXT);
			g.drawString("Cherry Blossom", 40, 52 + size + 4);
			VersionList.Version v = app.selected();
			if (v != null) {
				String fam = VersionList.familyKey(v.id());
				String name = VersionInfo.of(fam).name();
				g.setFont(Style.medium(13.5f));
				g.setColor(Style.alpha(Style.ACCENT, 0.95f));
				g.drawString(Lang.t("Ready to play ") + v.id() + (name.isEmpty() ? "" : "  ·  " + name), 43, 52 + size + 34);
			}

			// status and progress under the buttons
			String status = app.status;
			if (status != null && !status.isEmpty()) {
				g.setFont(Style.medium(12.5f));
				g.setColor(app.statusError ? Style.DANGER : Style.TEXT_DIM);
				FontMetrics fm = g.getFontMetrics();
				String s = status;
				while (fm.stringWidth(s) > w * 0.62f && s.length() > 10) s = s.substring(0, s.length() - 4) + "…";
				g.drawString(s, 43, h - 26);
			}
			if (app.busy) {
				int bx = 43, by = h - 18, bw = Math.min(460, w / 2);
				g.setColor(new Color(255, 255, 255, 30));
				g.fill(new RoundRectangle2D.Float(bx, by, bw, 4, 4, 4));
				g.setPaint(new GradientPaint(bx, 0, new Color(0xFBC2D6), bx + bw, 0, Style.ACCENT_DEEP));
				g.fill(new RoundRectangle2D.Float(bx, by, Math.max(4, bw * progressShown), 4, 4, 4));
			}
			g.dispose();
		}
	}

	/** A small cover for a recently played version. */
	private final class RecentCard extends Controls.Base {
		final String id;
		private boolean selected;

		RecentCard(String id) {
			this.id = id;
			setToolTipText(Lang.t("Select Minecraft ") + id);
		}

		void setSelected(boolean s) { if (s != selected) { selected = s; repaint(); } }

		@Override void clicked(MouseEvent e) { app.select(id); }

		@Override
		protected void paintComponent(Graphics g0) {
			Graphics2D g = Style.smooth(g0);
			int w = getWidth(), h = getHeight() - 4;
			float lift = hover * 2;
			g.translate(0, 2 - lift);
			g.drawImage(Art.cover(VersionList.familyKey(id), "", w, h), 0, 0, null);
			g.setPaint(new GradientPaint(0, 0, new Color(20, 10, 16, 40), w, 0, new Color(20, 10, 16, 170)));
			g.fill(new RoundRectangle2D.Float(0, 0, w, h, 18, 18));
			if (selected || hover > 0.01f) {
				g.setColor(Style.alpha(Style.ACCENT, selected ? 1f : hover * 0.7f));
				g.setStroke(new java.awt.BasicStroke(2f));
				g.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, 16, 16));
			}
			g.setFont(Style.display(20f));
			g.setColor(Style.TEXT);
			g.drawString(id, 12, h - 13);
			g.dispose();
		}
	}
}
