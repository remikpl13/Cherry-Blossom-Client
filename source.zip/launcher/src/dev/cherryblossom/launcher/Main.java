package dev.cherryblossom.launcher;

import dev.cherryblossom.launcher.core.Installer;
import dev.cherryblossom.launcher.core.Settings;
import dev.cherryblossom.launcher.ui.App;
import dev.cherryblossom.launcher.ui.LauncherWindow;

import javax.swing.SwingUtilities;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Main {
	private Main() {}

	public static void main(String[] args) throws Exception {
		System.setProperty("awt.useSystemAAFontSettings", "on");
		System.setProperty("sun.java2d.d3d", "true");
		Path base = baseDir();
		Files.createDirectories(base);
		migrateFromVersion1(base);
		// Language first, so every label (including presets made while loading settings) is translated.
		Path settingsFile = base.resolve("cherry-launcher.json");
		dev.cherryblossom.launcher.core.Lang.Language lang = dev.cherryblossom.launcher.core.Lang.systemDefault();
		try {
			String v = dev.cherryblossom.launcher.core.Json.str(dev.cherryblossom.launcher.core.Json.obj(
					dev.cherryblossom.launcher.core.Json.parse(Files.readString(settingsFile))), "language");
			if (v != null) lang = dev.cherryblossom.launcher.core.Lang.Language.valueOf(v);
		} catch (Exception ignored) {
			// no settings yet: use the system language
		}
		dev.cherryblossom.launcher.core.Lang.set(lang);
		Settings settings = Settings.load(settingsFile);
		dev.cherryblossom.launcher.core.Lang.set(settings.language);
		Installer installer = new Installer(base);
		App app = new App(settings, installer);
		SwingUtilities.invokeLater(() -> new LauncherWindow(app).start());
	}

	/** Version 1 kept one game folder in data/game; it becomes the "26" instance so worlds carry over. */
	private static void migrateFromVersion1(Path base) {
		Path old = base.resolve("game");
		Path target = base.resolve("instances").resolve("26");
		try {
			if (Files.isDirectory(old) && !Files.exists(target)) {
				Files.createDirectories(target.getParent());
				Files.move(old, target);
			}
		} catch (Exception e) {
			System.err.println("Could not move the old game folder: " + e);
		}
	}

	/**
	 * Everything lives in the folder the launcher sits in (the "minecraft cherry client folder"),
	 * so the install is portable and never touches .minecraft. Override with -Dcherry.home=...
	 */
	static Path baseDir() throws Exception {
		String override = System.getProperty("cherry.home");
		if (override != null) return Path.of(override);
		Path jar = Path.of(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
		Path dir = Files.isDirectory(jar) ? jar : jar.getParent();
		// The jar sits in <client folder>/launcher/, data goes in <client folder>/data/
		if (dir.getFileName() != null && dir.getFileName().toString().equals("launcher")) dir = dir.getParent();
		return dir.resolve("data");
	}
}
