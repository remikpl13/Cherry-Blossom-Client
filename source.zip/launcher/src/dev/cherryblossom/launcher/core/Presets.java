package dev.cherryblossom.launcher.core;

import java.lang.management.ManagementFactory;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Low-end / Balanced / High-end presets. Each sets memory, the mod set,
 * and (optionally) the in-game video settings that matter most for frame rate.
 */
public final class Presets {
	private Presets() {}

	public enum Preset {
		LOW(Lang.t("Low-end"), Lang.t("Older laptops, 4 to 8 GB RAM, integrated graphics")),
		BALANCED(Lang.t("Balanced"), Lang.t("Most gaming PCs and newer laptops")),
		HIGH(Lang.t("High-end"), Lang.t("Strong CPU, 16 GB+ RAM, dedicated graphics")),
		CUSTOM(Lang.t("Custom"), Lang.t("Your own memory and mod choices"));

		public final String label, about;

		Preset(String label, String about) {
			this.label = label;
			this.about = about;
		}
	}

	private static final List<String> CORE = List.of("sodium", "lithium", "ferrite-core", "immediatelyfast",
			"entityculling", "modernfix", "dynamic-fps", "krypton", "modmenu");

	public static Set<String> mods(Preset p) {
		Set<String> s = new java.util.LinkedHashSet<>(CORE);
		switch (p) {
			case LOW -> s.addAll(List.of("moreculling", "badoptimizations", "memoryleakfix"));
			case BALANCED -> s.addAll(List.of("badoptimizations", "memoryleakfix", "reeses-sodium-options"));
			case HIGH -> s.addAll(List.of("c2me-fabric", "iris", "lambdynamiclights", "sodium-extra", "reeses-sodium-options"));
			default -> {}
		}
		return s;
	}

	public static int ramMb(Preset p) {
		int max = Settings.maxRamMb();
		int want = switch (p) {
			case LOW -> 2048;
			case BALANCED -> 4096;
			case HIGH -> 6144;
			default -> 4096;
		};
		return Math.max(1024, Math.min(max, want));
	}

	/** Video settings written to options.txt. Unknown keys are ignored by versions that don't have them. */
	public static Map<String, String> video(Preset p) {
		Map<String, String> o = new LinkedHashMap<>();
		switch (p) {
			case LOW -> {
				o.put("renderDistance", "6");
				o.put("simulationDistance", "5");
				o.put("graphicsMode", "0");
				o.put("fancyGraphics", "false");
				o.put("particles", "2");
				o.put("renderClouds", "\"false\"");
				o.put("entityShadows", "false");
				o.put("biomeBlendRadius", "0");
				o.put("mipmapLevels", "0");
				o.put("entityDistanceScaling", "0.75");
				o.put("maxFps", "120");
				o.put("ao", "false");
			}
			case BALANCED -> {
				o.put("renderDistance", "10");
				o.put("simulationDistance", "8");
				o.put("graphicsMode", "1");
				o.put("fancyGraphics", "true");
				o.put("particles", "1");
				o.put("renderClouds", "\"fast\"");
				o.put("entityShadows", "true");
				o.put("biomeBlendRadius", "2");
				o.put("maxFps", "260");
				o.put("ao", "true");
			}
			case HIGH -> {
				o.put("renderDistance", "16");
				o.put("simulationDistance", "12");
				o.put("graphicsMode", "1");
				o.put("fancyGraphics", "true");
				o.put("particles", "0");
				o.put("renderClouds", "\"true\"");
				o.put("entityShadows", "true");
				o.put("biomeBlendRadius", "4");
				o.put("mipmapLevels", "4");
				o.put("maxFps", "260");
				o.put("ao", "true");
			}
			default -> {}
		}
		return o;
	}

	public static int cpuThreads() {
		return Runtime.getRuntime().availableProcessors();
	}

	/** Our guess for this PC, used on first run. */
	public static Preset recommend() {
		int ram = Settings.systemMemoryMb();
		int cpu = cpuThreads();
		if (ram < 7000 || cpu <= 4) return Preset.LOW;
		if (ram >= 15000 && cpu >= 8) return Preset.HIGH;
		return Preset.BALANCED;
	}

	public static String cpuName() {
		String n = System.getenv("PROCESSOR_IDENTIFIER");
		if (n == null || n.isBlank()) {
			try {
				n = ManagementFactory.getOperatingSystemMXBean().getArch();
			} catch (Exception e) {
				n = Lang.t("CPU");
			}
		}
		return n;
	}
}
