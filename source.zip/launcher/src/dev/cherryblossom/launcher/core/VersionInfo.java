package dev.cherryblossom.launcher.core;

import java.util.Map;

/** Names, colours and one-line notes for each version family, shown on the version cards. */
public final class VersionInfo {
	private VersionInfo() {}

	public record Info(String title, String name, String about, int colorA, int colorB) {}

	private static final Map<String, Info> INFO = Map.ofEntries(
			e("26", "Minecraft 26", Lang.t("The 2026 drops"), Lang.t("The newest Minecraft, with a drop every few months. Cherry HUD and the full performance set."), 0xF7A8C4, 0x8E4C7A),
			e("1.21", "Minecraft 1.21", "Tricky Trials", Lang.t("Trial chambers, the breeze, the mace, and a year of drops up to 1.21.11."), 0xE8956A, 0x7A3B2E),
			e("1.20", "Minecraft 1.20", "Trails & Tales", Lang.t("Cherry groves, archaeology, camels and sniffers. A big modding version (1.20.1)."), 0xF3B3CF, 0x6E4A8C),
			e("1.19", "Minecraft 1.19", "The Wild Update", Lang.t("The deep dark, the warden, mangrove swamps, frogs and allays."), 0x4FB3A6, 0x1F3D5A),
			e("1.18", "Minecraft 1.18", "Caves & Cliffs: Part II", Lang.t("Taller worlds, huge caves and mountains. 1.18.2 is still widely played."), 0x7FC27A, 0x2B4D3A),
			e("1.17", "Minecraft 1.17", "Caves & Cliffs: Part I", Lang.t("Copper, amethyst, goats, axolotls and glow squid."), 0x6FCFD0, 0x2F4F6E),
			e("1.16", "Minecraft 1.16", "Nether Update", Lang.t("New Nether biomes, piglins and netherite. 1.16.5 is a modding classic."), 0xE06A5A, 0x4A1E2A),
			e("1.15", "Minecraft 1.15", "Buzzy Bees", Lang.t("Bees, honey and a lot of bug fixes."), 0xF5CF6B, 0x7A5A2A),
			e("1.14", "Minecraft 1.14", "Village & Pillage", Lang.t("New villages, pillagers and raids. The first version Fabric supports."), 0xC9A66B, 0x4E3B2B),
			e("1.13", "Minecraft 1.13", "Update Aquatic", Lang.t("Oceans come alive: dolphins, coral reefs, shipwrecks."), 0x5AB6E8, 0x1D3B6A),
			e("1.12", "Minecraft 1.12", "World of Color", Lang.t("Concrete, glazed terracotta and recipe books."), 0xE07BB0, 0x3E5BA8),
			e("1.11", "Minecraft 1.11", "Exploration Update", Lang.t("Woodland mansions, llamas and explorer maps."), 0x9BBF6A, 0x3E5530),
			e("1.10", "Minecraft 1.10", "Frostburn Update", Lang.t("Polar bears, strays, husks and fossils."), 0xA8D8F0, 0x3B5A7A),
			e("1.9", "Minecraft 1.9", "Combat Update", Lang.t("Shields, dual wielding and the new attack cooldown."), 0xD9A35A, 0x5A3A2A),
			e("1.8", "Minecraft 1.8", "Bountiful Update", Lang.t("The PvP classic. Banners, ocean monuments and slime blocks."), 0x8FB4D8, 0x2E3F5E),
			e("1.7", "Minecraft 1.7", "The Update that Changed the World", Lang.t("New biomes, stained glass and fishing."), 0x7CC49A, 0x2E4A3E),
			e("1.6", "Minecraft 1.6", "Horse Update", Lang.t("Horses, hay bales, carpets and the new launcher."), 0xC79A70, 0x4A3326),
			e("1.5", "Minecraft 1.5", "Redstone Update", Lang.t("Comparators, hoppers and daylight sensors."), 0xE05A5A, 0x4A1F1F),
			e("1.4", "Minecraft 1.4", "Pretty Scary Update", Lang.t("Withers, witches, item frames and anvils."), 0x9A8AC8, 0x2E2848),
			e("1.3", "Minecraft 1.3", "", Lang.t("Trading, emeralds, temples and the Ender chest."), 0x6FC28A, 0x2B4A36),
			e("1.2", "Minecraft 1.2", "", Lang.t("Jungles, ocelots and iron golems."), 0x7DC26A, 0x34502A),
			e("1.1", "Minecraft 1.1", "", Lang.t("Spawn eggs and the first language support."), 0xB8C26A, 0x4A502A),
			e("1.0", "Minecraft 1.0", "Adventure Update", Lang.t("Where it all became official: the End and the ender dragon."), 0xB89BD8, 0x3A2E58),
			e("Beta", "Beta", Lang.t("2010 to 2011"), Lang.t("Before 1.0. Pistons, beds, weather. b1.7.3 is the famous one."), 0xC9B48A, 0x4E4434),
			e("Snapshots", Lang.t("Snapshots"), Lang.t("Test builds"), Lang.t("Weekly previews of upcoming features. Can be unstable, keep backups of your worlds."), 0xA8C8F0, 0x34405E),
			e("Alpha", "Alpha", "2010", Lang.t("The early days of Survival. Simple, quiet, nostalgic."), 0x9AB88A, 0x3A4A34));

	private static Map.Entry<String, Info> e(String key, String title, String name, String about, int a, int b) {
		return Map.entry(key, new Info(title, name, about, a, b));
	}

	public static Info of(String key) {
		Info i = INFO.get(key);
		return i != null ? i : new Info("Minecraft " + key, "", Lang.t("A classic Minecraft release."), 0xCFA8C0, 0x3A2A34);
	}

	public static String title(String key) {
		return of(key).title();
	}
}
