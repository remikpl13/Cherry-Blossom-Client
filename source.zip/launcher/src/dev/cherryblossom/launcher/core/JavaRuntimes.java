package dev.cherryblossom.launcher.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Every Minecraft version wants a specific Java (8 for 1.16 and older, 17 for 1.18, 21 for 1.20.5+, 25 for 26.x).
 * We download exactly the runtime Mojang ships for it, once, into data/runtime/.
 */
public final class JavaRuntimes {
	private static final String ALL = "https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json";

	private final Path root;

	public JavaRuntimes(Path root) {
		this.root = root;
	}

	public record Job(String url, Path path, String sha1, long size, boolean executable) {}

	static String platform() {
		String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
		boolean arm = System.getProperty("os.arch").toLowerCase(Locale.ROOT).contains("aarch64");
		if (os.contains("win")) return arm ? "windows-arm64" : "windows-x64";
		if (os.contains("mac")) return arm ? "mac-os-arm64" : "mac-os";
		return "linux";
	}

	/** Path of the java binary for this component (may not exist yet). */
	public Path executable(String component) {
		Path home = root.resolve(component);
		if (platform().startsWith("mac")) home = home.resolve("jre.bundle/Contents/Home");
		Path bin = home.resolve("bin");
		if (platform().startsWith("windows")) return bin.resolve("javaw.exe");
		return bin.resolve("java");
	}

	/**
	 * Returns download jobs needed for the component (empty if it's already complete).
	 * If Mojang has no runtime for this platform, falls back to the Java the launcher runs on.
	 */
	public List<Job> plan(String component) throws IOException {
		Path dir = root.resolve(component);
		Path marker = dir.resolve(".cherry-complete");
		List<Job> jobs = new ArrayList<>();
		if (Files.exists(marker) && Files.exists(executable(component))) return jobs;

		Map<String, Object> all = Http.getJson(ALL);
		List<Object> entries = Json.arr(Json.obj(all, platform()), component);
		if (entries.isEmpty()) return null;
		String manifestUrl = Json.str(Json.obj(Json.obj(entries.get(0)), "manifest"), "url");
		Map<String, Object> files = Json.obj(Http.getJson(manifestUrl), "files");
		for (Map.Entry<String, Object> e : files.entrySet()) {
			Map<String, Object> f = Json.obj(e.getValue());
			Path p = dir.resolve(e.getKey());
			switch (String.valueOf(Json.str(f, "type"))) {
				case "directory" -> Files.createDirectories(p);
				case "file" -> {
					Map<String, Object> raw = Json.obj(Json.obj(f, "downloads"), "raw");
					long size = Json.num(raw, "size", 0);
					if (!Files.isRegularFile(p) || Files.size(p) != size) {
						jobs.add(new Job(Json.str(raw, "url"), p, Json.str(raw, "sha1"), size, Json.bool(f, "executable", false)));
					}
				}
				default -> {} // symlinks only matter on macOS/Linux and aren't needed to run java
			}
		}
		return jobs;
	}

	public void finish(String component, List<Job> jobs) throws IOException {
		for (Job j : jobs) if (j.executable()) j.path().toFile().setExecutable(true, false);
		Path exe = executable(component);
		exe.toFile().setExecutable(true, false);
		Files.writeString(root.resolve(component).resolve(".cherry-complete"), "ok");
	}

	/** Java that runs the launcher, used only if Mojang has no runtime for this OS. */
	public static Path currentJava() {
		Path bin = Path.of(System.getProperty("java.home"), "bin");
		for (String n : new String[] {"javaw.exe", "java.exe", "java"}) {
			if (Files.exists(bin.resolve(n))) return bin.resolve(n);
		}
		return bin.resolve("java");
	}
}
