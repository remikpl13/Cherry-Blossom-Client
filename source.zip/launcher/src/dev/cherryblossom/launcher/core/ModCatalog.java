package dev.cherryblossom.launcher.core;

import java.util.List;

/**
 * The mods the launcher can manage, all fetched from Modrinth for the exact version you play.
 * If a mod hasn't been made for a version, it's simply skipped.
 */
public final class ModCatalog {
	private ModCatalog() {}

	public enum Group { PERFORMANCE, LOW_END, HIGH_END, UTILITY }

	public record Mod(String slug, String name, String about, Group group) {}

	public static final List<Mod> ALL = List.of(
			new Mod("sodium", "Sodium", Lang.t("Rewrites the renderer. Usually 2x to 3x the frame rate."), Group.PERFORMANCE),
			new Mod("lithium", "Lithium", Lang.t("Faster game logic, mob AI and physics. No visual change."), Group.PERFORMANCE),
			new Mod("ferrite-core", "FerriteCore", Lang.t("Cuts memory use, a big help on 4 GB and below."), Group.PERFORMANCE),
			new Mod("immediatelyfast", "ImmediatelyFast", Lang.t("Speeds up HUD, text and entity drawing."), Group.PERFORMANCE),
			new Mod("entityculling", "Entity Culling", Lang.t("Skips drawing mobs and chests you can't see."), Group.PERFORMANCE),
			new Mod("modernfix", "ModernFix", Lang.t("Faster startup and lower memory use."), Group.PERFORMANCE),
			new Mod("dynamic-fps", "Dynamic FPS", Lang.t("Drops to a few FPS when the game is in the background."), Group.PERFORMANCE),
			new Mod("krypton", "Krypton", Lang.t("Lighter networking, smoother on busy servers."), Group.PERFORMANCE),
			new Mod("moreculling", "More Culling", Lang.t("Hides even more hidden faces: leaves, signs, item frames."), Group.LOW_END),
			new Mod("badoptimizations", "BadOptimizations", Lang.t("Lots of small caching tweaks that add up on weak CPUs."), Group.LOW_END),
			new Mod("memoryleakfix", "Memory Leak Fix", Lang.t("Fixes slow memory leaks in older versions."), Group.LOW_END),
			new Mod("c2me-fabric", "C2ME", Lang.t("Loads and generates chunks on all your CPU cores."), Group.HIGH_END),
			new Mod("iris", "Iris Shaders", Lang.t("Run shader packs (Complementary, BSL...) with Sodium."), Group.HIGH_END),
			new Mod("lambdynamiclights", "LambDynamicLights", Lang.t("Torches light up the area around you while held."), Group.HIGH_END),
			new Mod("sodium-extra", "Sodium Extra", Lang.t("Extra graphics options: fog, particles, animations."), Group.UTILITY),
			new Mod("reeses-sodium-options", Lang.t("Better Video Settings"), Lang.t("A cleaner, searchable video settings screen."), Group.UTILITY),
			new Mod("modmenu", "Mod Menu", Lang.t("A Mods button on the title screen to configure mods."), Group.UTILITY));

	public static Mod bySlug(String slug) {
		for (Mod m : ALL) if (m.slug().equals(slug)) return m;
		return null;
	}
}
