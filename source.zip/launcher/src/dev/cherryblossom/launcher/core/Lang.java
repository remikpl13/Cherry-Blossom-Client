package dev.cherryblossom.launcher.core;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Interface language. Strings are written in English in the code and looked up here,
 * so a missing translation simply shows the English text instead of breaking anything.
 */
public final class Lang {
	private Lang() {}

	public enum Language {
		EN("English"), PL("Polski");

		public final String label;

		Language(String label) { this.label = label; }
	}

	private static Language current = Language.EN;
	private static final Map<String, String> PL = new HashMap<>();

	public static void set(Language l) {
		current = l == null ? Language.EN : l;
	}

	public static Language current() {
		return current;
	}

	/** Polish if the system is Polish, English otherwise. */
	public static Language systemDefault() {
		return "pl".equals(Locale.getDefault().getLanguage()) ? Language.PL : Language.EN;
	}

	public static String t(String english) {
		if (current == Language.EN || english == null) return english;
		String s = PL.get(english);
		return s == null ? english : s;
	}

	/** "8 threads" / "8 wątków": Polish has three plural forms. */
	public static String count(int n, String enOne, String enMany, String plOne, String plFew, String plMany) {
		if (current == Language.EN) return n + " " + (n == 1 ? enOne : enMany);
		int m10 = n % 10, m100 = n % 100;
		String w = n == 1 ? plOne : (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) ? plFew : plMany;
		return n + " " + w;
	}

	private static void pl(String en, String pl) {
		PL.put(en, pl);
	}

	static {
		// ---- home
		pl("LAUNCH GAME", "URUCHOM GRĘ");
		pl("Change version", "Zmień wersję");
		pl("Add server", "Dodaj serwer");
		pl("Tune performance", "Dostosuj wydajność");
		pl("Launch and join ", "Uruchom i dołącz do ");
		pl("  ·  right-click to remove", "  ·  prawy przycisk usuwa");
		pl("PLAYING", "W GRZE");
		pl("PREPARING", "PRZYGOTOWANIE");
		pl("Quick join", "Szybkie dołączanie");
		pl("Launch straight into a server. Right-click one to remove it.", "Wejdź prosto na serwer. Kliknij prawym, aby usunąć.");
		pl("Recently played", "Ostatnio grane");
		pl("Versions you play will show up here for one-click switching.", "Tu pojawią się wersje, w które grasz, aby przełączać je jednym kliknięciem.");
		pl("Your setup", "Twoja konfiguracja");
		pl("Preset", "Profil");
		pl("  (recommended)", "  (zalecany)");
		pl("Memory", "Pamięć");
		pl("CPU", "Procesor");
		pl(" threads", " wątki");
		pl("Mods", "Mody");
		pl(" performance and utility mods", " modów wydajności i narzędzi");
		pl("Player", "Gracz");
		pl("  ·  Microsoft", "  ·  Microsoft");
		pl("  ·  offline", "  ·  offline");
		pl("Welcome back, ", "Witaj ponownie, ");
		pl("Welcome! Pick a player name in Settings to start.", "Witaj! Aby zacząć, wybierz nazwę gracza w Ustawieniach.");
		pl("Ready to play ", "Gotowe do gry: ");
		pl("Select Minecraft ", "Wybierz Minecraft ");
		pl("GB of", "GB z");

		// ---- versions
		pl("Releases", "Wydania");
		pl("Snapshots", "Snapshoty");
		pl("Beta & Alpha", "Beta i Alpha");
		pl("Search versions, e.g. 1.8.9 or Trails", "Szukaj wersji, np. 1.8.9 lub Trails");
		pl("Snapshots ", "Snapshoty ");
		pl("Loading versions…", "Wczytywanie wersji…");
		pl("No versions match \"", "Brak wersji pasujących do „");
		pl(" builds", " wersji");
		pl("Latest ", "Najnowsza ");
		pl("LAUNCH", "URUCHOM");
		pl("LAUNCH ", "URUCHOM ");
		pl("VERSION", "WERSJA");
		pl("LOADER", "LOADER");
		pl("Checking Fabric support…", "Sprawdzanie obsługi Fabric…");
		pl("Fabric starts at 1.14, so this one runs vanilla.", "Fabric działa od wersji 1.14, więc ta uruchomi się bez modów.");
		pl("Fabric adds the performance mods and Cherry HUD.", "Fabric dodaje mody wydajności i Cherry HUD.");
		pl("Pure vanilla, no mods.", "Czysty vanilla, bez modów.");
		pl("Performance mods", "Mody wydajności");
		pl("Downloaded, starts instantly", "Pobrana, startuje od razu");
		pl("Downloads on first launch", "Pobierze się przy pierwszym uruchomieniu");
		pl(" (not for this one)", " (niedostępne dla tej wersji)");
		pl(" (checking…)", " (sprawdzanie…)");

		// ---- mods
		pl("PERFORMANCE", "WYDAJNOŚĆ");
		pl("EXTRA HELP FOR LOW-END PCS", "DODATKI DLA SŁABSZYCH KOMPUTERÓW");
		pl("EXTRAS FOR HIGH-END PCS", "DODATKI DLA MOCNYCH KOMPUTERÓW");
		pl("UTILITY", "NARZĘDZIA");
		pl("FPS, ping, keystrokes, armour, potions, zoom and more. Right Shift in game.", "FPS, ping, klawisze, zbroja, mikstury, zoom i więcej. Prawy Shift w grze.");
		pl("Open mods folder", "Otwórz folder modów");
		pl("Couldn't open the folder: ", "Nie udało się otworzyć folderu: ");
		pl("For Minecraft ", "Dla Minecraft ");
		pl(". Downloaded from Modrinth for the exact version you play,", ". Pobierane z Modrinth dokładnie dla wersji, w którą grasz,");
		pl("with anything they need. Your own .jar mods can go in the mods folder too.", "razem ze wszystkim, czego potrzebują. Własne mody .jar też możesz dodać do folderu modów.");
		pl("Mods need Fabric, which starts at 1.14. Minecraft ", "Mody wymagają Fabric, który działa od wersji 1.14. Minecraft ");
		pl(" runs vanilla.", " uruchomi się bez modów.");
		pl("You picked Vanilla for this version, so mods are off. Switch to Fabric on the Versions page.", "Wybrano Vanilla dla tej wersji, więc mody są wyłączone. Przełącz na Fabric na stronie Wersje.");
		pl("Built in", "Wbudowany");
		pl("1.21.9 to 26.3", "1.21.9 do 26.3");
		pl("For ", "Dla ");
		pl("Checking…", "Sprawdzanie…");
		pl("Not for ", "Brak dla ");

		// ---- settings
		pl("Player name", "Nazwa gracza");
		pl("Width", "Szerokość");
		pl("Height", "Wysokość");
		pl("Extra Java arguments (advanced, optional)", "Dodatkowe argumenty Javy (zaawansowane, opcjonalne)");
		pl("Apply the preset's video settings on next launch", "Zastosuj ustawienia grafiki profilu przy następnym uruchomieniu");
		pl("Render distance, graphics quality, particles and clouds, tuned for the preset", "Zasięg renderowania, jakość grafiki, cząsteczki i chmury dopasowane do profilu");
		pl("Sign in with Microsoft instead", "Zaloguj się kontem Microsoft");
		pl("Sign out", "Wyloguj");
		pl("Start in fullscreen", "Uruchamiaj na pełnym ekranie");
		pl("You can always switch with F11 in game", "W grze zawsze możesz przełączyć klawiszem F11");
		pl("Hide the launcher while playing", "Ukrywaj launcher podczas gry");
		pl("It comes back when you close the game, so it uses no CPU meanwhile", "Wraca po zamknięciu gry, a w tym czasie nie obciąża procesora");
		pl("Open the client's data folder", "Otwórz folder z danymi klienta");
		pl("Settings", "Ustawienia");
		pl("Performance", "Wydajność");
		pl("This PC: ", "Ten komputer: ");
		pl(" GB RAM  ·  ", " GB RAM  ·  ");
		pl("we suggest", "sugerujemy:");
		pl("Account", "Konto");
		pl("Signed in with Microsoft", "Zalogowano kontem Microsoft");
		pl("Offline name works for singleplayer, LAN and offline-mode servers", "Nazwa offline działa w trybie jednoosobowym, w sieci LAN i na serwerach offline");
		pl("Game window", "Okno gry");
		pl("Starting size of the Minecraft window", "Początkowy rozmiar okna Minecrafta");
		pl("Launcher", "Launcher");
		pl("About", "Informacje");
		pl("Language", "Język");
		pl("Restarts the launcher to switch", "Launcher uruchomi się ponownie, aby zmienić język");
		pl("Cherry Blossom Client 2.0  ·  every Minecraft version from Alpha to ", "Cherry Blossom Client 2.0  ·  każda wersja Minecrafta od Alphy do ");
		pl("Mods come from Modrinth, Minecraft and Java from Mojang. Fonts: DM Serif Display and Plus Jakarta Sans (OFL).", "Mody pochodzą z Modrinth, Minecraft i Java od Mojang. Czcionki: DM Serif Display i Plus Jakarta Sans (OFL).");
		pl("SUGGESTED", "ZALECANY");

		// ---- window
		pl("Home", "Start");
		pl("Versions", "Wersje");
		pl("Folder", "Folder");
		pl("Loading the version list", "Wczytywanie listy wersji");
		pl("Couldn't reach Mojang. Check your internet connection.", "Brak połączenia z Mojang. Sprawdź połączenie z internetem.");
		pl("Signing you in", "Logowanie");
		pl("Your Microsoft sign-in expired. Sign in again in Settings.", "Logowanie Microsoft wygasło. Zaloguj się ponownie w Ustawieniach.");
		pl("Ready", "Gotowe");
		pl("Set your player name in Settings, then press Launch.", "Ustaw nazwę gracza w Ustawieniach, a potem naciśnij Uruchom.");
		pl("Loading", "Wczytywanie");
		pl("Server address, e.g. play.example.net", "Adres serwera, np. play.example.net");
		pl("Add a server", "Dodaj serwer");
		pl("It appears in Quick join. Click it to launch your selected version straight into that server.", "Pojawi się w Szybkim dołączaniu. Kliknij go, aby uruchomić wybraną wersję prosto na tym serwerze.");
		pl("Cancel", "Anuluj");
		pl("Azure application (client) ID", "Identyfikator aplikacji Azure (klienta)");
		pl("Continue", "Dalej");
		pl("Sign in with Microsoft", "Logowanie przez Microsoft");
		pl("Microsoft sign-in needs an Azure app ID that Mojang has approved for Minecraft. ", "Logowanie Microsoft wymaga identyfikatora aplikacji Azure zatwierdzonej przez Mojang dla Minecrafta. ");
		pl("Paste yours below (README.txt explains how). Or just play offline with a player name.", "Wklej go poniżej (instrukcja w README.txt) albo graj offline z nazwą gracza.");
		pl("Contacting Microsoft…", "Łączenie z Microsoft…");
		pl("Copy code & open", "Kopiuj kod i otwórz");
		pl("Go to ", "Wejdź na ");
		pl(" and enter this code. ", " i wpisz ten kod. ");
		pl("You sign in on Microsoft's own page; Cherry Blossom never sees your password.", "Logujesz się na stronie Microsoftu, Cherry Blossom nigdy nie widzi Twojego hasła.");
		pl("Signed in as ", "Zalogowano jako ");
		pl("Couldn't sign in", "Nie udało się zalogować");
		pl("OK", "OK");
		pl("Waiting for you to finish in the browser", "Czekam, aż dokończysz w przeglądarce");

		// ---- launching
		pl("Still loading the version list. One moment.", "Lista wersji wciąż się wczytuje. Chwileczkę.");
		pl("Set a player name first (Settings, 3 to 16 letters, numbers or _).", "Najpierw ustaw nazwę gracza (Ustawienia, od 3 do 16 liter, cyfr lub _).");
		pl("Getting ready", "Przygotowywanie");
		pl("Your Microsoft sign-in expired. Please sign in again in Settings.", "Logowanie Microsoft wygasło. Zaloguj się ponownie w Ustawieniach.");
		pl("Couldn't start: ", "Nie udało się uruchomić: ");
		pl(" is starting. Have fun!", " się uruchamia. Miłej gry!");
		pl("Welcome back.", "Witaj ponownie.");
		pl("Minecraft closed with an error (code ", "Minecraft zamknął się z błędem (kod ");
		pl("). Check the logs in the game folder.", "). Sprawdź logi w folderze gry.");
		pl("MEMORY", "PAMIĘĆ");
		pl("Checking Minecraft ", "Sprawdzanie Minecraft ");
		pl("Checking Java ", "Sprawdzanie Javy ");
		pl("Downloading", "Pobieranie");
		pl("Getting mods for ", "Pobieranie modów dla ");
		pl("Starting Minecraft ", "Uruchamianie Minecraft ");
		pl("Fabric doesn't support ", "Fabric nie obsługuje wersji ");
		pl("Preparing classic sounds and textures", "Przygotowywanie klasycznych dźwięków i tekstur");
		pl("Downloading  ·  ", "Pobieranie  ·  ");

		// ---- presets
		pl("Low-end", "Słaby PC");
		pl("Older laptops, 4 to 8 GB RAM, integrated graphics", "Starsze laptopy, 4 do 8 GB RAM, zintegrowana grafika");
		pl("Balanced", "Zrównoważony");
		pl("Most gaming PCs and newer laptops", "Większość komputerów do gier i nowszych laptopów");
		pl("High-end", "Mocny PC");
		pl("Strong CPU, 16 GB+ RAM, dedicated graphics", "Mocny procesor, 16 GB+ RAM, dedykowana grafika");
		pl("Custom", "Własny");
		pl("Your own memory and mod choices", "Własny wybór pamięci i modów");

		// ---- mod descriptions
		pl("Rewrites the renderer. Usually 2x to 3x the frame rate.", "Nowy silnik renderowania. Zwykle 2 do 3 razy więcej FPS.");
		pl("Faster game logic, mob AI and physics. No visual change.", "Szybsza logika gry, AI mobów i fizyka. Bez zmian w wyglądzie.");
		pl("Cuts memory use, a big help on 4 GB and below.", "Zmniejsza zużycie pamięci, duża pomoc przy 4 GB i mniej.");
		pl("Speeds up HUD, text and entity drawing.", "Przyspiesza rysowanie HUD, tekstu i istot.");
		pl("Skips drawing mobs and chests you can't see.", "Nie rysuje mobów i skrzyń, których nie widać.");
		pl("Faster startup and lower memory use.", "Szybszy start i mniejsze zużycie pamięci.");
		pl("Drops to a few FPS when the game is in the background.", "Ogranicza FPS, gdy gra jest w tle.");
		pl("Lighter networking, smoother on busy servers.", "Lżejsza obsługa sieci, płynniej na zatłoczonych serwerach.");
		pl("Hides even more hidden faces: leaves, signs, item frames.", "Ukrywa jeszcze więcej niewidocznych ścian: liście, tabliczki, ramki.");
		pl("Lots of small caching tweaks that add up on weak CPUs.", "Wiele drobnych usprawnień, które dużo dają na słabych procesorach.");
		pl("Fixes slow memory leaks in older versions.", "Naprawia wycieki pamięci w starszych wersjach.");
		pl("Loads and generates chunks on all your CPU cores.", "Wczytuje i generuje chunki na wszystkich rdzeniach procesora.");
		pl("Run shader packs (Complementary, BSL...) with Sodium.", "Uruchamia shadery (Complementary, BSL...) razem z Sodium.");
		pl("Torches light up the area around you while held.", "Pochodnia w ręce oświetla okolicę.");
		pl("Extra graphics options: fog, particles, animations.", "Dodatkowe opcje grafiki: mgła, cząsteczki, animacje.");
		pl("A cleaner, searchable video settings screen.", "Czytelniejszy ekran ustawień grafiki z wyszukiwaniem.");
		pl("A Mods button on the title screen to configure mods.", "Przycisk Mody na ekranie tytułowym do konfiguracji modów.");
		pl("Better Video Settings", "Lepsze ustawienia grafiki");

		// ---- version notes
		pl("The 2026 drops", "Aktualizacje 2026");
		pl("The newest Minecraft, with a drop every few months. Cherry HUD and the full performance set.", "Najnowszy Minecraft z aktualizacją co kilka miesięcy. Cherry HUD i pełen zestaw modów wydajności.");
		pl("Trial chambers, the breeze, the mace, and a year of drops up to 1.21.11.", "Komnaty prób, bryza, buława i cały rok aktualizacji aż do 1.21.11.");
		pl("Cherry groves, archaeology, camels and sniffers. A big modding version (1.20.1).", "Wiśniowe gaje, archeologia, wielbłądy i węszyciele. Popularna wersja do modów (1.20.1).");
		pl("The deep dark, the warden, mangrove swamps, frogs and allays.", "Głęboki mrok, strażnik, bagna namorzynowe, żaby i allaye.");
		pl("Taller worlds, huge caves and mountains. 1.18.2 is still widely played.", "Wyższe światy, ogromne jaskinie i góry. W 1.18.2 wciąż gra wiele osób.");
		pl("Copper, amethyst, goats, axolotls and glow squid.", "Miedź, ametyst, kozy, aksolotle i świecące kałamarnice.");
		pl("New Nether biomes, piglins and netherite. 1.16.5 is a modding classic.", "Nowe biomy Netheru, piglini i netheryt. 1.16.5 to klasyka modów.");
		pl("Bees, honey and a lot of bug fixes.", "Pszczoły, miód i mnóstwo poprawek błędów.");
		pl("New villages, pillagers and raids. The first version Fabric supports.", "Nowe wioski, rozbójnicy i najazdy. Pierwsza wersja obsługiwana przez Fabric.");
		pl("Oceans come alive: dolphins, coral reefs, shipwrecks.", "Oceany ożywają: delfiny, rafy koralowe, wraki statków.");
		pl("Concrete, glazed terracotta and recipe books.", "Beton, glazurowana terakota i książka receptur.");
		pl("Woodland mansions, llamas and explorer maps.", "Leśne rezydencje, lamy i mapy odkrywcy.");
		pl("Polar bears, strays, husks and fossils.", "Niedźwiedzie polarne, tułacze, posuchy i skamieniałości.");
		pl("Shields, dual wielding and the new attack cooldown.", "Tarcze, druga ręka i nowe odnawianie ataku.");
		pl("The PvP classic. Banners, ocean monuments and slime blocks.", "Klasyka PvP. Sztandary, monumenty oceaniczne i bloki szlamu.");
		pl("New biomes, stained glass and fishing.", "Nowe biomy, barwione szkło i wędkowanie.");
		pl("Horses, hay bales, carpets and the new launcher.", "Konie, bele siana, dywany i nowy launcher.");
		pl("Comparators, hoppers and daylight sensors.", "Komparatory, leje i czujniki światła dziennego.");
		pl("Withers, witches, item frames and anvils.", "Withery, wiedźmy, ramki na przedmioty i kowadła.");
		pl("Trading, emeralds, temples and the Ender chest.", "Handel, szmaragdy, świątynie i skrzynia Kresu.");
		pl("Jungles, ocelots and iron golems.", "Dżungle, oceloty i żelazne golemy.");
		pl("Spawn eggs and the first language support.", "Jaja przywołujące i pierwsze wersje językowe.");
		pl("Where it all became official: the End and the ender dragon.", "Tu wszystko stało się oficjalne: Kres i smok Kresu.");
		pl("2010 to 2011", "2010 do 2011");
		pl("Before 1.0. Pistons, beds, weather. b1.7.3 is the famous one.", "Przed 1.0. Tłoki, łóżka, pogoda. Najsłynniejsza jest b1.7.3.");
		pl("Test builds", "Wersje testowe");
		pl("Weekly previews of upcoming features. Can be unstable, keep backups of your worlds.", "Cotygodniowe zapowiedzi nowości. Mogą być niestabilne, rób kopie zapasowe światów.");
		pl("The early days of Survival. Simple, quiet, nostalgic.", "Początki trybu przetrwania. Prosto, spokojnie, nostalgicznie.");
		pl("A classic Minecraft release.", "Klasyczne wydanie Minecrafta.");

		// ---- Discord
		pl("In the launcher", "W launcherze");
		pl("Picking a version", "Wybiera wersję");
		pl("Playing Minecraft ", "Gra w Minecraft ");
		pl("On ", "Na serwerze ");
		pl("Show on Discord", "Pokazuj na Discordzie");
		pl("Your Discord profile shows the client, version, server and play time", "Twój profil na Discordzie pokaże klienta, wersję, serwer i czas gry");
		pl("Custom Discord application ID (optional)", "Własne ID aplikacji Discord (opcjonalne)");
		pl("Create one at discord.com/developers", "Utwórz je na discord.com/developers");

		pl("Built-in shader pack: shadows, godrays, reflections. Runs on Iris, switch with K in game.", "Wbudowany pakiet shaderów: cienie, promienie słońca, odbicia. Działa przez Iris, w grze przełączasz klawiszem K.");

		// ---- friends and updates
		pl("Friends", "Znajomi");
		pl("Offline", "Offline");
		pl("Playing ", "Gra w ");
		pl("Singleplayer, ", "Jednoosobowa, ");
		pl("Type a player name or a friend code.", "Wpisz nick gracza albo kod znajomego.");
		pl("No Cherry player called ", "Żaden gracz Cherry o nicku ");
		pl(" has been online in the last 12 hours. Ask them for their friend code.", " nie był online przez ostatnie 12 godzin. Poproś o jego kod znajomego.");
		pl("More than one Cherry player is called ", "Kilku graczy Cherry ma nick ");
		pl(". Ask them for their friend code.", ". Poproś o kod znajomego.");
		pl("That isn't a player name or a friend code.", "To nie jest nick ani kod znajomego.");
		pl("That's your own code.", "To twój własny kod.");
		pl(" is already your friend.", " jest już twoim znajomym.");
		pl("You're now friends with ", "Jesteście teraz znajomymi: ");
		pl("Friend request sent to ", "Wysłano zaproszenie do: ");
		pl("New friend", "Nowy znajomy");
		pl(" is now your friend.", " jest teraz twoim znajomym.");
		pl("Friend request", "Zaproszenie do znajomych");
		pl(" wants to be your friend.", " chce zostać twoim znajomym.");
		pl(" accepted your friend request.", " przyjął twoje zaproszenie.");
		pl("is online", "jest online");
		pl("Couldn't reach the friends service. Check your internet.", "Brak połączenia z usługą znajomych. Sprawdź internet.");
		pl("Player name or friend code", "Nick gracza albo kod znajomego");
		pl("Add", "Dodaj");
		pl("Copy", "Kopiuj");
		pl("Copied", "Skopiowano");
		pl("Sending…", "Wysyłanie…");
		pl("Friend request sent", "Wysłano zaproszenie");
		pl("You're now friends", "Jesteście teraz znajomymi");
		pl("Works with offline and Microsoft accounts.", "Działa z kontami offline i Microsoft.");
		pl("YOUR FRIEND CODE", "TWÓJ KOD ZNAJOMEGO");
		pl("Connected", "Połączono");
		pl("Connecting to the friends service…", "Łączenie z usługą znajomych…");
		pl("ADD A FRIEND", "DODAJ ZNAJOMEGO");
		pl("By name: they need to have opened Cherry in the last 12 hours. A friend code always works.", "Po nicku: ta osoba musiała otworzyć Cherry w ciągu ostatnich 12 godzin. Kod znajomego działa zawsze.");
		pl("REQUESTS", "ZAPROSZENIA");
		pl("Decline", "Odrzuć");
		pl("Accept", "Przyjmij");
		pl("SENT", "WYSŁANE");
		pl("Waiting for them to accept", "Czeka na akceptację");
		pl("Your friends", "Twoi znajomi");
		pl(" online", " online");
		pl("No friends yet. Send your code to a friend, or add them by name on the left.", "Nie masz jeszcze znajomych. Wyślij komuś swój kod albo dodaj kogoś po nicku po lewej.");
		pl("Remove", "Usuń");
		pl("Update ", "Aktualizacja ");
		pl(" ready: restart", " gotowa: uruchom ponownie");
		pl("Downloading update ", "Pobieranie aktualizacji ");
		pl("The update installs when you close the game and restart the launcher.", "Aktualizacja zainstaluje się po zamknięciu gry i ponownym uruchomieniu launchera.");
		pl("Close and reopen Cherry Blossom Client to finish the update.", "Zamknij i otwórz ponownie Cherry Blossom Client, aby dokończyć aktualizację.");
		pl("the release has no cherry-launcher.jar", "wydanie nie zawiera pliku cherry-launcher.jar");
		pl("the download was cut short", "pobieranie zostało przerwane");
		pl("the download didn't match its checksum", "pobrany plik ma złą sumę kontrolną");
		pl("that isn't a Cherry launcher", "to nie jest launcher Cherry");

		// ---- server
		pl("Server", "Serwer");
		pl("Mojang has no server download for ", "Mojang nie udostępnia serwera dla wersji ");
		pl("Starting the server", "Uruchamianie serwera");
		pl("server with", "serwer z pamięcią");
		pl("Server stopped", "Serwer zatrzymany");
		pl("Your own server", "Twój własny serwer");
		pl("Runs on this PC. Friends on your Wi-Fi can join with your local IP; for others, forward the port on your router.", "Działa na tym komputerze. Znajomi w Twojej sieci Wi-Fi dołączą przez lokalny adres IP, a inni po przekierowaniu portu na routerze.");
		pl("SERVER MEMORY", "PAMIĘĆ SERWERA");
		pl("Suggested for this PC: ", "Zalecane dla tego komputera: ");
		pl("Server name (shown in the server list)", "Nazwa serwera (widoczna na liście serwerów)");
		pl("Max players", "Maks. graczy");
		pl("Port", "Port");
		pl("DIFFICULTY", "POZIOM TRUDNOŚCI");
		pl("GAME MODE", "TRYB GRY");
		pl("Peaceful", "Spokojny");
		pl("Easy", "Łatwy");
		pl("Normal", "Normalny");
		pl("Hard", "Trudny");
		pl("Survival", "Przetrwanie");
		pl("Creative", "Kreatywny");
		pl("Adventure", "Przygoda");
		pl("Microsoft accounts only", "Tylko konta Microsoft");
		pl("Off lets offline players join. Keep it on for public servers.", "Wyłączone pozwala dołączać graczom offline. Na publicznych serwerach zostaw włączone.");
		pl("PvP", "PvP");
		pl("Players can hurt each other", "Gracze mogą sobie zadawać obrażenia");
		pl("I agree to the Minecraft EULA", "Akceptuję licencję Minecraft (EULA)");
		pl("Required by Mojang to run a server. Read it at aka.ms/MinecraftEULA", "Wymagane przez Mojang do uruchomienia serwera. Treść: aka.ms/MinecraftEULA");
		pl("START SERVER", "URUCHOM SERWER");
		pl("STOP SERVER", "ZATRZYMAJ SERWER");
		pl("STOPPING", "ZATRZYMYWANIE");
		pl("Join", "Dołącz");
		pl("Open server folder", "Otwórz folder serwera");
		pl("Console", "Konsola");
		pl("Type a command, e.g. op YourName, then Enter", "Wpisz komendę, np. op TwojaNazwa, i naciśnij Enter");
		pl("Stopped", "Zatrzymany");
		pl("Preparing", "Przygotowywanie");
		pl("Starting", "Uruchamianie");
		pl("Online", "Online");
		pl("Stopping", "Zatrzymywanie");
		pl("Accept the EULA first.", "Najpierw zaakceptuj EULA.");
		pl("No one online yet", "Nikogo jeszcze nie ma");
		pl("Address for this PC: localhost:", "Adres na tym komputerze: localhost:");
		pl("The server log will show up here.", "Tutaj pojawią się logi serwera.");

		// ---- Microsoft errors
		pl("The sign-in code expired. Please try again.", "Kod logowania wygasł. Spróbuj ponownie.");
		pl("Sign-in was cancelled.", "Logowanie zostało anulowane.");
		pl("Microsoft sign-in failed (", "Logowanie Microsoft nie powiodło się (");
		pl("This Microsoft account has no Xbox profile yet. Sign in once at xbox.com, then try again.", "To konto Microsoft nie ma jeszcze profilu Xbox. Zaloguj się raz na xbox.com i spróbuj ponownie.");
		pl("This is a child account. An adult needs to add it to a Microsoft family first.", "To konto dziecka. Dorosły musi najpierw dodać je do rodziny Microsoft.");
		pl("This account doesn't own Minecraft Java Edition.", "To konto nie ma Minecraft: Java Edition.");
	}
}
