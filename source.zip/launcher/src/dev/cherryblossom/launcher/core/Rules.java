package dev.cherryblossom.launcher.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Evaluates Mojang's library/argument "rules" for this computer and fills in ${placeholders}. */
final class Rules {
	private Rules() {}

	private static final Pattern VAR = Pattern.compile("\\$\\{([a-zA-Z_]+)}");

	static String osName() {
		String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
		if (os.contains("win")) return "windows";
		if (os.contains("mac")) return "osx";
		return "linux";
	}

	static boolean allowed(List<Object> rules, Map<String, Boolean> features) {
		if (rules == null || rules.isEmpty()) return true;
		boolean result = false;
		for (Object o : rules) {
			Map<String, Object> rule = Json.obj(o);
			if (matches(rule, features)) result = "allow".equals(Json.str(rule, "action"));
		}
		return result;
	}

	private static boolean matches(Map<String, Object> rule, Map<String, Boolean> features) {
		Map<String, Object> os = Json.obj(rule, "os");
		if (os != null) {
			String name = Json.str(os, "name");
			if (name != null && !name.equals(osName())) return false;
			String arch = Json.str(os, "arch");
			if ("x86".equals(arch) && System.getProperty("os.arch").contains("64")) return false;
			String version = Json.str(os, "version");
			if (version != null) {
				try {
					if (!Pattern.compile(version).matcher(System.getProperty("os.version")).find()) return false;
				} catch (Exception ignored) {}
			}
		}
		Map<String, Object> wanted = Json.obj(rule, "features");
		if (wanted != null) {
			for (Map.Entry<String, Object> e : wanted.entrySet()) {
				boolean have = features.getOrDefault(e.getKey(), false);
				if (have != Boolean.TRUE.equals(e.getValue())) return false;
			}
		}
		return true;
	}

	/** Expands an "arguments" list: plain strings or {rules, value} objects. */
	static List<String> expand(List<Object> args, Map<String, String> vars, Map<String, Boolean> features) {
		List<String> out = new ArrayList<>();
		for (Object a : args) {
			if (a instanceof String s) {
				out.add(fill(s, vars));
			} else {
				Map<String, Object> m = Json.obj(a);
				if (m == null || !allowed(Json.arr(m, "rules"), features)) continue;
				Object v = m.get("value");
				if (v instanceof String s) out.add(fill(s, vars));
				else for (Object x : Json.arr(v)) out.add(fill(String.valueOf(x), vars));
			}
		}
		return out;
	}

	static String fill(String s, Map<String, String> vars) {
		Matcher m = VAR.matcher(s);
		StringBuilder b = new StringBuilder();
		while (m.find()) {
			String v = vars.get(m.group(1));
			m.appendReplacement(b, Matcher.quoteReplacement(v == null ? "" : v));
		}
		m.appendTail(b);
		return b.toString();
	}
}
