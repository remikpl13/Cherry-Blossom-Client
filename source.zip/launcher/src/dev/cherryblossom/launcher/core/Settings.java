package dev.cherryblossom.launcher.core;

import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Launcher settings, stored in data/cherry-launcher.json. */
public final class Settings {
	// Game
	public String selectedVersion = "";
	public boolean useFabric = true;
	public List<String> recentVersions = new ArrayList<>();

	// Performance
	public Presets.Preset preset = Presets.Preset.BALANCED;
	public int ramMb = 4096;
	public Set<String> enabledMods = new LinkedHashSet<>();
	public boolean cherryHud = true;
	public boolean builtInShaders = true;
	/** Apply the preset's video settings to options.txt on the next launch. */
	public boolean applyVideoPreset = true;

	// Game window
	public int gameWidth = 1280;
	public int gameHeight = 720;
	public boolean fullscreen = false;
	public String extraJvmArgs = "";

	// Launcher
	public Lang.Language language = Lang.systemDefault();
	public boolean hideWhilePlaying = true;
	public boolean discordEnabled = true;
	public String discordAppId = "";
	public boolean showSnapshots = false;

	// Hosting a server on this PC
	public String serverVersion = "";
	public int serverRamMb = 0;
	public String serverMotd = "";
	public int serverMaxPlayers = 10;
	public int serverPort = 25565;
	public String serverDifficulty = "normal";
	public String serverGamemode = "survival";
	public boolean serverOnlineMode = false;
	public boolean serverPvp = true;
	public boolean serverEula = false;

	// Servers for quick join: "name|address"
	public List<String> servers = new ArrayList<>();

	// Accounts
	public String offlineName = "";
	public String microsoftClientId = "";
	public String msRefreshToken = "";
	public String mcAccessToken = "";
	public long mcTokenExpiresAt = 0;
	public String mcName = "";
	public String mcUuid = "";

	private final transient Path file;

	private Settings(Path file) {
		this.file = file;
	}

	public boolean signedIn() {
		return !mcUuid.isEmpty() && !msRefreshToken.isEmpty();
	}

	public void signOut() {
		msRefreshToken = mcAccessToken = mcName = mcUuid = "";
		mcTokenExpiresAt = 0;
	}

	public String playerName() {
		return signedIn() ? mcName : offlineName;
	}

	public void applyPreset(Presets.Preset p) {
		preset = p;
		if (p == Presets.Preset.CUSTOM) return;
		ramMb = Presets.ramMb(p);
		enabledMods = Presets.mods(p);
		applyVideoPreset = true;
	}

	public void markPlayed(String version) {
		recentVersions.remove(version);
		recentVersions.add(0, version);
		while (recentVersions.size() > 6) recentVersions.remove(recentVersions.size() - 1);
	}

	/** Physical memory in MB, or 8 GB if the JVM can't tell us. */
	public static int systemMemoryMb() {
		try {
			var os = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
			return (int) (os.getTotalMemorySize() / (1024 * 1024));
		} catch (Throwable t) {
			return 8192;
		}
	}

	/** The most we let the slider go: leave ~2 GB for Windows and everything else. */
	public static int maxRamMb() {
		int sys = systemMemoryMb();
		int max = Math.max(1024, sys - 2048);
		return Math.min(max, 32768) / 512 * 512;
	}

	public static Settings load(Path file) {
		Settings s = new Settings(file);
		boolean fresh = !Files.exists(file);
		try {
			if (!fresh) {
				Map<String, Object> m = Json.obj(Json.parse(Files.readString(file)));
				s.selectedVersion = str(m, "selectedVersion", "");
				s.useFabric = Json.bool(m, "useFabric", true);
				s.recentVersions = strings(m, "recentVersions");
				try { s.preset = Presets.Preset.valueOf(str(m, "preset", "BALANCED")); } catch (Exception ignored) {}
				s.ramMb = (int) Json.num(m, "ramMb", s.ramMb);
				s.enabledMods = m.containsKey("enabledMods") ? new LinkedHashSet<>(strings(m, "enabledMods")) : Presets.mods(s.preset);
				s.cherryHud = Json.bool(m, "cherryHud", true);
				s.builtInShaders = Json.bool(m, "builtInShaders", true);
				s.applyVideoPreset = Json.bool(m, "applyVideoPreset", false);
				s.gameWidth = (int) Json.num(m, "gameWidth", 1280);
				s.gameHeight = (int) Json.num(m, "gameHeight", 720);
				s.fullscreen = Json.bool(m, "fullscreen", false);
				s.extraJvmArgs = str(m, "extraJvmArgs", "");
				s.hideWhilePlaying = Json.bool(m, "hideWhilePlaying", true);
				s.discordEnabled = Json.bool(m, "discordEnabled", true);
				s.serverVersion = str(m, "serverVersion", "");
				s.serverRamMb = (int) Json.num(m, "serverRamMb", 0);
				s.serverMotd = str(m, "serverMotd", "");
				s.serverMaxPlayers = (int) Json.num(m, "serverMaxPlayers", 10);
				s.serverPort = (int) Json.num(m, "serverPort", 25565);
				s.serverDifficulty = str(m, "serverDifficulty", "normal");
				s.serverGamemode = str(m, "serverGamemode", "survival");
				s.serverOnlineMode = Json.bool(m, "serverOnlineMode", false);
				s.serverPvp = Json.bool(m, "serverPvp", true);
				s.serverEula = Json.bool(m, "serverEula", false);
				s.discordAppId = str(m, "discordAppId", "");
				try { s.language = Lang.Language.valueOf(str(m, "language", Lang.systemDefault().name())); } catch (Exception ignored) {}
				s.showSnapshots = Json.bool(m, "showSnapshots", false);
				s.servers = m.containsKey("servers") ? strings(m, "servers") : defaultServers();
				s.offlineName = str(m, "offlineName", "");
				s.microsoftClientId = str(m, "microsoftClientId", "");
				s.msRefreshToken = str(m, "msRefreshToken", "");
				s.mcAccessToken = str(m, "mcAccessToken", "");
				s.mcTokenExpiresAt = Json.num(m, "mcTokenExpiresAt", 0);
				s.mcName = str(m, "mcName", "");
				s.mcUuid = str(m, "mcUuid", "");
			}
		} catch (Exception e) {
			System.err.println("Could not read settings: " + e);
			fresh = true;
		}
		if (fresh) {
			s.applyPreset(Presets.recommend());
			s.servers = defaultServers();
		}
		s.ramMb = Math.max(1024, Math.min(maxRamMb(), s.ramMb));
		return s;
	}

	private static List<String> defaultServers() {
		return new ArrayList<>(List.of("Hypixel|mc.hypixel.net", "CubeCraft|play.cubecraft.net", "Wynncraft|play.wynncraft.com"));
	}

	private static String str(Map<String, Object> m, String k, String def) {
		String v = Json.str(m, k);
		return v == null ? def : v;
	}

	private static List<String> strings(Map<String, Object> m, String k) {
		List<String> out = new ArrayList<>();
		for (Object o : Json.arr(m, k)) if (o != null) out.add(o.toString());
		return out;
	}

	public synchronized void save() {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("selectedVersion", selectedVersion);
		m.put("useFabric", useFabric);
		m.put("recentVersions", new ArrayList<>(recentVersions));
		m.put("preset", preset.name());
		m.put("ramMb", ramMb);
		m.put("enabledMods", new ArrayList<>(enabledMods));
		m.put("cherryHud", cherryHud);
		m.put("builtInShaders", builtInShaders);
		m.put("applyVideoPreset", applyVideoPreset);
		m.put("gameWidth", gameWidth);
		m.put("gameHeight", gameHeight);
		m.put("fullscreen", fullscreen);
		m.put("extraJvmArgs", extraJvmArgs);
		m.put("hideWhilePlaying", hideWhilePlaying);
		m.put("discordEnabled", discordEnabled);
		m.put("serverVersion", serverVersion);
		m.put("serverRamMb", serverRamMb);
		m.put("serverMotd", serverMotd);
		m.put("serverMaxPlayers", serverMaxPlayers);
		m.put("serverPort", serverPort);
		m.put("serverDifficulty", serverDifficulty);
		m.put("serverGamemode", serverGamemode);
		m.put("serverOnlineMode", serverOnlineMode);
		m.put("serverPvp", serverPvp);
		m.put("serverEula", serverEula);
		m.put("discordAppId", discordAppId);
		m.put("language", language.name());
		m.put("showSnapshots", showSnapshots);
		m.put("servers", new ArrayList<>(servers));
		m.put("offlineName", offlineName);
		m.put("microsoftClientId", microsoftClientId);
		m.put("msRefreshToken", msRefreshToken);
		m.put("mcAccessToken", mcAccessToken);
		m.put("mcTokenExpiresAt", mcTokenExpiresAt);
		m.put("mcName", mcName);
		m.put("mcUuid", mcUuid);
		try {
			Files.createDirectories(file.getParent());
			Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
			Files.writeString(tmp, Json.write(m));
			Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			System.err.println("Could not save settings: " + e);
		}
	}
}
