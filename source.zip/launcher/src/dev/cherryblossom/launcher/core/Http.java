package dev.cherryblossom.launcher.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.LongConsumer;

/** HTTP helpers: JSON calls and verified, retried file downloads. */
public final class Http {
	private Http() {}

	private static final String UA = "CherryBlossomClient/1.0 (launcher)";
	private static final HttpClient CLIENT = HttpClient.newBuilder()
			.followRedirects(HttpClient.Redirect.NORMAL)
			.connectTimeout(Duration.ofSeconds(15))
			.build();

	public static final class HttpError extends IOException {
		public final int status;
		public final String body;

		HttpError(int status, String body, String url) {
			super("HTTP " + status + " from " + url);
			this.status = status;
			this.body = body;
		}
	}

	public static String get(String url) throws IOException {
		return send(HttpRequest.newBuilder(URI.create(url)).GET(), url, null);
	}

	public static String get(String url, String bearer) throws IOException {
		return send(HttpRequest.newBuilder(URI.create(url)).GET(), url, bearer);
	}

	public static Map<String, Object> getJson(String url) throws IOException {
		return Json.obj(Json.parse(get(url)));
	}

	public static Object getJsonAny(String url) throws IOException {
		return Json.parse(get(url));
	}

	public static Map<String, Object> postJson(String url, Object body) throws IOException {
		HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url))
				.header("Content-Type", "application/json")
				.header("Accept", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(Json.write(body)));
		return Json.obj(Json.parse(send(b, url, null)));
	}

	public static Map<String, Object> postForm(String url, Map<String, String> form) throws IOException {
		StringJoiner j = new StringJoiner("&");
		form.forEach((k, v) -> j.add(URLEncoder.encode(k, StandardCharsets.UTF_8) + "=" + URLEncoder.encode(v, StandardCharsets.UTF_8)));
		HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url))
				.header("Content-Type", "application/x-www-form-urlencoded")
				.POST(HttpRequest.BodyPublishers.ofString(j.toString()));
		return Json.obj(Json.parse(send(b, url, null)));
	}

	private static String send(HttpRequest.Builder b, String url, String bearer) throws IOException {
		b.header("User-Agent", UA).timeout(Duration.ofSeconds(30));
		if (bearer != null) b.header("Authorization", "Bearer " + bearer);
		try {
			HttpResponse<String> r = CLIENT.send(b.build(), HttpResponse.BodyHandlers.ofString());
			if (r.statusCode() / 100 != 2) throw new HttpError(r.statusCode(), r.body(), url);
			return r.body();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new IOException("Interrupted", e);
		}
	}

	/**
	 * Downloads to {@code target} via a temp file, verifying SHA-1 when given.
	 * Retries a few times because thousands of small asset files will hit the odd hiccup.
	 */
	public static void download(String url, Path target, String sha1, LongConsumer bytes) throws IOException {
		IOException last = null;
		for (int attempt = 0; attempt < 4; attempt++) {
			try {
				downloadOnce(url, target, sha1, bytes);
				return;
			} catch (IOException e) {
				last = e;
				try { Thread.sleep(400L * (attempt + 1)); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw e; }
			}
		}
		throw last;
	}

	private static void downloadOnce(String url, Path target, String sha1, LongConsumer bytes) throws IOException {
		Files.createDirectories(target.getParent());
		Path tmp = target.resolveSibling(target.getFileName() + ".part");
		HttpRequest req = HttpRequest.newBuilder(URI.create(url)).header("User-Agent", UA).timeout(Duration.ofMinutes(5)).GET().build();
		MessageDigest md = sha1 == null ? null : sha1();
		try {
			HttpResponse<InputStream> r = CLIENT.send(req, HttpResponse.BodyHandlers.ofInputStream());
			if (r.statusCode() / 100 != 2) {
				r.body().close();
				throw new HttpError(r.statusCode(), "", url);
			}
			try (InputStream in = r.body(); OutputStream out = Files.newOutputStream(tmp)) {
				byte[] buf = new byte[64 * 1024];
				int n;
				while ((n = in.read(buf)) > 0) {
					out.write(buf, 0, n);
					if (md != null) md.update(buf, 0, n);
					if (bytes != null) bytes.accept(n);
				}
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new IOException("Interrupted", e);
		}
		if (md != null) {
			String got = HexFormat.of().formatHex(md.digest());
			if (!got.equalsIgnoreCase(sha1)) {
				Files.deleteIfExists(tmp);
				throw new IOException("Checksum mismatch for " + url);
			}
		}
		Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
	}

	public static String sha1Of(Path file) throws IOException {
		MessageDigest md = sha1();
		try (InputStream in = Files.newInputStream(file)) {
			byte[] buf = new byte[64 * 1024];
			int n;
			while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
		}
		return HexFormat.of().formatHex(md.digest());
	}

	private static MessageDigest sha1() {
		try {
			return MessageDigest.getInstance("SHA-1");
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}
}
