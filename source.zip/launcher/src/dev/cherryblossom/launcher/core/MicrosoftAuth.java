package dev.cherryblossom.launcher.core;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * Microsoft account sign-in using the device-code flow: you sign in on Microsoft's own website,
 * the launcher never sees your password. Requires an Azure app (client) ID with Minecraft API access.
 */
public final class MicrosoftAuth {
	private static final String DEVICE = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
	private static final String TOKEN = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
	private static final String SCOPE = "XboxLive.signin offline_access";

	private MicrosoftAuth() {}

	public record DeviceCode(String userCode, String verificationUri, String deviceCode, int interval, long expiresAt) {}

	public static DeviceCode start(String clientId) throws IOException {
		Map<String, Object> r = Http.postForm(DEVICE, Map.of("client_id", clientId, "scope", SCOPE));
		return new DeviceCode(
				Json.str(r, "user_code"),
				Json.str(r, "verification_uri"),
				Json.str(r, "device_code"),
				(int) Json.num(r, "interval", 5),
				System.currentTimeMillis() + Json.num(r, "expires_in", 900) * 1000);
	}

	/** Polls until the player finishes signing in in the browser, then signs in to Minecraft. */
	public static void finish(String clientId, DeviceCode code, Settings settings, BooleanSupplier cancelled) throws Exception {
		int interval = Math.max(1, code.interval());
		while (!cancelled.getAsBoolean()) {
			if (System.currentTimeMillis() > code.expiresAt()) throw new IOException(Lang.t("The sign-in code expired. Please try again."));
			Thread.sleep(interval * 1000L);
			try {
				Map<String, Object> t = Http.postForm(TOKEN, Map.of(
						"grant_type", "urn:ietf:params:oauth:grant-type:device_code",
						"client_id", clientId,
						"device_code", code.deviceCode()));
				minecraftLogin(Json.str(t, "access_token"), Json.str(t, "refresh_token"), settings);
				return;
			} catch (Http.HttpError e) {
				String err = errorCode(e.body);
				if ("authorization_pending".equals(err)) continue;
				if ("slow_down".equals(err)) { interval += 5; continue; }
				if ("authorization_declined".equals(err)) throw new IOException(Lang.t("Sign-in was cancelled."));
				throw new IOException(Lang.t("Microsoft sign-in failed (") + (err == null ? e.status : err) + ").");
			}
		}
	}

	/** Refreshes the Minecraft token if it's close to expiring. Returns false if the player must sign in again. */
	public static boolean refresh(Settings s) {
		if (!s.signedIn()) return false;
		if (System.currentTimeMillis() < s.mcTokenExpiresAt - 10 * 60_000) return true;
		if (s.microsoftClientId.isBlank()) return false;
		try {
			Map<String, Object> t = Http.postForm(TOKEN, Map.of(
					"grant_type", "refresh_token",
					"client_id", s.microsoftClientId,
					"refresh_token", s.msRefreshToken,
					"scope", SCOPE));
			minecraftLogin(Json.str(t, "access_token"), Json.str(t, "refresh_token"), s);
			return true;
		} catch (Exception e) {
			System.err.println("Token refresh failed: " + e.getMessage());
			return false;
		}
	}

	private static void minecraftLogin(String msToken, String refreshToken, Settings s) throws IOException {
		Map<String, Object> xbl = Http.postJson("https://user.auth.xboxlive.com/user/authenticate", Map.of(
				"Properties", Map.of("AuthMethod", "RPS", "SiteName", "user.auth.xboxlive.com", "RpsTicket", "d=" + msToken),
				"RelyingParty", "http://auth.xboxlive.com",
				"TokenType", "JWT"));
		String xblToken = Json.str(xbl, "Token");

		Map<String, Object> xsts;
		try {
			xsts = Http.postJson("https://xsts.auth.xboxlive.com/xsts/authorize", Map.of(
					"Properties", Map.of("SandboxId", "RETAIL", "UserTokens", List.of(xblToken)),
					"RelyingParty", "rp://api.minecraftservices.com/",
					"TokenType", "JWT"));
		} catch (Http.HttpError e) {
			if (e.body.contains("2148916233")) throw new IOException(Lang.t("This Microsoft account has no Xbox profile yet. Sign in once at xbox.com, then try again."));
			if (e.body.contains("2148916238")) throw new IOException(Lang.t("This is a child account. An adult needs to add it to a Microsoft family first."));
			throw e;
		}
		String uhs = Json.str(Json.obj(Json.arr(Json.obj(xsts, "DisplayClaims"), "xui").get(0)), "uhs");
		String xstsToken = Json.str(xsts, "Token");

		Map<String, Object> mc = Http.postJson("https://api.minecraftservices.com/authentication/login_with_xbox",
				Map.of("identityToken", "XBL3.0 x=" + uhs + ";" + xstsToken));
		String access = Json.str(mc, "access_token");
		long expires = Json.num(mc, "expires_in", 86400);

		Map<String, Object> profile;
		try {
			profile = Json.obj(Json.parse(Http.get("https://api.minecraftservices.com/minecraft/profile", access)));
		} catch (Http.HttpError e) {
			if (e.status == 404) throw new IOException(Lang.t("This account doesn't own Minecraft Java Edition."));
			throw e;
		}

		s.mcAccessToken = access;
		s.mcTokenExpiresAt = System.currentTimeMillis() + expires * 1000;
		s.msRefreshToken = refreshToken == null ? "" : refreshToken;
		s.mcName = Json.str(profile, "name");
		s.mcUuid = Json.str(profile, "id");
		s.save();
	}

	private static String errorCode(String body) {
		try {
			return Json.str(Json.obj(Json.parse(body)), "error");
		} catch (Exception e) {
			return null;
		}
	}
}
