package dev.cherryblossom.launcher.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tiny JSON reader/writer so the launcher has zero dependencies.
 * Objects become LinkedHashMap, arrays ArrayList, numbers Double.
 */
public final class Json {
	private final String s;
	private int i;

	private Json(String s) {
		this.s = s;
	}

	public static Object parse(String text) {
		Json p = new Json(text);
		p.ws();
		Object v = p.value();
		p.ws();
		if (p.i != p.s.length()) throw p.err("trailing characters");
		return v;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> obj(Object o) {
		return o instanceof Map ? (Map<String, Object>) o : null;
	}

	@SuppressWarnings("unchecked")
	public static List<Object> arr(Object o) {
		return o instanceof List ? (List<Object>) o : List.of();
	}

	public static Map<String, Object> obj(Map<String, Object> m, String key) {
		return m == null ? null : obj(m.get(key));
	}

	public static List<Object> arr(Map<String, Object> m, String key) {
		return m == null ? List.of() : arr(m.get(key));
	}

	public static String str(Map<String, Object> m, String key) {
		Object o = m == null ? null : m.get(key);
		return o == null ? null : o.toString();
	}

	public static long num(Map<String, Object> m, String key, long def) {
		Object o = m == null ? null : m.get(key);
		return o instanceof Number n ? n.longValue() : def;
	}

	public static boolean bool(Map<String, Object> m, String key, boolean def) {
		Object o = m == null ? null : m.get(key);
		return o instanceof Boolean b ? b : def;
	}

	private RuntimeException err(String msg) {
		return new IllegalArgumentException("JSON " + msg + " at " + i);
	}

	private void ws() {
		while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
	}

	private Object value() {
		if (i >= s.length()) throw err("unexpected end");
		char c = s.charAt(i);
		switch (c) {
			case '{': return object();
			case '[': return array();
			case '"': return string();
			case 't': expect("true"); return Boolean.TRUE;
			case 'f': expect("false"); return Boolean.FALSE;
			case 'n': expect("null"); return null;
			default: return number();
		}
	}

	private void expect(String word) {
		if (!s.startsWith(word, i)) throw err("expected " + word);
		i += word.length();
	}

	private Map<String, Object> object() {
		Map<String, Object> m = new LinkedHashMap<>();
		i++;
		ws();
		if (s.charAt(i) == '}') { i++; return m; }
		while (true) {
			ws();
			String k = string();
			ws();
			if (s.charAt(i++) != ':') throw err("expected :");
			ws();
			m.put(k, value());
			ws();
			char c = s.charAt(i++);
			if (c == '}') return m;
			if (c != ',') throw err("expected , or }");
		}
	}

	private List<Object> array() {
		List<Object> l = new ArrayList<>();
		i++;
		ws();
		if (s.charAt(i) == ']') { i++; return l; }
		while (true) {
			ws();
			l.add(value());
			ws();
			char c = s.charAt(i++);
			if (c == ']') return l;
			if (c != ',') throw err("expected , or ]");
		}
	}

	private String string() {
		if (s.charAt(i) != '"') throw err("expected string");
		i++;
		StringBuilder b = new StringBuilder();
		while (true) {
			char c = s.charAt(i++);
			if (c == '"') return b.toString();
			if (c == '\\') {
				char e = s.charAt(i++);
				switch (e) {
					case 'n' -> b.append('\n');
					case 't' -> b.append('\t');
					case 'r' -> b.append('\r');
					case 'b' -> b.append('\b');
					case 'f' -> b.append('\f');
					case 'u' -> { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
					default -> b.append(e);
				}
			} else {
				b.append(c);
			}
		}
	}

	private Double number() {
		int start = i;
		while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
		if (start == i) throw err("unexpected character");
		return Double.parseDouble(s.substring(start, i));
	}

	// ---- writing ----

	public static String write(Object o) {
		StringBuilder b = new StringBuilder();
		write(b, o, 0);
		return b.toString();
	}

	private static void write(StringBuilder b, Object o, int indent) {
		if (o == null) b.append("null");
		else if (o instanceof String str) quote(b, str);
		else if (o instanceof Number n) {
			double d = n.doubleValue();
			if (d == Math.rint(d) && Math.abs(d) < 1e15) b.append((long) d); else b.append(d);
		} else if (o instanceof Boolean) b.append(o);
		else if (o instanceof Map<?, ?> m) {
			b.append("{");
			boolean first = true;
			for (Map.Entry<?, ?> e : m.entrySet()) {
				b.append(first ? "\n" : ",\n");
				first = false;
				b.append("  ".repeat(indent + 1));
				quote(b, String.valueOf(e.getKey()));
				b.append(": ");
				write(b, e.getValue(), indent + 1);
			}
			if (!first) b.append("\n").append("  ".repeat(indent));
			b.append("}");
		} else if (o instanceof List<?> l) {
			b.append("[");
			for (int k = 0; k < l.size(); k++) {
				if (k > 0) b.append(", ");
				write(b, l.get(k), indent + 1);
			}
			b.append("]");
		} else quote(b, o.toString());
	}

	private static void quote(StringBuilder b, String s) {
		b.append('"');
		for (int k = 0; k < s.length(); k++) {
			char c = s.charAt(k);
			switch (c) {
				case '"' -> b.append("\\\"");
				case '\\' -> b.append("\\\\");
				case '\n' -> b.append("\\n");
				case '\r' -> b.append("\\r");
				case '\t' -> b.append("\\t");
				default -> {
					if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
				}
			}
		}
		b.append('"');
	}
}
