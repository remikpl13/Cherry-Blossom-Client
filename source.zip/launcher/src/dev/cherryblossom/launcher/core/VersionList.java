package dev.cherryblossom.launcher.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Every Minecraft version Mojang publishes, from Alpha to today, grouped into
 * "families" (26, 1.21, 1.20 ... 1.0, Beta, Alpha) for the versions page.
 */
public final class VersionList {
	private static final String MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

	public enum Kind { RELEASE, SNAPSHOT, BETA, ALPHA }

	public record Version(String id, Kind kind, String url, String sha1, int year, String releaseTime) {}

	/** A family of versions shown as one card, newest version first. */
	public record Family(String key, String title, Kind kind, List<Version> versions) {
		public Version latest() { return versions.get(0); }
		public int year() { return versions.get(versions.size() - 1).year(); }
	}

	private final List<Version> all;
	private final String latestRelease;

	private VersionList(List<Version> all, String latestRelease) {
		this.all = all;
		this.latestRelease = latestRelease;
	}

	public static VersionList load(Path cacheDir) throws IOException {
		Path cache = cacheDir.resolve("version_manifest.json");
		String text;
		try {
			text = Http.get(MANIFEST);
			Files.createDirectories(cacheDir);
			Files.writeString(cache, text);
		} catch (IOException e) {
			if (!Files.exists(cache)) throw e; // offline: use what we saw last time
			text = Files.readString(cache);
		}
		Map<String, Object> m = Json.obj(Json.parse(text));
		List<Version> list = new ArrayList<>();
		for (Object o : Json.arr(m, "versions")) {
			Map<String, Object> v = Json.obj(o);
			Kind kind = switch (String.valueOf(Json.str(v, "type"))) {
				case "release" -> Kind.RELEASE;
				case "old_beta" -> Kind.BETA;
				case "old_alpha" -> Kind.ALPHA;
				default -> Kind.SNAPSHOT;
			};
			String time = Json.str(v, "releaseTime");
			int year = 2009;
			try { year = OffsetDateTime.parse(time).getYear(); } catch (Exception ignored) {}
			list.add(new Version(Json.str(v, "id"), kind, Json.str(v, "url"), Json.str(v, "sha1"), year, time));
		}
		return new VersionList(list, Json.str(Json.obj(m, "latest"), "release"));
	}

	public String latestRelease() {
		return latestRelease;
	}

	public Version find(String id) {
		for (Version v : all) if (v.id().equals(id)) return v;
		return null;
	}

	public List<Version> snapshots() {
		List<Version> out = new ArrayList<>();
		for (Version v : all) if (v.kind() == Kind.SNAPSHOT) out.add(v);
		return out;
	}

	/** Releases grouped by family, newest first, then Beta and Alpha. */
	public List<Family> families() {
		Map<String, List<Version>> groups = new LinkedHashMap<>();
		for (Version v : all) {
			String key = switch (v.kind()) {
				case RELEASE -> familyKey(v.id());
				case BETA -> "Beta";
				case ALPHA -> "Alpha";
				default -> null;
			};
			if (key != null) groups.computeIfAbsent(key, k -> new ArrayList<>()).add(v);
		}
		List<Family> out = new ArrayList<>();
		for (Map.Entry<String, List<Version>> e : groups.entrySet()) {
			Kind kind = e.getValue().get(0).kind();
			out.add(new Family(e.getKey(), VersionInfo.title(e.getKey()), kind, e.getValue()));
		}
		return out;
	}

	/** "1.21.11" -> "1.21", "26.3" -> "26", "1.8" -> "1.8". */
	public static String familyKey(String id) {
		String[] p = id.split("\\.");
		if (p.length >= 1 && !p[0].equals("1")) return p[0];
		return p.length >= 2 ? p[0] + "." + p[1] : id;
	}
}
