package dev.cherryblossom.launcher.core;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Reads fabric.mod.json from every jar in a mods folder (including jars nested inside jars)
 * so we can tell which required mods are missing before the game ever starts.
 */
final class ModDeps {
	private ModDeps() {}

	/** Mod ids that are always there: the game, Java, the loader and what it bundles. */
	private static final Set<String> BUILT_IN = Set.of("minecraft", "java", "fabricloader", "fabric-loader", "mixinextras");

	record ModJar(Path file, Set<String> ids, Set<String> depends) {}

	static List<ModJar> scan(Path dir) throws IOException {
		List<ModJar> out = new ArrayList<>();
		if (!Files.isDirectory(dir)) return out;
		try (var files = Files.list(dir)) {
			for (Path p : (Iterable<Path>) files::iterator) {
				if (!p.getFileName().toString().endsWith(".jar")) continue;
				Set<String> ids = new HashSet<>(), deps = new HashSet<>();
				try (InputStream in = Files.newInputStream(p)) {
					read(in, ids, deps, true, 0);
				} catch (Exception e) {
					continue; // not a mod jar we can read; leave it alone
				}
				out.add(new ModJar(p, ids, deps));
			}
		}
		return out;
	}

	private static void read(InputStream in, Set<String> ids, Set<String> deps, boolean top, int depth) throws IOException {
		ZipInputStream zin = new ZipInputStream(in);
		ZipEntry e;
		while ((e = zin.getNextEntry()) != null) {
			String n = e.getName();
			if (n.equals("fabric.mod.json")) {
				String json = new String(zin.readAllBytes(), StandardCharsets.UTF_8);
				Map<String, Object> m = Json.obj(Json.parse(stripComments(json)));
				String id = Json.str(m, "id");
				if (id != null) ids.add(id);
				for (Object o : Json.arr(m, "provides")) ids.add(String.valueOf(o));
				Map<String, Object> d = Json.obj(m, "depends");
				if (top && d != null) deps.addAll(d.keySet());
			} else if (n.startsWith("META-INF/jars/") && n.endsWith(".jar") && depth < 3) {
				// Jar-in-jar: what's bundled inside counts as provided, but its own needs don't matter here.
				read(new ByteArrayInputStream(zin.readAllBytes()), ids, new HashSet<>(), false, depth + 1);
			}
		}
	}

	private static String stripComments(String s) {
		return s.replaceAll("(?m)^\\s*//.*$", "");
	}

	/** Missing dependency ids per jar. */
	static Map<Path, Set<String>> missing(List<ModJar> jars) {
		Set<String> provided = new HashSet<>(BUILT_IN);
		for (ModJar j : jars) provided.addAll(j.ids());
		Map<Path, Set<String>> out = new LinkedHashMap<>();
		for (ModJar j : jars) {
			Set<String> miss = new HashSet<>();
			for (String d : j.depends()) if (!provided.contains(d)) miss.add(d);
			if (!miss.isEmpty()) out.put(j.file(), miss);
		}
		return out;
	}

	/** Best guess at the Modrinth project for a mod id. */
	static List<String> modrinthGuesses(String modId) {
		List<String> g = new ArrayList<>();
		switch (modId) {
			case "fabric" -> g.add("fabric-api");
			case "cloth-config2", "cloth_config" -> g.add("cloth-config");
			case "yet_another_config_lib_v3", "yet-another-config-lib" -> g.add("yacl");
			default -> {}
		}
		g.add(modId);
		if (modId.contains("_")) g.add(modId.replace('_', '-'));
		return g;
	}
}
