package dev.cherryblossom.launcher.core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Lets the Cherry HUD mod in game see and change the friends list. Only listens on this PC
 * (127.0.0.1) and needs a random token passed to the game on its command line.
 * One JSON object per line each way.
 */
public final class FriendsBridge {
	private final Friends friends;
	private final String token = HexFormat.of().formatHex(new SecureRandom().generateSeed(16));
	private final List<OutputStream> clients = new CopyOnWriteArrayList<>();
	private int port;

	public FriendsBridge(Friends friends) {
		this.friends = friends;
		friends.listen(this::broadcastState);
		friends.onNotice((title, text) -> broadcast(Map.of("type", "toast", "title", title, "text", text)));
	}

	public void start() {
		try {
			ServerSocket ss = new ServerSocket(0, 4, InetAddress.getLoopbackAddress());
			port = ss.getLocalPort();
			Thread t = new Thread(() -> {
				while (true) {
					try {
						Socket s = ss.accept();
						Thread c = new Thread(() -> serve(s), "cherry-bridge-client");
						c.setDaemon(true);
						c.start();
					} catch (Exception e) { return; }
				}
			}, "cherry-bridge");
			t.setDaemon(true);
			t.start();
		} catch (Exception e) {
			System.err.println("Friends bridge off: " + e);
		}
	}

	/** The JVM argument the game needs to find us. */
	public String jvmArg() {
		return port == 0 ? null : "-Dcherry.friends=" + port + ":" + token;
	}

	private void serve(Socket s) {
		OutputStream out = null;
		try (s) {
			s.setTcpNoDelay(true);
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
			if (!token.equals(in.readLine())) return;
			out = s.getOutputStream();
			clients.add(out);
			write(out, state());
			String line;
			while ((line = in.readLine()) != null) {
				Map<String, Object> m = Json.obj(Json.parse(line));
				String cmd = Json.str(m, "cmd"), arg = Json.str(m, "arg");
				if (cmd == null) continue;
				switch (cmd) {
					case "add" -> {
						String result;
						try { result = friends.add(arg == null ? "" : arg); } catch (Exception e) { result = Lang.t("Couldn't reach the friends service. Check your internet."); }
						write(out, Map.of("type", "result", "text", result));
					}
					case "accept" -> friends.accept(arg);
					case "decline" -> friends.decline(arg);
					case "remove" -> friends.remove(arg);
					case "cancel" -> friends.cancel(arg);
					case "server" -> friends.setServer(arg);
					default -> {}
				}
			}
		} catch (Exception ignored) {
		} finally {
			if (out != null) clients.remove(out);
		}
	}

	private Map<String, Object> state() {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("type", "state");
		m.put("code", friends.prettyCode());
		m.put("connected", friends.connected());
		List<Object> fl = new ArrayList<>();
		List<Friends.Friend> sorted = new ArrayList<>(friends.friends);
		sorted.sort((a, b) -> a.online() != b.online() ? (a.online() ? -1 : 1) : a.name.compareToIgnoreCase(b.name));
		for (Friends.Friend f : sorted) {
			Map<String, Object> fm = new LinkedHashMap<>();
			fm.put("code", f.code); fm.put("name", f.name); fm.put("online", f.online()); fm.put("activity", f.activity());
			String j = f.joinable();
			fm.put("server", j == null ? "" : j);
			fl.add(fm);
		}
		m.put("friends", fl);
		m.put("incoming", reqs(friends.incoming));
		m.put("outgoing", reqs(friends.outgoing));
		return m;
	}

	private static List<Object> reqs(List<Friends.Request> list) {
		List<Object> out = new ArrayList<>();
		for (Friends.Request r : list) out.add(Map.of("code", r.code(), "name", r.name()));
		return out;
	}

	private void broadcastState() {
		if (!clients.isEmpty()) broadcast(state());
	}

	private void broadcast(Map<String, Object> m) {
		for (OutputStream o : clients) {
			try { write(o, m); } catch (Exception e) { clients.remove(o); }
		}
	}

	private static void write(OutputStream o, Map<String, Object> m) throws Exception {
		synchronized (o) {
			o.write((Json.write(m).replace("\n", " ") + "\n").getBytes(StandardCharsets.UTF_8));
			o.flush();
		}
	}
}
