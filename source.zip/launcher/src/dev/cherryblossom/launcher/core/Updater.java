package dev.cherryblossom.launcher.core;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;

/**
 * Keeps every copy of the client up to date.
 *
 * The launcher folder holds update.txt with either a GitHub repository ("owner/repo", newest release
 * with a cherry-launcher.jar attached) or a link to a small JSON file:
 *   {"version": "2.2.0", "url": "https://.../cherry-launcher.jar", "sha256": "...", "notes": "..."}
 * A newer launcher is downloaded next to the current one as cherry-launcher.jar.new and the exe
 * swaps it in the next time it starts.
 */
public final class Updater {
	/** Bump this for every release. */
	public static final String VERSION = "2.1.0";

	public enum State { OFF, CHECKING, UP_TO_DATE, DOWNLOADING, READY, FAILED }

	private final Path launcherDir;
	public volatile State state = State.OFF;
	public volatile String latest = "", notes = "", error = "";
	public volatile float progress;
	private Runnable onChange = () -> {};

	public Updater(Path launcherDir) {
		this.launcherDir = launcherDir;
	}

	public void onChange(Runnable r) { onChange = r; }

	public String source() {
		try {
			Path f = launcherDir.resolve("update.txt");
			if (!Files.exists(f)) return "";
			for (String line : Files.readAllLines(f)) {
				line = line.trim();
				if (!line.isEmpty() && !line.startsWith("#")) return line;
			}
		} catch (Exception ignored) {}
		return "";
	}

	/** Checks now and every three hours. */
	public void start() {
		Thread t = new Thread(() -> {
			while (true) {
				check();
				if (state == State.READY) return;
				try { Thread.sleep(3 * 3600_000L); } catch (InterruptedException e) { return; }
			}
		}, "cherry-updater");
		t.setDaemon(true);
		t.start();
	}

	public void check() {
		String src = source();
		if (src.isEmpty()) { set(State.OFF); return; }
		set(State.CHECKING);
		try {
			String version, url, sha = null;
			long size = -1;
			if (src.startsWith("http")) {
				Map<String, Object> m = Http.getJson(src);
				version = Json.str(m, "version");
				url = Json.str(m, "url");
				sha = Json.str(m, "sha256");
				notes = String.valueOf(Json.str(m, "notes") == null ? "" : Json.str(m, "notes"));
			} else {
				Map<String, Object> m = Http.getJson("https://api.github.com/repos/" + src.replaceAll("^https?://github.com/", "").replaceAll("/+$", "") + "/releases/latest");
				version = Json.str(m, "tag_name");
				notes = Json.str(m, "body") == null ? "" : Json.str(m, "body");
				url = null;
				for (Object o : Json.arr(m, "assets")) {
					Map<String, Object> a = Json.obj(o);
					if ("cherry-launcher.jar".equals(Json.str(a, "name"))) {
						url = Json.str(a, "browser_download_url");
						size = Json.num(a, "size", -1);
					}
				}
			}
			if (version == null || url == null) throw new IllegalStateException(Lang.t("the release has no cherry-launcher.jar"));
			version = version.replaceFirst("^[vV]", "");
			latest = version;
			if (compare(version, VERSION) <= 0) { set(State.UP_TO_DATE); return; }

			set(State.DOWNLOADING);
			Path part = launcherDir.resolve("cherry-launcher.jar.part");
			long expected = size;
			Http.download(url, part, null, n -> { if (expected > 0) { progress = (float) n / expected; onChange.run(); } });
			if (size > 0 && Files.size(part) != size) throw new IllegalStateException(Lang.t("the download was cut short"));
			if (sha != null && !sha.isBlank()) {
				String got = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(part)));
				if (!got.equalsIgnoreCase(sha.trim())) { Files.deleteIfExists(part); throw new IllegalStateException(Lang.t("the download didn't match its checksum")); }
			}
			try (var zip = new java.util.zip.ZipFile(part.toFile())) {
				if (zip.getEntry("dev/cherryblossom/launcher/Main.class") == null) throw new IllegalStateException(Lang.t("that isn't a Cherry launcher"));
			}
			Files.move(part, launcherDir.resolve("cherry-launcher.jar.new"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			set(State.READY);
		} catch (Exception e) {
			error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
			set(State.FAILED);
		}
	}

	/** Starts the exe again (which installs the update) and lets this launcher close. */
	public boolean restart() {
		Path exe = launcherDir.getParent().resolve("Cherry Blossom Client.exe");
		if (!Files.exists(exe)) return false;
		try {
			new ProcessBuilder(exe.toString()).directory(launcherDir.getParent().toFile()).start();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	private void set(State s) {
		state = s;
		onChange.run();
	}

	/** Compares 2.10.1 and 2.9 the way people expect. */
	static int compare(String a, String b) {
		String[] x = a.split("[.\\-+]"), y = b.split("[.\\-+]");
		for (int i = 0; i < Math.max(x.length, y.length); i++) {
			int p = i < x.length ? num(x[i]) : 0, q = i < y.length ? num(y[i]) : 0;
			if (p != q) return Integer.compare(p, q);
		}
		return 0;
	}

	private static int num(String s) {
		try { return Integer.parseInt(s.replaceAll("\\D", "")); } catch (Exception e) { return 0; }
	}
}
