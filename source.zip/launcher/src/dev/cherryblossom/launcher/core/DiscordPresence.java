package dev.cherryblossom.launcher.core;

import java.io.Closeable;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Discord Rich Presence over Discord's local IPC pipe (no SDK, no extra files).
 * Shows "Playing Cherry Blossom Client" with the version, server and play time.
 * Everything runs on one background thread and silently retries if Discord isn't open.
 */
public final class DiscordPresence {
	/** What we'd like Discord to show; null means clear it. */
	private record Activity(String details, String state, long start) {}

	/** The Cherry Blossom Client app on Discord. A custom ID in Settings overrides it. */
	public static final String DEFAULT_APP_ID = "1562187713833209927";

	private final Settings settings;
	private volatile Activity wanted;
	private volatile boolean dirty = true;
	private Pipe pipe;
	private String connectedId;

	public DiscordPresence(Settings settings) {
		this.settings = settings;
		Thread t = new Thread(this::loop, "cherry-discord");
		t.setDaemon(true);
		t.start();
	}

	/** In the launcher, browsing. */
	public void idle() {
		set(new Activity(Lang.t("In the launcher"), Lang.t("Picking a version"), System.currentTimeMillis() / 1000));
	}

	/** In game. {@code server} may be null. */
	public void playing(String version, boolean fabric, boolean hud, String server) {
		String details = Lang.t("Playing Minecraft ") + version;
		String state = server != null && !server.isBlank() ? Lang.t("On ") + server
				: fabric ? (hud ? "Fabric  ·  Cherry HUD" : "Fabric") : "Vanilla";
		set(new Activity(details, state, System.currentTimeMillis() / 1000));
	}

	private void set(Activity a) {
		wanted = a;
		dirty = true;
		synchronized (this) { notifyAll(); }
	}

	/** Settings changed (enabled/app id): reconnect and resend. */
	public void refresh() {
		dirty = true;
		synchronized (this) { notifyAll(); }
	}

	private void loop() {
		while (true) {
			try {
				String id = settings.discordAppId.isBlank() ? DEFAULT_APP_ID : settings.discordAppId.trim();
				boolean on = settings.discordEnabled && id.matches("\\d{15,22}");
				if (!on) {
					close();
				} else {
					if (pipe == null || !id.equals(connectedId)) {
						close();
						pipe = Pipe.open();
						if (pipe != null) {
							handshake(id);
							connectedId = id;
							dirty = true;
						}
					}
					if (pipe != null && dirty) {
						dirty = false;
						send(wanted);
					}
				}
			} catch (Exception e) {
				close(); // Discord closed or not running; try again later
			}
			synchronized (this) {
				try { wait(pipe == null ? 15000 : 30000); } catch (InterruptedException e) { return; }
			}
		}
	}

	private void handshake(String id) throws IOException {
		Map<String, Object> hello = new LinkedHashMap<>();
		hello.put("v", 1);
		hello.put("client_id", id);
		pipe.write(0, Json.write(hello));
		pipe.read(); // READY (or an error, which ends in an exception and a retry)
	}

	private void send(Activity a) throws IOException {
		Map<String, Object> args = new LinkedHashMap<>();
		args.put("pid", ProcessHandle.current().pid());
		if (a != null) {
			Map<String, Object> act = new LinkedHashMap<>();
			act.put("details", a.details());
			act.put("state", a.state());
			act.put("timestamps", Map.of("start", a.start()));
			act.put("assets", Map.of("large_image", "logo", "large_text", "Cherry Blossom Client"));
			args.put("activity", act);
		}
		Map<String, Object> cmd = new LinkedHashMap<>();
		cmd.put("cmd", "SET_ACTIVITY");
		cmd.put("args", args);
		cmd.put("nonce", UUID.randomUUID().toString());
		pipe.write(1, Json.write(cmd));
		String reply = pipe.read();
		if (reply.contains("\"evt\":\"ERROR\"") || reply.contains("\"evt\": \"ERROR\"")) {
			System.err.println("Discord rejected the presence: " + reply);
		}
	}

	private void close() {
		if (pipe != null) {
			try { pipe.close(); } catch (Exception ignored) {}
		}
		pipe = null;
		connectedId = null;
	}

	/** Discord's IPC: a named pipe on Windows, a Unix socket elsewhere. Frames are [op][length][json], little-endian. */
	private static final class Pipe implements Closeable {
		private RandomAccessFile file;
		private SocketChannel socket;

		static Pipe open() {
			for (int i = 0; i < 10; i++) {
				try {
					Pipe p = new Pipe();
					if (System.getProperty("os.name").toLowerCase().contains("win")) {
						p.file = new RandomAccessFile("\\\\.\\pipe\\discord-ipc-" + i, "rw");
					} else {
						Path sock = null;
						for (String env : new String[] {"XDG_RUNTIME_DIR", "TMPDIR", "TMP", "TEMP"}) {
							String dir = System.getenv(env);
							if (dir == null) continue;
							for (String sub : new String[] {"", "app/com.discordapp.Discord/", "snap.discord/"}) {
								Path c = Path.of(dir, sub + "discord-ipc-" + i);
								if (Files.exists(c)) { sock = c; break; }
							}
							if (sock != null) break;
						}
						if (sock == null) sock = Path.of("/tmp/discord-ipc-" + i);
						if (!Files.exists(sock)) continue;
						p.socket = SocketChannel.open(StandardProtocolFamily.UNIX);
						p.socket.connect(UnixDomainSocketAddress.of(sock));
					}
					return p;
				} catch (Exception ignored) {
					// try the next pipe number
				}
			}
			return null;
		}

		void write(int op, String json) throws IOException {
			byte[] body = json.getBytes(StandardCharsets.UTF_8);
			ByteBuffer b = ByteBuffer.allocate(8 + body.length).order(ByteOrder.LITTLE_ENDIAN);
			b.putInt(op).putInt(body.length).put(body).flip();
			if (file != null) file.write(b.array());
			else while (b.hasRemaining()) socket.write(b);
		}

		String read() throws IOException {
			byte[] header = readFully(8);
			ByteBuffer h = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
			int op = h.getInt();
			int len = h.getInt();
			if (len < 0 || len > 1 << 20) throw new IOException("bad frame");
			String body = new String(readFully(len), StandardCharsets.UTF_8);
			if (op == 2) throw new IOException("Discord closed the connection: " + body);
			return body;
		}

		private byte[] readFully(int n) throws IOException {
			byte[] out = new byte[n];
			if (file != null) {
				file.readFully(out);
			} else {
				ByteBuffer b = ByteBuffer.wrap(out);
				while (b.hasRemaining()) if (socket.read(b) < 0) throw new IOException("closed");
			}
			return out;
		}

		@Override
		public void close() throws IOException {
			if (file != null) file.close();
			if (socket != null) socket.close();
		}
	}
}
