package dev.cherryblossom.launcher.core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiConsumer;

/**
 * Friends without accounts or a server of our own.
 *
 * Everyone gets an Ed25519 key the first time the launcher starts. Your friend code is a short hash of
 * that key, so it works the same for offline and Microsoft players. Messages travel through ntfy.sh
 * (a free public relay) on topics named after the code, and every message is signed, so nobody can
 * pretend to be your friend even if they learn your code.
 */
public final class Friends {
	public static final String RELAY = System.getProperty("cherry.relay", "https://ntfy.sh");
	private static final long ONLINE_FOR_MS = 22 * 60_000L;   // a friend is online if we heard from them this recently
	private static final long HEARTBEAT_MS = 10 * 60_000L;

	public static final class Friend {
		public String code, name, pub;
		public long since, lastSeen;
		public String state = "offline", version = "", server = "";
		public boolean confirmed = true;

		public boolean online() { return !"offline".equals(state) && System.currentTimeMillis() - lastSeen < ONLINE_FOR_MS; }

		/** What the friend is doing, in a few words. */
		public String activity() {
			if (!online()) return Lang.t("Offline");
			if (!"playing".equals(state)) return Lang.t("In the launcher");
			if (server == null || server.isBlank()) return Lang.t("Playing ") + version;
			if ("singleplayer".equals(server)) return Lang.t("Singleplayer, ") + version;
			return Lang.t("On ") + server + " (" + version + ")";
		}

		/** A server the friend is on that we could join too. */
		public String joinable() {
			if (!online() || !"playing".equals(state) || server == null || server.isBlank() || "singleplayer".equals(server)) return null;
			String host = server.toLowerCase(Locale.ROOT);
			if (host.startsWith("localhost") || host.startsWith("127.") || host.startsWith("192.168.") || host.startsWith("10.")) return null;
			return server;
		}
	}

	/** Someone who sent us a request, or someone we sent one to. */
	public record Request(String code, String name, String pub, long time) {}

	private final Path file;
	private final Settings settings;
	private PrivateKey key;
	private String pub;
	private String code;
	public final List<Friend> friends = new CopyOnWriteArrayList<>();
	public final List<Request> incoming = new CopyOnWriteArrayList<>();
	public final List<Request> outgoing = new CopyOnWriteArrayList<>();
	private final LinkedHashSet<String> seen = new LinkedHashSet<>();

	private final List<Runnable> listeners = new CopyOnWriteArrayList<>();
	private final List<BiConsumer<String, String>> notices = new CopyOnWriteArrayList<>();
	private volatile String myState = "online", myVersion = "", myServer = "";
	private volatile HttpURLConnection stream;
	private volatile boolean connected;
	private volatile boolean stopped;

	public Friends(Path file, Settings settings) {
		this.file = file;
		this.settings = settings;
		load();
	}

	// ------------------------------------------------------------------ public API

	public String code() { return code; }

	/** The code as people type it: ABCD-EFGH-JKLM-NPQR. */
	public String prettyCode() { return pretty(code); }

	public static String pretty(String c) {
		return c.substring(0, 4) + "-" + c.substring(4, 8) + "-" + c.substring(8, 12) + "-" + c.substring(12);
	}

	public boolean connected() { return connected; }

	public void listen(Runnable r) { listeners.add(r); }

	/** (title, text) whenever something worth a pop-up happens. */
	public void onNotice(BiConsumer<String, String> n) { notices.add(n); }

	public int onlineCount() {
		int n = 0;
		for (Friend f : friends) if (f.online()) n++;
		return n;
	}

	public void start() {
		Thread t = new Thread(this::run, "cherry-friends");
		t.setDaemon(true);
		t.start();
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			stopped = true;
			myState = "offline";
			try { publishPresence(); } catch (Exception ignored) {}
		}));
	}

	/** Tell friends what we're doing. state is "online" (in the launcher) or "playing". */
	public void setActivity(String state, String version, String server) {
		myState = state;
		myVersion = version == null ? "" : version;
		myServer = server == null ? "" : server;
		async(this::publishPresence);
	}

	/** Called from the game when it joins or leaves a server. */
	public void setServer(String server) {
		if (!"playing".equals(myState)) return;
		myServer = server == null ? "" : server;
		async(this::publishPresence);
	}

	/**
	 * Sends a friend request to a friend code, or to the Cherry player with that name.
	 * Returns a message for the user.
	 */
	public String add(String query) throws Exception {
		String q = query.trim();
		if (q.isEmpty()) return Lang.t("Type a player name or a friend code.");
		String asCode = q.toUpperCase(Locale.ROOT).replace("-", "").replace(" ", "");
		String target = null, name = null;
		if (asCode.matches("[A-Z2-7]{16}")) {
			target = asCode;
		} else if (q.matches("[A-Za-z0-9_]{2,16}")) {
			Map<String, String> found = lookupName(q);
			found.remove(code);
			if (found.isEmpty())
				return Lang.t("No Cherry player called ") + q + Lang.t(" has been online in the last 12 hours. Ask them for their friend code.");
			if (found.size() > 1)
				return Lang.t("More than one Cherry player is called ") + q + Lang.t(". Ask them for their friend code.");
			var e = found.entrySet().iterator().next();
			target = e.getKey();
			name = e.getValue();
		} else {
			return Lang.t("That isn't a player name or a friend code.");
		}
		if (target.equals(code)) return Lang.t("That's your own code.");
		for (Friend f : friends) if (f.code.equals(target)) return f.name + Lang.t(" is already your friend.");
		for (Request r : incoming) if (r.code().equals(target)) { accept(r.code()); return Lang.t("You're now friends with ") + r.name() + "."; }
		String to = target;
		String label = name != null ? name : pretty(to);
		outgoing.removeIf(r -> r.code().equals(to));
		outgoing.add(new Request(to, label, "", System.currentTimeMillis()));
		save();
		send(to, "req", Map.of());
		changed();
		return Lang.t("Friend request sent to ") + label + ".";
	}

	public void accept(String who) {
		Request r = find(incoming, who);
		if (r == null) return;
		incoming.remove(r);
		Friend f = befriend(r.code(), r.name(), r.pub(), false);
		save();
		async(() -> { send(f.code, "acc", Map.of()); publishPresence(); });
		reconnect();
		changed();
	}

	public void decline(String who) {
		Request r = find(incoming, who);
		if (r == null) return;
		incoming.remove(r);
		save();
		async(() -> send(r.code(), "dec", Map.of()));
		changed();
	}

	public void cancel(String who) {
		Request r = find(outgoing, who);
		if (r == null) return;
		outgoing.remove(r);
		save();
		changed();
	}

	public void remove(String who) {
		friends.removeIf(f -> f.code.equals(who));
		save();
		async(() -> send(who, "del", Map.of()));
		reconnect();
		changed();
	}

	public void stop() {
		stopped = true;
		HttpURLConnection c = stream;
		if (c != null) c.disconnect();
	}

	// ------------------------------------------------------------------ relay

	private void run() {
		long backoff = 2000;
		long lastBeat = 0;
		boolean first = true;
		while (!stopped) {
			try {
				if (first) {
					// Requests and acceptances only wait on the relay for 12 hours, so send them again.
					for (Request r : outgoing) send(r.code(), "req", Map.of());
					for (Friend f : friends) if (!f.confirmed) send(f.code, "acc", Map.of());
					announceName();
					first = false;
				}
				if (System.currentTimeMillis() - lastBeat > HEARTBEAT_MS) { publishPresence(); lastBeat = System.currentTimeMillis(); }
				subscribe(() -> {
					if (System.currentTimeMillis() - (long) heartbeat[0] > HEARTBEAT_MS) {
						heartbeat[0] = System.currentTimeMillis();
						async(this::publishPresence);
					}
				});
				backoff = 2000;
			} catch (Exception e) {
				if (stopped) return;
				connected = false;
				changed();
				try { Thread.sleep(backoff); } catch (InterruptedException ie) { return; }
				backoff = Math.min(60_000, backoff * 2);
			}
		}
	}

	private final Object[] heartbeat = {System.currentTimeMillis()};

	/** One long-lived stream for our inbox and every friend's status. Returns when it drops or friends change. */
	private void subscribe(Runnable onKeepalive) throws Exception {
		List<String> topics = new ArrayList<>();
		topics.add(inbox(code));
		for (Friend f : friends) topics.add(presence(f.code));
		long since = System.currentTimeMillis() / 1000 - 12 * 3600;
		HttpURLConnection c = (HttpURLConnection) URI.create(RELAY + "/" + String.join(",", topics) + "/json?since=" + since).toURL().openConnection();
		c.setConnectTimeout(10_000);
		c.setReadTimeout(90_000);   // ntfy sends a keepalive every 45 s
		c.setRequestProperty("User-Agent", "CherryBlossomClient");
		stream = c;
		try (BufferedReader in = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
			connected = true;
			changed();
			String line;
			while (!stopped && (line = in.readLine()) != null) {
				if (line.isBlank()) continue;
				Map<String, Object> m = Json.obj(Json.parse(line));
				String event = Json.str(m, "event");
				if ("keepalive".equals(event) || "open".equals(event)) { onKeepalive.run(); continue; }
				if (!"message".equals(event)) continue;
				try { handle(Json.str(m, "id"), Json.str(m, "topic"), Json.str(m, "message")); } catch (Exception ignored) {}
				onKeepalive.run();
			}
		} finally {
			stream = null;
			c.disconnect();
		}
	}

	/** Drops the stream so it comes back with the new list of friends. */
	private void reconnect() {
		HttpURLConnection c = stream;
		if (c != null) c.disconnect();
	}

	private void handle(String id, String topic, String wire) throws Exception {
		if (wire == null || topic == null) return;
		Map<String, Object> p = open(wire);
		if (p == null) return;
		String from = codeOf(Json.str(p, "pub"));
		String type = Json.str(p, "t");
		String name = clean(Json.str(p, "name"));
		long ts = Json.num(p, "ts", 0);
		if (from.equals(code)) return;

		if (topic.equals(inbox(code))) {
			synchronized (seen) {
				if (id != null && !seen.add(id)) return;
				while (seen.size() > 300) seen.remove(seen.iterator().next());
			}
			Friend f = friend(from);
			switch (type == null ? "" : type) {
				case "req" -> {
					if (f != null) { if (samePub(f, p)) send(from, "acc", Map.of()); }
					else if (find(outgoing, from) != null) {
						outgoing.remove(find(outgoing, from));
						befriend(from, name, Json.str(p, "pub"), false);
						send(from, "acc", Map.of());
						notice(Lang.t("New friend"), name + Lang.t(" is now your friend."));
						reconnect();
					} else if (find(incoming, from) == null) {
						incoming.add(new Request(from, name, Json.str(p, "pub"), ts));
						notice(Lang.t("Friend request"), name + Lang.t(" wants to be your friend."));
					}
				}
				case "acc" -> {
					Request r = find(outgoing, from);
					if (r != null) {
						outgoing.remove(r);
						befriend(from, name, Json.str(p, "pub"), true);
						notice(Lang.t("New friend"), name + Lang.t(" accepted your friend request."));
						reconnect();
					}
					if (friend(from) != null) send(from, "ok", Map.of());
				}
				case "ok" -> { if (f != null && samePub(f, p)) f.confirmed = true; }
				case "dec" -> outgoing.removeIf(r -> r.code().equals(from));
				case "del" -> {
					if (f != null && samePub(f, p) && ts > f.since) { friends.remove(f); reconnect(); }
					incoming.removeIf(r -> r.code().equals(from));
				}
				default -> { return; }
			}
			save();
			changed();
		} else if (topic.startsWith("cbc-p-")) {
			Friend f = friend(from);
			if (f == null || !samePub(f, p) || ts < f.lastSeen) return;
			boolean wasOnline = f.online();
			f.lastSeen = ts;
			f.state = String.valueOf(Json.str(p, "state"));
			f.version = clean(Json.str(p, "version"));
			f.server = clean(Json.str(p, "server"));
			if (!name.isEmpty()) f.name = name;
			if (!wasOnline && f.online() && System.currentTimeMillis() - ts < 60_000) notice(f.name, Lang.t("is online"));
			changed();
		}
	}

	private Map<String, String> lookupName(String name) throws Exception {
		Map<String, String> out = new LinkedHashMap<>();
		String body = Http.get(RELAY + "/" + nameTopic(name) + "/json?poll=1&since=12h");
		for (String line : body.split("\n")) {
			if (line.isBlank()) continue;
			try {
				Map<String, Object> m = Json.obj(Json.parse(line));
				Map<String, Object> p = open(Json.str(m, "message"));
				if (p == null || !"name".equals(Json.str(p, "t"))) continue;
				if (!name.equalsIgnoreCase(Json.str(p, "name"))) continue;
				out.put(codeOf(Json.str(p, "pub")), clean(Json.str(p, "name")));
			} catch (Exception ignored) {}
		}
		return out;
	}

	private void announceName() throws Exception {
		String n = settings.playerName();
		if (n == null || n.isBlank()) return;
		publish(nameTopic(n), seal("name", Map.of()));
	}

	private void publishPresence() throws Exception {
		publish(presence(code), seal("st", Map.of("state", myState, "version", myVersion, "server", myServer)));
	}

	private void send(String to, String type, Map<String, Object> extra) throws Exception {
		publish(inbox(to), seal(type, extra));
	}

	private static void publish(String topic, String body) throws Exception {
		HttpURLConnection c = (HttpURLConnection) URI.create(RELAY + "/" + topic).toURL().openConnection();
		c.setRequestMethod("POST");
		c.setDoOutput(true);
		c.setConnectTimeout(10_000);
		c.setReadTimeout(15_000);
		c.setRequestProperty("User-Agent", "CherryBlossomClient");
		c.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
		int status = c.getResponseCode();
		c.getInputStream().close();
		if (status >= 300) throw new java.io.IOException("relay said " + status);
	}

	// ------------------------------------------------------------------ signing

	/** payload as base64 JSON, a dot, then the Ed25519 signature of those bytes. */
	private String seal(String type, Map<String, Object> extra) throws Exception {
		Map<String, Object> p = new LinkedHashMap<>(extra);
		p.put("t", type);
		p.put("name", settings.playerName() == null ? "" : settings.playerName());
		p.put("pub", pub);
		p.put("ts", System.currentTimeMillis());
		byte[] data = Json.write(p).getBytes(StandardCharsets.UTF_8);
		Signature s = Signature.getInstance("Ed25519");
		s.initSign(key);
		s.update(data);
		Base64.Encoder b = Base64.getUrlEncoder().withoutPadding();
		return b.encodeToString(data) + "." + b.encodeToString(s.sign());
	}

	/** Checks the signature; returns the payload, or null if it was forged or garbled. */
	private static Map<String, Object> open(String wire) {
		try {
			int dot = wire.indexOf('.');
			if (dot < 0) return null;
			Base64.Decoder d = Base64.getUrlDecoder();
			byte[] data = d.decode(wire.substring(0, dot));
			byte[] sig = d.decode(wire.substring(dot + 1));
			Map<String, Object> p = Json.obj(Json.parse(new String(data, StandardCharsets.UTF_8)));
			PublicKey k = KeyFactory.getInstance("Ed25519").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(Json.str(p, "pub"))));
			Signature s = Signature.getInstance("Ed25519");
			s.initVerify(k);
			s.update(data);
			return s.verify(sig) ? p : null;
		} catch (Exception e) {
			return null;
		}
	}

	/** 16 base32 letters (80 bits) of the key's SHA-256. */
	static String codeOf(String pubB64) throws Exception {
		byte[] h = MessageDigest.getInstance("SHA-256").digest(Base64.getDecoder().decode(pubB64));
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
		StringBuilder sb = new StringBuilder();
		int bits = 0, value = 0, i = 0;
		while (sb.length() < 16) {
			if (bits < 5) { value = (value << 8) | (h[i++] & 0xFF); bits += 8; }
			sb.append(alphabet.charAt((value >> (bits - 5)) & 31));
			bits -= 5;
		}
		return sb.toString();
	}

	private static String inbox(String code) { return "cbc-i-" + code.toLowerCase(Locale.ROOT); }

	private static String presence(String code) { return "cbc-p-" + code.toLowerCase(Locale.ROOT); }

	private static String nameTopic(String name) {
		try {
			byte[] h = MessageDigest.getInstance("SHA-256").digest(("cherry:" + name.toLowerCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8));
			return "cbc-n-" + HexFormat.of().formatHex(h, 0, 12);
		} catch (Exception e) { throw new IllegalStateException(e); }
	}

	// ------------------------------------------------------------------ bookkeeping

	private Friend befriend(String who, String name, String pubKey, boolean confirmed) {
		Friend f = friend(who);
		if (f == null) { f = new Friend(); f.code = who; friends.add(f); }
		f.name = name.isEmpty() ? pretty(who) : name;
		f.pub = pubKey;
		f.since = System.currentTimeMillis();
		f.confirmed = confirmed;
		return f;
	}

	private Friend friend(String who) {
		for (Friend f : friends) if (f.code.equals(who)) return f;
		return null;
	}

	private static Request find(List<Request> list, String who) {
		for (Request r : list) if (r.code().equals(who)) return r;
		return null;
	}

	private static boolean samePub(Friend f, Map<String, Object> p) {
		return f.pub != null && f.pub.equals(Json.str(p, "pub"));
	}

	private static String clean(String s) {
		if (s == null) return "";
		s = s.replaceAll("[\\p{Cntrl}§]", "");
		return s.length() > 64 ? s.substring(0, 64) : s;
	}

	private void notice(String title, String text) {
		for (BiConsumer<String, String> n : notices) n.accept(title, text);
	}

	private void changed() {
		for (Runnable r : listeners) r.run();
	}

	private void async(ThrowingRunnable r) {
		Thread t = new Thread(() -> { try { r.run(); } catch (Exception ignored) {} }, "cherry-friends-send");
		t.setDaemon(true);
		t.start();
	}

	private interface ThrowingRunnable { void run() throws Exception; }

	private void load() {
		try {
			if (Files.exists(file)) {
				Map<String, Object> m = Json.obj(Json.parse(Files.readString(file)));
				KeyFactory kf = KeyFactory.getInstance("Ed25519");
				key = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(Json.str(m, "key"))));
				pub = Json.str(m, "pub");
				for (Object o : Json.arr(m, "friends")) {
					Map<String, Object> fm = Json.obj(o);
					Friend f = new Friend();
					f.code = Json.str(fm, "code");
					f.name = Json.str(fm, "name");
					f.pub = Json.str(fm, "pub");
					f.since = Json.num(fm, "since", 0);
					f.confirmed = Json.bool(fm, "confirmed", true);
					friends.add(f);
				}
				for (Object o : Json.arr(m, "incoming")) incoming.add(req(Json.obj(o)));
				for (Object o : Json.arr(m, "outgoing")) outgoing.add(req(Json.obj(o)));
				for (Object o : Json.arr(m, "seen")) seen.add(String.valueOf(o));
			}
		} catch (Exception e) {
			System.err.println("Could not read friends: " + e);
		}
		try {
			if (key == null) {
				KeyPair kp = KeyPairGenerator.getInstance("Ed25519").generateKeyPair();
				key = kp.getPrivate();
				pub = Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());
				save();
			}
			code = codeOf(pub);
		} catch (Exception e) {
			throw new IllegalStateException("Ed25519 not available", e);
		}
	}

	private static Request req(Map<String, Object> m) {
		return new Request(Json.str(m, "code"), Json.str(m, "name"), String.valueOf(Json.str(m, "pub")), Json.num(m, "time", 0));
	}

	private synchronized void save() {
		Map<String, Object> m = new LinkedHashMap<>();
		m.put("key", Base64.getEncoder().encodeToString(key.getEncoded()));
		m.put("pub", pub);
		List<Object> fl = new ArrayList<>();
		for (Friend f : friends) {
			Map<String, Object> fm = new LinkedHashMap<>();
			fm.put("code", f.code); fm.put("name", f.name); fm.put("pub", f.pub); fm.put("since", f.since); fm.put("confirmed", f.confirmed);
			fl.add(fm);
		}
		m.put("friends", fl);
		m.put("incoming", reqs(incoming));
		m.put("outgoing", reqs(outgoing));
		synchronized (seen) { m.put("seen", new ArrayList<>(seen)); }
		try {
			Files.createDirectories(file.getParent());
			Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
			Files.writeString(tmp, Json.write(m));
			Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			System.err.println("Could not save friends: " + e);
		}
	}

	private static List<Object> reqs(List<Request> list) {
		List<Object> out = new ArrayList<>();
		for (Request r : list) {
			Map<String, Object> m = new LinkedHashMap<>();
			m.put("code", r.code()); m.put("name", r.name()); m.put("pub", r.pub()); m.put("time", r.time());
			out.add(m);
		}
		return out;
	}

	@SuppressWarnings("unused")
	private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
