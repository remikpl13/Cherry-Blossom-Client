package dev.cherryblossom.launcher.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs a Minecraft server on this PC: downloads the official server, writes its settings,
 * starts it with tuned memory flags and streams its console. One world folder per version family.
 */
public final class ServerManager {
	public enum State { STOPPED, PREPARING, STARTING, ONLINE, STOPPING }

	private static final Pattern JOINED = Pattern.compile("]: (\\w{3,16}) joined the game");
	private static final Pattern LEFT = Pattern.compile("]: (\\w{3,16}) left the game");

	private final Installer installer;
	private final Path root;
	private final Deque<String> console = new ArrayDeque<>();
	private final Set<String> players = new LinkedHashSet<>();
	private volatile State state = State.STOPPED;
	private volatile Process process;
	private volatile String runningVersion;
	private Runnable onChange = () -> {};

	public ServerManager(Installer installer, Path root) {
		this.installer = installer;
		this.root = root;
		Runtime.getRuntime().addShutdownHook(new Thread(this::stopNow));
	}

	public void onChange(Runnable r) { onChange = r; }

	public State state() { return state; }

	public String runningVersion() { return runningVersion; }

	public synchronized List<String> players() { return new ArrayList<>(players); }

	public synchronized List<String> console() { return new ArrayList<>(console); }

	public Path dir(String versionId) {
		return root.resolve(VersionList.familyKey(versionId).replaceAll("[^A-Za-z0-9._-]", "_"));
	}

	/** Suggested server memory: what's left after Windows and the game itself, kept between 1 and 8 GB. */
	public static int suggestedRamMb(int clientRamMb) {
		int free = Settings.systemMemoryMb() - clientRamMb - 2048;
		int mb = Math.max(1024, Math.min(8192, free));
		if (Settings.systemMemoryMb() <= 8192) mb = Math.min(mb, 2048);
		return mb / 512 * 512;
	}

	/** View distance that the CPU can comfortably keep up with. */
	public static int suggestedViewDistance() {
		int t = Presets.cpuThreads();
		return t <= 4 ? 7 : t <= 8 ? 10 : 12;
	}

	public record Options(int ramMb, String motd, int maxPlayers, int port, String difficulty, String gamemode,
						  boolean onlineMode, boolean pvp) {}

	public void start(VersionList.Version version, Options o, Installer.Progress progress) {
		if (state != State.STOPPED) return;
		state = State.PREPARING;
		changed();
		Thread t = new Thread(() -> {
			try {
				Path dir = dir(version.id());
				Files.createDirectories(dir);
				String[] prepared = installer.prepareServer(version, dir, progress);
				Files.writeString(dir.resolve("eula.txt"), "# Agreed in Cherry Blossom Client: https://aka.ms/MinecraftEULA\neula=true\n");
				writeProperties(dir.resolve("server.properties"), o);

				List<String> cmd = new ArrayList<>();
				cmd.add(prepared[0]);
				cmd.add("-Xms" + Math.min(o.ramMb(), 1024) + "M");
				cmd.add("-Xmx" + o.ramMb() + "M");
				// Aikar's G1 flags: the community standard for smooth Minecraft servers.
				cmd.addAll(List.of("-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200",
						"-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC", "-XX:+AlwaysPreTouch",
						"-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40", "-XX:G1HeapRegionSize=8M",
						"-XX:G1ReservePercent=20", "-XX:G1HeapWastePercent=5", "-XX:G1MixedGCCountTarget=4",
						"-XX:InitiatingHeapOccupancyPercent=15", "-XX:G1MixedGCLiveThresholdPercent=90",
						"-XX:G1RSetUpdatingPauseTimePercent=5", "-XX:SurvivorRatio=32", "-XX:+PerfDisableSharedMem",
						"-XX:MaxTenuringThreshold=1"));
				cmd.addAll(List.of("-jar", prepared[1], "nogui"));

				synchronized (this) { console.clear(); players.clear(); }
				log("> " + Lang.t("Starting Minecraft ") + version.id() + " " + Lang.t("server with") + " " + (o.ramMb() / 1024f) + " GB");
				process = new ProcessBuilder(cmd).directory(dir.toFile()).redirectErrorStream(true).start();
				runningVersion = version.id();
				state = State.STARTING;
				changed();
				try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
					String line;
					while ((line = r.readLine()) != null) {
						log(line);
						if (state == State.STARTING && line.contains("Done (")) { state = State.ONLINE; changed(); }
						Matcher j = JOINED.matcher(line), l = LEFT.matcher(line);
						if (j.find()) { synchronized (this) { players.add(j.group(1)); } changed(); }
						if (l.find()) { synchronized (this) { players.remove(l.group(1)); } changed(); }
					}
				}
				int code = process.waitFor();
				log("> " + Lang.t("Server stopped") + (code == 0 ? "" : " (" + code + ")"));
			} catch (Exception e) {
				log("> " + Lang.t("Couldn't start: ") + (e.getMessage() == null ? e : e.getMessage()));
			} finally {
				process = null;
				runningVersion = null;
				synchronized (this) { players.clear(); }
				state = State.STOPPED;
				changed();
			}
		}, "cherry-server");
		t.setDaemon(true);
		t.start();
	}

	/** Types a command into the server console. */
	public void command(String text) {
		Process p = process;
		if (p == null || text.isBlank()) return;
		try {
			OutputStream out = p.getOutputStream();
			out.write((text.trim() + "\n").getBytes(StandardCharsets.UTF_8));
			out.flush();
			log("> " + text.trim());
		} catch (IOException e) {
			log("> " + e.getMessage());
		}
	}

	/** Saves the world and stops cleanly; force-stops if it hangs. */
	public void stop() {
		Process p = process;
		if (p == null) return;
		state = State.STOPPING;
		changed();
		command("stop");
		Thread t = new Thread(() -> {
			try {
				if (!p.waitFor(30, java.util.concurrent.TimeUnit.SECONDS)) p.destroyForcibly();
			} catch (InterruptedException ignored) {}
		}, "cherry-server-stop");
		t.setDaemon(true);
		t.start();
	}

	private void stopNow() {
		Process p = process;
		if (p == null) return;
		command("stop");
		try {
			if (!p.waitFor(20, java.util.concurrent.TimeUnit.SECONDS)) p.destroyForcibly();
		} catch (InterruptedException ignored) {}
	}

	private void writeProperties(Path file, Options o) throws IOException {
		Map<String, String> want = new LinkedHashMap<>();
		want.put("motd", o.motd().isBlank() ? "Cherry Blossom server" : o.motd().replace("\n", " "));
		want.put("max-players", Integer.toString(o.maxPlayers()));
		want.put("server-port", Integer.toString(o.port()));
		want.put("difficulty", o.difficulty());
		want.put("gamemode", o.gamemode());
		want.put("online-mode", Boolean.toString(o.onlineMode()));
		want.put("pvp", Boolean.toString(o.pvp()));
		want.put("view-distance", Integer.toString(suggestedViewDistance()));
		want.put("simulation-distance", Integer.toString(Math.min(10, suggestedViewDistance() - 2)));
		want.put("sync-chunk-writes", "false");
		List<String> lines = Files.exists(file) ? new ArrayList<>(Files.readAllLines(file)) : new ArrayList<>();
		for (int i = 0; i < lines.size(); i++) {
			String line = lines.get(i);
			int eq = line.indexOf('=');
			if (eq <= 0 || line.startsWith("#")) continue;
			String key = line.substring(0, eq);
			if (want.containsKey(key)) lines.set(i, key + "=" + want.remove(key));
		}
		want.forEach((k, v) -> lines.add(k + "=" + v));
		Files.write(file, lines);
	}

	private synchronized void log(String line) {
		console.addLast(line);
		while (console.size() > 400) console.removeFirst();
		changed();
	}

	private void changed() {
		onChange.run();
	}
}
