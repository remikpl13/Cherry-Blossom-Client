package dev.cherryblossom.launcher.core;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Installs and launches any Minecraft version, from Alpha to the latest, with or without Fabric.
 * Only missing files are downloaded. Each version family gets its own game folder
 * (so old versions never touch newer worlds), and each exact version its own mods folder.
 */
public final class Installer {
	private static final String FABRIC_META = "https://meta.fabricmc.net/v2/versions/loader/";
	private static final String ASSETS = "https://resources.download.minecraft.net/";
	private static final String MODRINTH = "https://api.modrinth.com/v2/project/";

	public interface Progress {
		void update(String status, double fraction);
	}

	public record Account(String name, String uuid, String accessToken, String userType, String xuid) {}

	private final Path base;
	private final Path libraries;
	private final Path assets;
	private final JavaRuntimes runtimes;

	private final AtomicLong done = new AtomicLong();
	private long total;
	private final Map<String, Boolean> fabricSupport = new ConcurrentHashMap<>();

	public Installer(Path base) {
		this.base = base;
		this.libraries = base.resolve("libraries");
		this.assets = base.resolve("assets");
		this.runtimes = new JavaRuntimes(base.resolve("runtime"));
	}

	public Path base() {
		return base;
	}

	/** Worlds, options, packs and screenshots for a version family, e.g. data/instances/1.21. */
	public Path gameDir(String versionId) {
		return base.resolve("instances").resolve(VersionList.familyKey(versionId).replaceAll("[^A-Za-z0-9._-]", "_"));
	}

	public Path modsDir(String versionId) {
		return gameDir(versionId).resolve("mods").resolve(versionId);
	}

	/** True if the Cherry HUD has a build for this exact version. */
	public static boolean hasCherryHud(String versionId) {
		return Installer.class.getResource("/bundled/hud/" + versionId + ".jar") != null;
	}

	/** Asks Fabric's servers whether this version is supported (cached). */
	public boolean fabricSupports(String versionId) {
		return fabricSupport.computeIfAbsent(versionId, id -> {
			try {
				return !Json.arr(Http.getJsonAny(FABRIC_META + id)).isEmpty();
			} catch (IOException e) {
				return Files.exists(base.resolve("versions").resolve(id).resolve("fabric-profile.json"));
			}
		});
	}

	public boolean isInstalled(String versionId) {
		return Files.exists(base.resolve("versions").resolve(versionId).resolve(versionId + ".jar"));
	}

	private record FileJob(String url, Path path, String sha1, long size) {}

	public List<String> prepare(Settings settings, VersionList.Version version, boolean wantFabric, Account account,
								String server, Progress progress) throws Exception {
		String id = version.id();
		Path versionDir = base.resolve("versions").resolve(id);
		Path gameDir = gameDir(id);
		Files.createDirectories(gameDir);

		progress.update(Lang.t("Checking Minecraft ") + id, 0.01);
		Map<String, Object> vanilla = versionJson(version, versionDir);
		boolean fabric = wantFabric && fabricSupports(id);
		Map<String, Object> fabricProfile = fabric ? fabricProfile(id, versionDir) : null;

		// Java for this version.
		Map<String, Object> javaVersion = Json.obj(vanilla, "javaVersion");
		String component = javaVersion == null ? "jre-legacy" : Json.str(javaVersion, "component");
		int javaMajor = javaVersion == null ? 8 : (int) Json.num(javaVersion, "majorVersion", 8);
		progress.update(Lang.t("Checking Java ") + javaMajor, 0.02);
		List<JavaRuntimes.Job> javaJobs = runtimes.plan(component);
		String java = javaJobs == null ? JavaRuntimes.currentJava().toString() : runtimes.executable(component).toString();

		List<FileJob> jobs = new ArrayList<>();
		if (javaJobs != null) for (JavaRuntimes.Job j : javaJobs) jobs.add(new FileJob(j.url(), j.path(), j.sha1(), j.size()));

		List<Path> classpath = new ArrayList<>();
		List<Path[]> natives = new ArrayList<>(); // {jar, ...}
		List<List<String>> nativeExcludes = new ArrayList<>();
		collectLibraries(vanilla, fabricProfile, jobs, classpath, natives, nativeExcludes);

		Map<String, Object> client = Json.obj(Json.obj(vanilla, "downloads"), "client");
		Path clientJar = versionDir.resolve(id + ".jar");
		jobs.add(new FileJob(Json.str(client, "url"), clientJar, Json.str(client, "sha1"), Json.num(client, "size", 0)));
		classpath.add(clientJar);

		Map<String, Object> logging = Json.obj(Json.obj(vanilla, "logging"), "client");
		Path logConfig = null;
		String logArgument = null;
		if (logging != null) {
			Map<String, Object> f = Json.obj(logging, "file");
			logConfig = assets.resolve("log_configs").resolve(Json.str(f, "id"));
			logArgument = Json.str(logging, "argument");
			jobs.add(new FileJob(Json.str(f, "url"), logConfig, Json.str(f, "sha1"), Json.num(f, "size", 0)));
		}

		// Assets.
		Map<String, Object> assetIndex = Json.obj(vanilla, "assetIndex");
		String indexId = Json.str(assetIndex, "id");
		Path indexFile = assets.resolve("indexes").resolve(indexId + ".json");
		if (!matchesSha(indexFile, Json.str(assetIndex, "sha1"))) {
			Http.download(Json.str(assetIndex, "url"), indexFile, Json.str(assetIndex, "sha1"), null);
		}
		Map<String, Object> index = Json.obj(Json.parse(Files.readString(indexFile)));
		Map<String, Object> objects = Json.obj(index, "objects");
		Set<String> seen = new HashSet<>();
		for (Object o : objects.values()) {
			Map<String, Object> a = Json.obj(o);
			String hash = Json.str(a, "hash");
			if (!seen.add(hash)) continue;
			String sub = hash.substring(0, 2) + "/" + hash;
			jobs.add(new FileJob(ASSETS + sub, assets.resolve("objects").resolve(sub), hash, Json.num(a, "size", 0)));
		}

		List<FileJob> missing = new ArrayList<>();
		Set<Path> queued = new HashSet<>();
		for (FileJob j : jobs) if (queued.add(j.path) && !matches(j.path, j.size)) missing.add(j);
		total = 0;
		for (FileJob j : missing) total += Math.max(1, j.size);
		done.set(0);
		if (!missing.isEmpty()) {
			progress.update(Lang.t("Downloading"), 0.03);
			runParallel(missing, progress);
		}
		if (javaJobs != null) runtimes.finish(component, javaJobs);

		// Old versions read assets from a flat folder instead of the hashed store.
		Path gameAssets = assets;
		if (Json.bool(index, "map_to_resources", false)) {
			gameAssets = gameDir.resolve("resources");
			copyAssets(objects, gameAssets, progress);
		} else if (Json.bool(index, "virtual", false)) {
			gameAssets = assets.resolve("virtual").resolve(indexId);
			copyAssets(objects, gameAssets, progress);
		}

		Path nativesDir = versionDir.resolve("natives");
		extractNatives(natives, nativeExcludes, nativesDir);

		if (fabric) {
			progress.update(Lang.t("Getting mods for ") + id, 0.97);
			installMods(settings, id);
		}

		if (settings.applyVideoPreset && settings.preset != Presets.Preset.CUSTOM) {
			applyVideoSettings(gameDir.resolve("options.txt"), Presets.video(settings.preset));
			settings.applyVideoPreset = false;
			settings.save();
		}

		progress.update(Lang.t("Starting Minecraft ") + id, 1);
		return buildCommand(java, javaMajor, id, vanilla, fabricProfile, classpath, nativesDir, logConfig, logArgument,
				indexId, gameAssets, gameDir, settings, account, server);
	}

	// ---------------------------------------------------------------- metadata

	/**
	 * For the server page: makes sure the right Java and the official server jar for this version
	 * are downloaded. Returns {java executable, server jar}.
	 */
	public String[] prepareServer(VersionList.Version version, Path serverDir, Progress progress) throws Exception {
		Path versionDir = base.resolve("versions").resolve(version.id());
		progress.update(Lang.t("Checking Minecraft ") + version.id(), 0.02);
		Map<String, Object> vanilla = versionJson(version, versionDir);
		Map<String, Object> server = Json.obj(Json.obj(vanilla, "downloads"), "server");
		if (server == null) throw new IOException(Lang.t("Mojang has no server download for ") + version.id());
		Map<String, Object> javaVersion = Json.obj(vanilla, "javaVersion");
		String component = javaVersion == null ? "jre-legacy" : Json.str(javaVersion, "component");
		List<JavaRuntimes.Job> javaJobs = runtimes.plan(component);
		String java = javaJobs == null ? JavaRuntimes.currentJava().toString() : runtimes.executable(component).toString();
		// Servers don't need javaw: use the console java so it can't pop a window either way.
		java = java.replace("javaw.exe", "java.exe");

		List<FileJob> jobs = new ArrayList<>();
		if (javaJobs != null) for (JavaRuntimes.Job j : javaJobs) jobs.add(new FileJob(j.url(), j.path(), j.sha1(), j.size()));
		Path jar = serverDir.resolve("server-" + version.id() + ".jar");
		jobs.add(new FileJob(Json.str(server, "url"), jar, Json.str(server, "sha1"), Json.num(server, "size", 0)));
		List<FileJob> missing = new ArrayList<>();
		for (FileJob j : jobs) if (!matches(j.path, j.size)) missing.add(j);
		total = 0;
		for (FileJob j : missing) total += Math.max(1, j.size);
		done.set(0);
		if (!missing.isEmpty()) runParallel(missing, progress);
		if (javaJobs != null) runtimes.finish(component, javaJobs);
		progress.update(Lang.t("Starting the server"), 1);
		return new String[] {java, jar.toString()};
	}

	private Map<String, Object> versionJson(VersionList.Version v, Path dir) throws IOException {
		Path file = dir.resolve(v.id() + ".json");
		if (!matchesSha(file, v.sha1())) {
			try {
				Http.download(v.url(), file, v.sha1(), null);
			} catch (IOException e) {
				if (!Files.exists(file)) throw e;
			}
		}
		return Json.obj(Json.parse(Files.readString(file)));
	}

	private Map<String, Object> fabricProfile(String id, Path dir) throws IOException {
		Path file = dir.resolve("fabric-profile.json");
		try {
			List<Object> loaders = Json.arr(Http.getJsonAny(FABRIC_META + id));
			String chosen = null;
			for (Object o : loaders) {
				Map<String, Object> loader = Json.obj(Json.obj(o), "loader");
				if (chosen == null) chosen = Json.str(loader, "version");
				if (Json.bool(loader, "stable", false)) { chosen = Json.str(loader, "version"); break; }
			}
			if (chosen == null) throw new IOException(Lang.t("Fabric doesn't support ") + id);
			String profile = Http.get(FABRIC_META + id + "/" + chosen + "/profile/json");
			Files.createDirectories(dir);
			Files.writeString(file, profile);
		} catch (IOException e) {
			if (!Files.exists(file)) throw e;
		}
		return Json.obj(Json.parse(Files.readString(file)));
	}

	// ---------------------------------------------------------------- libraries

	private void collectLibraries(Map<String, Object> vanilla, Map<String, Object> fabric, List<FileJob> jobs,
								  List<Path> cp, List<Path[]> natives, List<List<String>> excludes) {
		Map<String, Path> byKey = new LinkedHashMap<>();
		if (fabric != null) {
			for (Object o : Json.arr(fabric, "libraries")) {
				Map<String, Object> lib = Json.obj(o);
				String name = Json.str(lib, "name");
				String rel = mavenPath(name);
				String repo = Json.str(lib, "url");
				if (repo == null) repo = "https://maven.fabricmc.net/";
				if (!repo.endsWith("/")) repo += "/";
				Path p = libraries.resolve(rel);
				jobs.add(new FileJob(repo + rel, p, Json.str(lib, "sha1"), Json.num(lib, "size", 0)));
				byKey.put(libKey(name), p);
			}
		}
		for (Object o : Json.arr(vanilla, "libraries")) {
			Map<String, Object> lib = Json.obj(o);
			if (!Rules.allowed(Json.arr(lib, "rules"), Map.of())) continue;
			String name = Json.str(lib, "name");
			Map<String, Object> downloads = Json.obj(lib, "downloads");

			// Old-style natives (1.18 and older): a classifier jar we unzip into the natives folder.
			Map<String, Object> nat = Json.obj(lib, "natives");
			if (nat != null) {
				String classifier = Json.str(nat, Rules.osName());
				if (classifier != null) {
					classifier = classifier.replace("${arch}", System.getProperty("os.arch").contains("64") ? "64" : "32");
					Map<String, Object> art = Json.obj(Json.obj(downloads, "classifiers"), classifier);
					if (art != null) {
						Path p = libraries.resolve(Json.str(art, "path"));
						jobs.add(new FileJob(Json.str(art, "url"), p, Json.str(art, "sha1"), Json.num(art, "size", 0)));
						natives.add(new Path[] {p});
						List<String> ex = new ArrayList<>();
						for (Object e : Json.arr(Json.obj(lib, "extract"), "exclude")) ex.add(String.valueOf(e));
						excludes.add(ex);
					}
				}
			}

			if (byKey.containsKey(libKey(name))) continue;
			Map<String, Object> art = Json.obj(downloads, "artifact");
			if (art != null) {
				Path p = libraries.resolve(Json.str(art, "path"));
				jobs.add(new FileJob(Json.str(art, "url"), p, Json.str(art, "sha1"), Json.num(art, "size", 0)));
				byKey.put(libKey(name), p);
			} else if (downloads == null && name != null) {
				String rel = mavenPath(name);
				String repo = Json.str(lib, "url");
				if (repo == null) repo = "https://libraries.minecraft.net/";
				Path p = libraries.resolve(rel);
				jobs.add(new FileJob(repo + rel, p, null, 0));
				byKey.put(libKey(name), p);
			}
		}
		cp.addAll(byKey.values());
	}

	private static String libKey(String name) {
		String[] p = name.split(":");
		return p[0] + ":" + p[1] + (p.length > 3 ? ":" + p[3] : "");
	}

	static String mavenPath(String name) {
		String[] p = name.split(":");
		String file = p[1] + "-" + p[2] + (p.length > 3 ? "-" + p[3] : "") + ".jar";
		return p[0].replace('.', '/') + "/" + p[1] + "/" + p[2] + "/" + file;
	}

	private static void extractNatives(List<Path[]> jars, List<List<String>> excludes, Path dir) throws IOException {
		if (jars.isEmpty()) return;
		Path marker = dir.resolve(".cherry-extracted");
		if (Files.exists(marker)) return;
		Files.createDirectories(dir);
		for (int i = 0; i < jars.size(); i++) {
			List<String> ex = excludes.get(i);
			try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(jars.get(i)[0]))) {
				ZipEntry e;
				while ((e = zin.getNextEntry()) != null) {
					String n = e.getName();
					if (e.isDirectory() || ex.stream().anyMatch(n::startsWith)) continue;
					Path out = dir.resolve(n).normalize();
					if (!out.startsWith(dir)) continue;
					Files.createDirectories(out.getParent());
					Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING);
				}
			}
		}
		Files.writeString(marker, "ok");
	}

	private void copyAssets(Map<String, Object> objects, Path target, Progress progress) throws IOException {
		progress.update(Lang.t("Preparing classic sounds and textures"), 0.96);
		for (Map.Entry<String, Object> e : objects.entrySet()) {
			Map<String, Object> a = Json.obj(e.getValue());
			String hash = Json.str(a, "hash");
			Path src = assets.resolve("objects").resolve(hash.substring(0, 2)).resolve(hash);
			Path dst = target.resolve(e.getKey());
			if (Files.exists(dst) && Files.size(dst) == Json.num(a, "size", -1)) continue;
			Files.createDirectories(dst.getParent());
			Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
		}
	}

	// ---------------------------------------------------------------- downloading

	private static boolean matches(Path p, long size) {
		try {
			return Files.isRegularFile(p) && (size <= 0 || Files.size(p) == size);
		} catch (IOException e) {
			return false;
		}
	}

	private static boolean matchesSha(Path p, String sha1) {
		try {
			return Files.isRegularFile(p) && (sha1 == null || Http.sha1Of(p).equalsIgnoreCase(sha1));
		} catch (IOException e) {
			return false;
		}
	}

	private void runParallel(List<FileJob> jobs, Progress progress) throws Exception {
		ExecutorService pool = Executors.newFixedThreadPool(16, r -> {
			Thread t = new Thread(r, "cherry-download");
			t.setDaemon(true);
			return t;
		});
		try {
			List<Future<?>> futures = new ArrayList<>();
			for (FileJob j : jobs) {
				futures.add(pool.submit(() -> {
					Http.download(j.url, j.path, j.sha1, n -> done.addAndGet(n));
					return null;
				}));
			}
			for (Future<?> f : futures) {
				while (true) {
					try {
						f.get(150, TimeUnit.MILLISECONDS);
						break;
					} catch (TimeoutException te) {
						report(progress);
					}
				}
				report(progress);
			}
		} catch (ExecutionException e) {
			throw e.getCause() instanceof Exception ex ? ex : e;
		} finally {
			pool.shutdownNow();
		}
	}

	private void report(Progress progress) {
		double f = total == 0 ? 1 : Math.min(1, done.get() / (double) total);
		String mb = String.format("%.0f / %.0f MB", done.get() / 1048576.0, total / 1048576.0);
		progress.update(Lang.t("Downloading  ·  ") + mb, 0.03 + f * 0.92);
	}

	// ---------------------------------------------------------------- mods

	/** Installs the Cherry HUD and the enabled mods (with their required dependencies) for this exact version. */
	private void installMods(Settings settings, String versionId) throws Exception {
		Path mods = modsDir(versionId);
		Files.createDirectories(mods);
		Path managedList = mods.resolve(".cherry-managed");
		Set<String> previous = new LinkedHashSet<>();
		if (Files.exists(managedList)) previous.addAll(Files.readAllLines(managedList));
		Set<String> managed = Collections.synchronizedSet(new LinkedHashSet<>());

		boolean hud = settings.cherryHud && hasCherryHud(versionId);
		if (hud) {
			try (InputStream in = Installer.class.getResourceAsStream("/bundled/hud/" + versionId + ".jar")) {
				Path target = mods.resolve("cherry-blossom-hud.jar");
				Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
				managed.add("cherry-hud@cherry-blossom-hud.jar");
			}
		}

		List<String> wanted = new ArrayList<>();
		if (hud) wanted.add("fabric-api");
		for (String slug : settings.enabledMods) if (ModCatalog.bySlug(slug) != null) wanted.add(slug);
		// The built-in shader pack runs on Iris (which brings Sodium along).
		if (settings.builtInShaders && !wanted.contains("iris")) wanted.add("iris");

		Set<String> doneProjects = ConcurrentHashMap.newKeySet();
		ExecutorService pool = Executors.newFixedThreadPool(6, r -> {
			Thread t = new Thread(r, "cherry-mods");
			t.setDaemon(true);
			return t;
		});
		try {
			List<Future<?>> futures = new ArrayList<>();
			for (String slug : wanted) {
				futures.add(pool.submit(() -> {
					try {
						installModrinth(slug, versionId, mods, managed, doneProjects, 0);
					} catch (IOException e) {
						System.err.println("Could not update " + slug + ": " + e.getMessage());
						for (String old : previous) if (old.startsWith(slug + "@")) managed.add(old);
					}
					return null;
				}));
			}
			for (Future<?> f : futures) f.get();
		} finally {
			pool.shutdownNow();
		}

		// Remove files we installed before but no longer want. Compare by file name: the same jar
		// can be recorded under its slug one time and its project id another.
		Set<String> keep = new HashSet<>();
		for (String m : managed) keep.add(fileName(m));
		for (String old : previous) {
			if (!keep.contains(fileName(old))) Files.deleteIfExists(mods.resolve(fileName(old)));
		}
		resolveMissingDependencies(mods, versionId, managed, doneProjects);
		Files.write(managedList, managed);
		installShaders(settings, versionId, managed.stream().anyMatch(m -> m.startsWith("iris@")));
	}

	/**
	 * Modrinth's dependency lists aren't always complete, so we also read each jar's fabric.mod.json.
	 * Missing requirements are fetched; if one can't be found, the mod that needs it is left out
	 * instead of letting the game crash on startup.
	 */
	private void resolveMissingDependencies(Path mods, String versionId, Set<String> managed, Set<String> doneProjects) throws IOException {
		for (int pass = 0; pass < 3; pass++) {
			Map<Path, Set<String>> missing = ModDeps.missing(ModDeps.scan(mods));
			if (missing.isEmpty()) return;
			Set<String> ids = new LinkedHashSet<>();
			missing.values().forEach(ids::addAll);
			int before = managed.size();
			for (String modId : ids) {
				for (String guess : ModDeps.modrinthGuesses(modId)) {
					int n = managed.size();
					try {
						installModrinth(guess, versionId, mods, managed, doneProjects, 0);
					} catch (IOException ignored) {
						// not a Modrinth project under that name
					}
					if (managed.size() > n) break;
				}
			}
			if (managed.size() == before) break;
		}
		for (int pass = 0; pass < 3; pass++) {
			Map<Path, Set<String>> missing = ModDeps.missing(ModDeps.scan(mods));
			boolean removed = false;
			for (Map.Entry<Path, Set<String>> e : missing.entrySet()) {
				String file = e.getKey().getFileName().toString();
				String entry = null;
				for (String m : managed) if (fileName(m).equals(file)) entry = m;
				if (entry == null) continue; // a mod you added yourself: not ours to remove
				System.err.println("Leaving out " + file + ": it needs " + e.getValue());
				Files.deleteIfExists(e.getKey());
				managed.remove(entry);
				removed = true;
			}
			if (!removed) return;
		}
	}

	/** The shader pack that ships inside the launcher. */
	public static final String SHADER_PACK = "E-LITE shaders 5.1.1.zip";

	/**
	 * Copies the built-in shader pack into this version's shaderpacks folder and points Iris at it.
	 * Your own choice in game (another pack, or shaders off with K) is kept after the first time.
	 */
	private void installShaders(Settings settings, String versionId, boolean irisInstalled) throws IOException {
		Path game = gameDir(versionId);
		Path iris = game.resolve("config").resolve("iris.properties");
		if (!settings.builtInShaders) {
			if (Files.exists(iris)) {
				java.util.Properties p = load(iris);
				if (SHADER_PACK.equals(p.getProperty("shaderPack"))) { p.setProperty("enableShaders", "false"); p.setProperty("cherryDisabled", "true"); store(iris, p); }
			}
			return;
		}
		if (!irisInstalled) return;
		Path packs = game.resolve("shaderpacks");
		Files.createDirectories(packs);
		Path target = packs.resolve(SHADER_PACK);
		try (InputStream in = Installer.class.getResourceAsStream("/bundled/shaders/elite.zip")) {
			if (in == null) return;
			byte[] data = in.readAllBytes();
			if (!Files.exists(target) || Files.size(target) != data.length) Files.write(target, data);
		}
		java.util.Properties p = Files.exists(iris) ? load(iris) : new java.util.Properties();
		String current = p.getProperty("shaderPack", "");
		if (current.isEmpty() || !Files.exists(packs.resolve(current)) || !"true".equals(p.getProperty("cherryConfigured"))) {
			p.setProperty("shaderPack", SHADER_PACK);
			p.setProperty("enableShaders", "true");
			p.setProperty("cherryConfigured", "true");
			store(iris, p);
		} else if (SHADER_PACK.equals(current) && "false".equals(p.getProperty("enableShaders")) && "true".equals(p.getProperty("cherryDisabled"))) {
			p.setProperty("enableShaders", "true");
			p.remove("cherryDisabled");
			store(iris, p);
		}
	}

	private static java.util.Properties load(Path f) throws IOException {
		java.util.Properties p = new java.util.Properties();
		try (var r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) { p.load(r); }
		return p;
	}

	private static void store(Path f, java.util.Properties p) throws IOException {
		Files.createDirectories(f.getParent());
		try (var w = Files.newBufferedWriter(f, StandardCharsets.UTF_8)) { p.store(w, "Iris settings (set up by Cherry Blossom Client)"); }
	}

	private static String fileName(String entry) {
		int at = entry.indexOf('@');
		return at < 0 ? entry : entry.substring(at + 1);
	}

	private void installModrinth(String project, String versionId, Path mods, Set<String> managed,
								 Set<String> doneProjects, int depth) throws IOException {
		if (depth > 4) return;
		String q = "?loaders=" + URLEncoder.encode("[\"fabric\"]", StandardCharsets.UTF_8)
				+ "&game_versions=" + URLEncoder.encode("[\"" + versionId + "\"]", StandardCharsets.UTF_8);
		List<Object> versions = Json.arr(Http.getJsonAny(MODRINTH + project + "/version" + q));
		if (versions.isEmpty()) return; // not made for this version
		Map<String, Object> best = null;
		for (Object o : versions) {
			Map<String, Object> v = Json.obj(o);
			if ("release".equals(Json.str(v, "version_type"))) { best = v; break; }
		}
		if (best == null) best = Json.obj(versions.get(0));
		String projectId = Json.str(best, "project_id");
		if (!doneProjects.add(projectId)) return;

		Map<String, Object> file = null;
		for (Object o : Json.arr(best, "files")) {
			Map<String, Object> f = Json.obj(o);
			if (file == null || Json.bool(f, "primary", false)) file = f;
		}
		if (file == null) return;
		String name = Json.str(file, "filename");
		String sha1 = Json.str(Json.obj(file, "hashes"), "sha1");
		Path target = mods.resolve(name);
		if (!matchesSha(target, sha1)) Http.download(Json.str(file, "url"), target, sha1, null);
		managed.add(project + "@" + name);

		for (Object o : Json.arr(best, "dependencies")) {
			Map<String, Object> d = Json.obj(o);
			if (!"required".equals(Json.str(d, "dependency_type"))) continue;
			String dep = Json.str(d, "project_id");
			if (dep != null && !doneProjects.contains(dep)) installModrinth(dep, versionId, mods, managed, doneProjects, depth + 1);
		}
	}

	// ---------------------------------------------------------------- options.txt

	static void applyVideoSettings(Path options, Map<String, String> values) throws IOException {
		List<String> lines = Files.exists(options) ? new ArrayList<>(Files.readAllLines(options)) : new ArrayList<>();
		Map<String, String> left = new LinkedHashMap<>(values);
		for (int i = 0; i < lines.size(); i++) {
			String line = lines.get(i);
			int c = line.indexOf(':');
			if (c <= 0) continue;
			String key = line.substring(0, c);
			if (left.containsKey(key)) lines.set(i, key + ":" + left.remove(key));
		}
		left.forEach((k, v) -> lines.add(k + ":" + v));
		Files.createDirectories(options.getParent());
		Files.write(options, lines);
	}

	// ---------------------------------------------------------------- command line

	private List<String> buildCommand(String java, int javaMajor, String id, Map<String, Object> vanilla,
									  Map<String, Object> fabric, List<Path> classpath, Path nativesDir,
									  Path logConfig, String logArgument, String assetIndex, Path gameAssets,
									  Path gameDir, Settings settings, Account account, String server) throws IOException {
		Files.createDirectories(nativesDir);
		StringBuilder cp = new StringBuilder();
		for (Path p : classpath) {
			if (!cp.isEmpty()) cp.append(File.pathSeparatorChar);
			cp.append(p.toAbsolutePath());
		}
		String host = null, port = "25565";
		if (server != null && !server.isBlank()) {
			host = server.trim();
			int colon = host.lastIndexOf(':');
			if (colon > 0 && host.indexOf(']') < colon) { port = host.substring(colon + 1); host = host.substring(0, colon); }
		}

		Map<String, Object> vArgs = Json.obj(vanilla, "arguments");
		boolean quickPlay = vArgs != null && Json.write(vArgs).contains("quickPlayMultiplayer");

		Map<String, String> vars = new HashMap<>();
		vars.put("natives_directory", nativesDir.toAbsolutePath().toString());
		vars.put("launcher_name", "cherry-blossom-client");
		vars.put("launcher_version", "2.0");
		vars.put("classpath", cp.toString());
		vars.put("classpath_separator", File.pathSeparator);
		vars.put("library_directory", libraries.toAbsolutePath().toString());
		vars.put("auth_player_name", account.name());
		vars.put("version_name", id);
		vars.put("game_directory", gameDir.toAbsolutePath().toString());
		vars.put("assets_root", assets.toAbsolutePath().toString());
		vars.put("game_assets", gameAssets.toAbsolutePath().toString());
		vars.put("assets_index_name", assetIndex);
		vars.put("auth_uuid", account.uuid());
		vars.put("auth_access_token", account.accessToken());
		vars.put("auth_session", "msa".equals(account.userType()) ? "token:" + account.accessToken() + ":" + account.uuid() : "-");
		vars.put("user_properties", "{}");
		vars.put("clientid", "");
		vars.put("auth_xuid", account.xuid() == null ? "" : account.xuid());
		vars.put("user_type", account.userType());
		vars.put("version_type", "release");
		vars.put("resolution_width", Integer.toString(settings.gameWidth));
		vars.put("resolution_height", Integer.toString(settings.gameHeight));
		if (host != null) vars.put("quickPlayMultiplayer", host + ":" + port);

		Map<String, Boolean> features = new HashMap<>();
		features.put("has_custom_resolution", !settings.fullscreen);
		features.put("is_quick_play_multiplayer", host != null && quickPlay);

		List<String> cmd = new ArrayList<>();
		cmd.add(java);
		cmd.addAll(memoryFlags(settings.ramMb, javaMajor));
		if (!settings.extraJvmArgs.isBlank()) cmd.addAll(List.of(settings.extraJvmArgs.trim().split("\\s+")));

		List<String> game = new ArrayList<>();
		if (vArgs != null) {
			cmd.addAll(Rules.expand(Json.arr(vArgs, "jvm"), vars, features));
			game.addAll(Rules.expand(Json.arr(vArgs, "game"), vars, features));
		} else {
			// Pre-1.13 versions describe their arguments as one string.
			if (Rules.osName().equals("windows")) cmd.add("-XX:HeapDumpPath=MojangTricksIntelDriversForPerformance_javaw.exe_minecraft.exe.heapdump");
			cmd.add("-Djava.library.path=" + nativesDir.toAbsolutePath());
			cmd.add("-cp");
			cmd.add(cp.toString());
			String legacy = Json.str(vanilla, "minecraftArguments");
			if (legacy != null) for (String a : legacy.trim().split("\\s+")) game.add(Rules.fill(a, vars));
			boolean modernMain = legacy != null && legacy.contains("--version");
			if (modernMain && !settings.fullscreen) {
				game.addAll(List.of("--width", vars.get("resolution_width"), "--height", vars.get("resolution_height")));
			}
		}
		if (host != null && !quickPlay) game.addAll(List.of("--server", host, "--port", port));
		if (settings.fullscreen) game.add("--fullscreen");

		if (fabric != null) {
			Path mods = modsDir(id);
			cmd.add("-Dfabric.modsFolder=" + mods.toAbsolutePath());
			Map<String, Object> fArgs = Json.obj(fabric, "arguments");
			cmd.addAll(Rules.expand(Json.arr(fArgs, "jvm"), vars, features));
			game.addAll(Rules.expand(Json.arr(fArgs, "game"), vars, features));
		}
		if (logConfig != null && logArgument != null) cmd.add(logArgument.replace("${path}", logConfig.toAbsolutePath().toString()));
		cmd.add(fabric != null ? Json.str(fabric, "mainClass") : Json.str(vanilla, "mainClass"));
		cmd.addAll(game);
		return cmd;
	}

	/**
	 * Heap size from the slider. With room to breathe on modern Java, generational ZGC gives the
	 * smoothest frame times; on small heaps or older Java, G1 tuned the way Mojang tunes it.
	 */
	static List<String> memoryFlags(int ramMb, int javaMajor) {
		List<String> f = new ArrayList<>();
		f.add("-Xmx" + ramMb + "M");
		f.add("-Xms" + Math.min(ramMb, 1024) + "M");
		if (javaMajor >= 25) f.add("-XX:+UseCompactObjectHeaders");
		if (ramMb >= 4096 && javaMajor >= 21) {
			f.add("-XX:+UseZGC");
			if (javaMajor < 23) f.add("-XX:+ZGenerational");
		} else {
			f.add("-XX:+UseG1GC");
			f.add("-XX:+UnlockExperimentalVMOptions");
			f.add("-XX:G1NewSizePercent=20");
			f.add("-XX:G1ReservePercent=20");
			f.add("-XX:MaxGCPauseMillis=50");
			f.add("-XX:G1HeapRegionSize=" + (ramMb >= 3072 ? "32M" : "16M"));
		}
		f.add("-XX:+UseStringDeduplication");
		f.add("-XX:+DisableExplicitGC");
		return f;
	}
}
