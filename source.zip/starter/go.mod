module cherryblossom/starter

go 1.22
