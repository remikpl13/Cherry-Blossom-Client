//go:build windows

package main

import (
	"fmt"
	"syscall"
	"unsafe"
)

// A tiny native progress window drawn with GDI. Only shown the first time,
// while Java downloads. No UI frameworks, so the exe stays small.

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")

	pRegisterClassExW   = user32.NewProc("RegisterClassExW")
	pCreateWindowExW    = user32.NewProc("CreateWindowExW")
	pDefWindowProcW     = user32.NewProc("DefWindowProcW")
	pGetMessageW        = user32.NewProc("GetMessageW")
	pTranslateMessage   = user32.NewProc("TranslateMessage")
	pDispatchMessageW   = user32.NewProc("DispatchMessageW")
	pPostQuitMessage    = user32.NewProc("PostQuitMessage")
	pDestroyWindow      = user32.NewProc("DestroyWindow")
	pShowWindow         = user32.NewProc("ShowWindow")
	pUpdateWindow       = user32.NewProc("UpdateWindow")
	pBeginPaint         = user32.NewProc("BeginPaint")
	pEndPaint           = user32.NewProc("EndPaint")
	pFillRect           = user32.NewProc("FillRect")
	pDrawTextW          = user32.NewProc("DrawTextW")
	pInvalidateRect     = user32.NewProc("InvalidateRect")
	pSetTimer           = user32.NewProc("SetTimer")
	pKillTimer          = user32.NewProc("KillTimer")
	pGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	pMessageBoxW        = user32.NewProc("MessageBoxW")
	pSetWindowRgn       = user32.NewProc("SetWindowRgn")
	pLoadCursorW        = user32.NewProc("LoadCursorW")
	pLoadIconW          = user32.NewProc("LoadIconW")
	pSetProcessDPIAware = user32.NewProc("SetProcessDPIAware")
	pGetDpiForSystem    = user32.NewProc("GetDpiForSystem")

	pCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	pDeleteObject           = gdi32.NewProc("DeleteObject")
	pSelectObject           = gdi32.NewProc("SelectObject")
	pSetTextColor           = gdi32.NewProc("SetTextColor")
	pSetBkMode              = gdi32.NewProc("SetBkMode")
	pCreateFontW            = gdi32.NewProc("CreateFontW")
	pCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	pCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	pBitBlt                 = gdi32.NewProc("BitBlt")
	pDeleteDC               = gdi32.NewProc("DeleteDC")
	pCreateRoundRectRgn     = gdi32.NewProc("CreateRoundRectRgn")

	pGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")
)

const (
	wsPopup       = 0x80000000
	wsExToolWin   = 0x00000080
	wsExAppWindow = 0x00040000
	wmDestroy     = 0x0002
	wmPaint       = 0x000F
	wmClose       = 0x0010
	wmEraseBkgnd  = 0x0014
	wmTimer       = 0x0113
	swShow        = 5
	smCxScreen    = 0
	smCyScreen    = 1
	srcCopy       = 0x00CC0020
	transparent   = 1
	dtLeft        = 0x0000
	dtSingleLine  = 0x0020
	dtVCenter     = 0x0004
	dtNoPrefix    = 0x0800
	dtEndEllipsis = 0x8000
	idcArrow      = 32512
	fwSemibold    = 600
	fwNormal      = 400
	clearType     = 5
)

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type point struct{ x, y int32 }

type msg struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	pt      point
}

type rect struct{ left, top, right, bottom int32 }

type paintStruct struct {
	hdc         uintptr
	fErase      int32
	rcPaint     rect
	fRestore    int32
	fIncUpdate  int32
	rgbReserved [32]byte
}

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

var (
	current *progress
	scale   = 1.0
	shownF  = 0.0
)

func s(v int) int32 { return int32(float64(v)*scale + 0.5) }

func utf16(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

func messageBox(title, text string) {
	pMessageBoxW.Call(0, uintptr(unsafe.Pointer(utf16(text))), uintptr(unsafe.Pointer(utf16(title))), 0x10)
}

func runProgressWindow(p *progress) {
	current = p
	if pSetProcessDPIAware.Find() == nil {
		pSetProcessDPIAware.Call()
	}
	if pGetDpiForSystem.Find() == nil {
		if dpi, _, _ := pGetDpiForSystem.Call(); dpi >= 96 {
			scale = float64(dpi) / 96.0
		}
	}

	hInst, _, _ := pGetModuleHandleW.Call(0)
	className := utf16("CherryBlossomStarter")
	cursor, _, _ := pLoadCursorW.Call(0, idcArrow)
	icon, _, _ := pLoadIconW.Call(hInst, 1) // icon resource embedded at build time
	wc := wndClassEx{
		lpfnWndProc:   syscall.NewCallback(wndProc),
		hInstance:     hInst,
		hCursor:       cursor,
		hIcon:         icon,
		hIconSm:       icon,
		lpszClassName: className,
	}
	wc.cbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	w, h := s(460), s(150)
	sw, _, _ := pGetSystemMetrics.Call(smCxScreen)
	sh, _, _ := pGetSystemMetrics.Call(smCyScreen)
	x, y := (int32(sw)-w)/2, (int32(sh)-h)/2
	hwnd, _, _ := pCreateWindowExW.Call(wsExAppWindow, uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(utf16("Cherry Blossom Client"))), wsPopup,
		uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, hInst, 0)
	if hwnd == 0 {
		// No window? Just wait for the download quietly.
		for !p.finished.Load() {
			sleepMs(100)
		}
		return
	}
	rgn, _, _ := pCreateRoundRectRgn.Call(0, 0, uintptr(w+1), uintptr(h+1), uintptr(s(18)), uintptr(s(18)))
	pSetWindowRgn.Call(hwnd, rgn, 1)
	pShowWindow.Call(hwnd, swShow)
	pUpdateWindow.Call(hwnd)
	pSetTimer.Call(hwnd, 1, 33, 0)

	var m msg
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}

func wndProc(hwnd, umsg, wParam, lParam uintptr) uintptr {
	switch umsg {
	case wmTimer:
		if current.finished.Load() {
			pKillTimer.Call(hwnd, 1)
			pDestroyWindow.Call(hwnd)
			return 0
		}
		pInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case wmEraseBkgnd:
		return 1
	case wmPaint:
		paint(hwnd)
		return 0
	case wmClose:
		return 0 // keep going until Java is ready
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, umsg, wParam, lParam)
	return r
}

func fillRect(dc uintptr, l, t, r, b int32, color uintptr) {
	brush, _, _ := pCreateSolidBrush.Call(color)
	rc := rect{l, t, r, b}
	pFillRect.Call(dc, uintptr(unsafe.Pointer(&rc)), brush)
	pDeleteObject.Call(brush)
}

func text(dc uintptr, str string, l, t, r, b int32, size int, weight int, color uintptr) {
	font, _, _ := pCreateFontW.Call(uintptr(-s(size)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, clearType, 0,
		uintptr(unsafe.Pointer(utf16("Segoe UI"))))
	old, _, _ := pSelectObject.Call(dc, font)
	pSetTextColor.Call(dc, color)
	pSetBkMode.Call(dc, transparent)
	rc := rect{l, t, r, b}
	u, _ := syscall.UTF16FromString(str)
	pDrawTextW.Call(dc, uintptr(unsafe.Pointer(&u[0])), uintptr(len(u)-1), uintptr(unsafe.Pointer(&rc)),
		dtLeft|dtSingleLine|dtVCenter|dtNoPrefix|dtEndEllipsis)
	pSelectObject.Call(dc, old)
	pDeleteObject.Call(font)
}

func paint(hwnd uintptr) {
	var ps paintStruct
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	w, h := s(460), s(150)

	// Draw off-screen first so nothing flickers.
	mem, _, _ := pCreateCompatibleDC.Call(hdc)
	bmp, _, _ := pCreateCompatibleBitmap.Call(hdc, uintptr(w), uintptr(h))
	oldBmp, _, _ := pSelectObject.Call(mem, bmp)

	fillRect(mem, 0, 0, w, h, rgb(0x1C, 0x12, 0x17))
	fillRect(mem, 0, 0, w, s(3), rgb(0xF7, 0xA8, 0xC4))

	text(mem, "Cherry Blossom Client", s(28), s(24), w-s(28), s(58), 21, fwSemibold, rgb(0xF8, 0xEE, 0xF2))

	stage, _ := current.stage.Load().(string)
	done, total := current.done.Load(), current.total.Load()
	f := 0.0
	if total > 0 {
		f = float64(done) / float64(total)
		if f > 1 {
			f = 1
		}
	}
	shownF += (f - shownF) * 0.25
	line := stage
	if total > 0 && stage != "Unpacking Java" {
		line = fmt.Sprintf("%s  ·  %d / %d MB", stage, done>>20, total>>20)
	}
	text(mem, line, s(28), s(62), w-s(28), s(88), 13, fwNormal, rgb(0xBD, 0xA7, 0xB1))

	bx, by, bw := s(28), s(108), w-s(56)
	fillRect(mem, bx, by, bx+bw, by+s(4), rgb(0x3A, 0x28, 0x30))
	fill := int32(float64(bw) * shownF)
	if fill > 0 {
		fillRect(mem, bx, by, bx+fill, by+s(4), rgb(0xF7, 0xA8, 0xC4))
	}

	pBitBlt.Call(hdc, 0, 0, uintptr(w), uintptr(h), mem, 0, 0, srcCopy)
	pSelectObject.Call(mem, oldBmp)
	pDeleteObject.Call(bmp)
	pDeleteDC.Call(mem)
	pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
}
