//go:build windows

// Cherry Blossom Client starter.
//
// The launcher itself is a small Java app. This exe makes sure a private copy of
// Java 25 sits in the client folder (downloading it once, with a small progress
// window), then opens the launcher and gets out of the way.
package main

import (
	"archive/zip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
)

const adoptiumAPI = "https://api.adoptium.net/v3/assets/latest/25/hotspot?architecture=x64&image_type=jre&os=windows&vendor=eclipse"

func init() {
	// Win32 windows must stay on the thread that created them.
	runtime.LockOSThread()
}

func main() {
	exe, err := os.Executable()
	if err != nil {
		fail("Couldn't find where Cherry Blossom Client is installed.", err)
	}
	root := filepath.Dir(exe)
	jar := filepath.Join(root, "launcher", "cherry-launcher.jar")
	javaw := filepath.Join(root, "runtime", "jre", "bin", "javaw.exe")

	// The launcher downloads updates next to itself; swap them in before it starts.
	// Waits a moment in case the old launcher is still closing.
	if _, err := os.Stat(jar + ".new"); err == nil {
		for i := 0; i < 20; i++ {
			os.Remove(jar + ".old")
			if os.Rename(jar, jar+".old") == nil || !exists(jar) {
				break
			}
			sleepMs(250)
		}
		if err := os.Rename(jar+".new", jar); err != nil {
			os.Rename(jar+".old", jar) // put the old one back
		}
	}

	if _, err := os.Stat(jar); err != nil {
		fail("The launcher file is missing:\n"+jar+"\n\nPlease copy the whole Cherry Blossom Client folder again.", nil)
	}

	if _, err := os.Stat(javaw); err != nil {
		if err := setupJava(root); err != nil {
			fail("Couldn't set up Java. Check your internet connection and try again.", err)
		}
	}

	cmd := exec.Command(javaw,
		"-Xmx256m", "-XX:+UseSerialGC", "-XX:TieredStopAtLevel=1",
		"-Dfile.encoding=UTF-8", "-jar", jar)
	cmd.Dir = root
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if err := cmd.Start(); err != nil {
		fail("Couldn't open the launcher.", err)
	}
}

// ---------------------------------------------------------------- Java download

type progress struct {
	done, total atomic.Int64
	stage       atomic.Value // string
	err         atomic.Value // error
	finished    atomic.Bool
}

func setupJava(root string) error {
	p := &progress{}
	p.stage.Store("Getting Java ready (first launch only)")
	go func() {
		err := downloadJava(root, p)
		if err != nil {
			p.err.Store(err)
		}
		p.finished.Store(true)
	}()
	runProgressWindow(p) // returns when finished
	if v := p.err.Load(); v != nil {
		return v.(error)
	}
	return nil
}

func downloadJava(root string, p *progress) error {
	client := &http.Client{Timeout: 0}
	req, _ := http.NewRequest("GET", adoptiumAPI, nil)
	req.Header.Set("User-Agent", "CherryBlossomClient/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	var assets []struct {
		Binary struct {
			Package struct {
				Link     string `json:"link"`
				Checksum string `json:"checksum"`
				Size     int64  `json:"size"`
			} `json:"package"`
		} `json:"binary"`
	}
	err = json.NewDecoder(resp.Body).Decode(&assets)
	resp.Body.Close()
	if err != nil {
		return err
	}
	if len(assets) == 0 {
		return errors.New("no Java 25 build found")
	}
	pkg := assets[0].Binary.Package
	p.total.Store(pkg.Size)

	runtimeDir := filepath.Join(root, "runtime")
	if err := os.MkdirAll(runtimeDir, 0o755); err != nil {
		return err
	}
	zipPath := filepath.Join(runtimeDir, "jre-download.zip")
	if err := fetch(client, pkg.Link, zipPath, pkg.Checksum, p); err != nil {
		return err
	}
	defer os.Remove(zipPath)

	p.stage.Store("Unpacking Java")
	tmp := filepath.Join(runtimeDir, "jre-unpacking")
	os.RemoveAll(tmp)
	if err := unzipStripTop(zipPath, tmp); err != nil {
		return err
	}
	final := filepath.Join(runtimeDir, "jre")
	os.RemoveAll(final)
	return os.Rename(tmp, final)
}

func fetch(client *http.Client, url, dst, sha string, p *progress) error {
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("User-Agent", "CherryBlossomClient/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("download failed: HTTP %d", resp.StatusCode)
	}
	f, err := os.Create(dst)
	if err != nil {
		return err
	}
	h := sha256.New()
	buf := make([]byte, 256*1024)
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			if _, werr := f.Write(buf[:n]); werr != nil {
				f.Close()
				return werr
			}
			h.Write(buf[:n])
			p.done.Add(int64(n))
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			f.Close()
			return rerr
		}
	}
	if err := f.Close(); err != nil {
		return err
	}
	if sha != "" && !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), sha) {
		os.Remove(dst)
		return errors.New("the Java download was corrupted, please try again")
	}
	return nil
}

// unzipStripTop extracts the archive, dropping the single top-level folder (jdk-25.x-jre/).
func unzipStripTop(zipPath, dst string) error {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer r.Close()
	base := filepath.Clean(dst) + string(os.PathSeparator)
	for _, f := range r.File {
		name := strings.ReplaceAll(f.Name, "\\", "/")
		if i := strings.Index(name, "/"); i >= 0 {
			name = name[i+1:]
		} else {
			continue
		}
		if name == "" {
			continue
		}
		target := filepath.Join(dst, filepath.FromSlash(name))
		if !strings.HasPrefix(target, base) {
			return errors.New("unexpected path in Java archive")
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		if err := extract(f, target); err != nil {
			return err
		}
	}
	return nil
}

func extract(f *zip.File, target string) error {
	in, err := f.Open()
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(target)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

func fail(msg string, err error) {
	if err != nil {
		msg += "\n\n(" + err.Error() + ")"
	}
	messageBox("Cherry Blossom Client", msg)
	os.Exit(1)
}

func exists(p string) bool { _, err := os.Stat(p); return err == nil }

func sleepMs(ms int) { time.Sleep(time.Duration(ms) * time.Millisecond) }
