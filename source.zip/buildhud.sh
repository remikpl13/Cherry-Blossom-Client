#!/bin/bash
# buildhud.sh <mc_version> <fabric_api_version> [srcdir]
set -e
V=$1; F=$2; SRC=${3:-/home/claude/cherry/mod}
D=/home/claude/cherry/hudbuilds/$V
mkdir -p $D
rm -rf $D/src; cp -r $SRC/src $SRC/build.gradle $SRC/settings.gradle $SRC/gradle.properties $D/
[ -n "$4" ] && cp -r /home/claude/cherry/mod/variants/$4/. $D/src/client/java/
sed -i "s/^minecraft_version=.*/minecraft_version=$V/; s/^fabric_api_version=.*/fabric_api_version=$F/" $D/gradle.properties
rm -rf $D/build/libs; cd $D && JAVA_HOME=/opt/jdk25 /opt/gradle97/gradle-9.7.1/bin/gradle build --no-daemon -q 2>&1 | grep -v "Picked up" | head -40
mkdir -p /home/claude/cherry/hudjars && cp $D/build/libs/cherry-blossom-hud-2.0.0.jar /home/claude/cherry/hudjars/$V.jar && echo "OK $V"
