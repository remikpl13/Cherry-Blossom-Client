package dev.cherryblossom.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Numbers several widgets need that have to be measured over time: clicks per second, speed, session time. */
public final class Stats {
	private Stats() {}

	private static final long[] left = new long[64];
	private static final long[] right = new long[64];
	private static int leftHead, rightHead;

	private static double lastX, lastZ;
	private static boolean hasLast;
	private static double speed;
	private static long sessionStart;

	/** Called from the mouse mixin on every button press while playing. */
	public static void click(boolean isLeft) {
		long now = System.nanoTime();
		if (isLeft) { left[leftHead] = now; leftHead = (leftHead + 1) % left.length; }
		else { right[rightHead] = now; rightHead = (rightHead + 1) % right.length; }
	}

	public static int cps(boolean isLeft) {
		long[] ring = isLeft ? left : right;
		long cutoff = System.nanoTime() - 1_000_000_000L;
		int n = 0;
		for (long t : ring) if (t != 0 && t > cutoff) n++;
		return n;
	}

	/** Called once per client tick (20 times a second). */
	public static void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null) {
			hasLast = false;
			sessionStart = 0;
			return;
		}
		if (sessionStart == 0) sessionStart = System.currentTimeMillis();
		if (hasLast) {
			double dx = p.getX() - lastX, dz = p.getZ() - lastZ;
			double now = Math.sqrt(dx * dx + dz * dz) * 20.0;
			speed = speed * 0.7 + now * 0.3; // light smoothing so the number is readable
		}
		lastX = p.getX();
		lastZ = p.getZ();
		hasLast = true;
	}

	public static double speed() {
		return speed;
	}

	public static long sessionMillis() {
		return sessionStart == 0 ? 0 : System.currentTimeMillis() - sessionStart;
	}
}
