package dev.cherryblossom.client.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Window title reads "Cherry Blossom Client 26.3 - Singleplayer" instead of "Minecraft* 26.3 ...". */
@Mixin(Minecraft.class)
public abstract class MinecraftTitleMixin {
	@Inject(method = "createTitle", at = @At("RETURN"), cancellable = true)
	private void cherryblossom$title(CallbackInfoReturnable<String> cir) {
		String title = cir.getReturnValue();
		if (title != null) {
			cir.setReturnValue(title.replaceFirst("^Minecraft\\*?", "Cherry Blossom Client"));
		}
	}
}
