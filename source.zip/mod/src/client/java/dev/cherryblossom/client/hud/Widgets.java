package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.config.CherryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.player.LocalPlayer;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** Every widget the client ships with. Each one is tiny; the shared look lives in TextWidget/HudWidget. */
public final class Widgets {
	private Widgets() {}

	public static final int GOOD = 0xFFA8E6C1;
	public static final int OKAY = 0xFFF3D98B;
	public static final int BAD = 0xFFF09090;

	private static final DateTimeFormatter H24 = DateTimeFormatter.ofPattern("HH:mm");
	private static final DateTimeFormatter H12 = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);

	public static final HudWidget FPS = new TextWidget("fps", "FPS", "Frames per second", true, 0f, 0f) {
		@Override public String label() { return "FPS"; }
		@Override protected String compute(Minecraft mc) { return Integer.toString(mc.getFps()); }
		@Override protected String sizingSample() { return "000"; }
		@Override protected int color(Minecraft mc) {
			int fps = mc.getFps();
			return fps >= 60 ? GOOD : fps >= 30 ? OKAY : BAD;
		}
	};

	public static final HudWidget PING = new TextWidget("ping", "Ping", "Your latency to the server", true, 0f, 0.075f) {
		@Override public String label() { return "PING"; }
		@Override protected String sizingSample() { return "000 ms"; }
		@Override protected String compute(Minecraft mc) {
			if (mc.isLocalServer()) return "local";
			int ms = latency(mc);
			return ms < 0 ? "..." : ms + " ms";
		}
		@Override protected int color(Minecraft mc) {
			if (mc.isLocalServer()) return GOOD;
			int ms = latency(mc);
			if (ms < 0) return OKAY;
			return ms < 80 ? GOOD : ms < 160 ? OKAY : BAD;
		}
	};

	public static final HudWidget SERVER = new TextWidget("server", "Server", "Which server you're on", true, 0f, 0.15f) {
		@Override public String label() { return "SERVER"; }
		@Override protected String sizingSample() { return "Singleplayer"; }
		@Override protected String compute(Minecraft mc) {
			if (mc.isLocalServer()) return "Singleplayer";
			ServerData data = mc.getCurrentServer();
			if (data == null) return "Offline";
			// Respect the vanilla "hide server address" option for streamers.
			String text = mc.options.hideServerAddress || data.ip == null ? data.name : data.ip;
			if (text == null || text.isBlank()) text = "Multiplayer";
			return text.length() > 28 ? text.substring(0, 27) + "…" : text;
		}
	};

	public static final HudWidget CPS = new TextWidget("cps", "CPS", "Clicks per second, left | right", false, 0f, 0.225f) {
		@Override public String label() { return "CPS"; }
		@Override protected String sizingSample() { return "00 | 00"; }
		@Override protected String compute(Minecraft mc) { return Stats.cps(true) + " | " + Stats.cps(false); }
	};

	public static final HudWidget COORDS = new TextWidget("coords", "Coordinates", "Where you are in the world", false, 0f, 0.30f) {
		@Override public String label() { return "XYZ"; }
		@Override protected String sizingSample() { return "-0000 000 -0000"; }
		@Override protected String compute(Minecraft mc) {
			LocalPlayer p = mc.player;
			if (p == null) return "";
			return (int) Math.floor(p.getX()) + " " + (int) Math.floor(p.getY()) + " " + (int) Math.floor(p.getZ());
		}
	};

	public static final HudWidget DIRECTION = new TextWidget("direction", "Direction", "Which way you're facing", false, 0f, 0.375f) {
		private static final String[] NAMES = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
		private static final String[] AXES = {"+Z", "-X +Z", "-X", "-X -Z", "-Z", "+X -Z", "+X", "+X +Z"};
		@Override public String label() { return "FACING"; }
		@Override protected String sizingSample() { return "NW  -X -Z"; }
		@Override protected String compute(Minecraft mc) {
			if (mc.player == null) return "";
			float yaw = ((mc.player.getYRot() % 360) + 360) % 360;
			int i = Math.round(yaw / 45f) % 8;
			return NAMES[i] + "  " + AXES[i];
		}
	};

	public static final HudWidget BIOME = new TextWidget("biome", "Biome", "The biome you're standing in", false, 0f, 0.45f) {
		@Override public String label() { return "BIOME"; }
		@Override protected String sizingSample() { return "Cherry Grove"; }
		@Override protected String compute(Minecraft mc) {
			if (mc.player == null || mc.level == null) return "";
			return mc.level.getBiome(mc.player.blockPosition()).unwrapKey()
					.map(k -> pretty(k.identifier().getPath())).orElse("");
		}
	};

	public static final HudWidget SPEED = new TextWidget("speed", "Speed", "How fast you're moving, blocks per second", false, 0f, 0.525f) {
		@Override public String label() { return "SPEED"; }
		@Override protected String sizingSample() { return "00.0 b/s"; }
		@Override protected String compute(Minecraft mc) {
			return mc.player == null ? "" : String.format(Locale.ROOT, "%.1f b/s", Stats.speed());
		}
	};

	public static final HudWidget SATURATION = new TextWidget("saturation", "Saturation", "Hidden food saturation", false, 0f, 0.6f) {
		@Override public String label() { return "SAT"; }
		@Override protected String sizingSample() { return "00.0"; }
		@Override protected String compute(Minecraft mc) {
			return mc.player == null ? "" : String.format(Locale.ROOT, "%.1f", mc.player.getFoodData().getSaturationLevel());
		}
		@Override protected int color(Minecraft mc) {
			if (mc.player == null) return GOOD;
			float s = mc.player.getFoodData().getSaturationLevel();
			return s >= 5 ? GOOD : s >= 1 ? OKAY : BAD;
		}
	};

	public static final HudWidget CLOCK = new TextWidget("clock", "Clock", "Your real-world time", false, 1f, 0f) {
		@Override public String label() { return ""; }
		@Override protected String sizingSample() { return "00:00 PM"; }
		@Override protected String compute(Minecraft mc) {
			return LocalTime.now().format(CherryConfig.get().clock24h ? H24 : H12);
		}
	};

	public static final HudWidget PLAYTIME = new TextWidget("playtime", "Session Time", "How long you've been playing this session", false, 1f, 0.075f) {
		@Override public String label() { return "PLAYED"; }
		@Override protected String sizingSample() { return "00h 00m"; }
		@Override protected String compute(Minecraft mc) {
			long m = Stats.sessionMillis() / 60000;
			return m < 60 ? m + "m" : (m / 60) + "h " + String.format("%02dm", m % 60);
		}
	};

	public static final HudWidget MEMORY = new TextWidget("memory", "Memory", "How much of your RAM the game is using", false, 1f, 0.15f) {
		@Override public String label() { return "MEM"; }
		@Override protected String sizingSample() { return "100%  0000 / 0000 MB"; }
		@Override protected String compute(Minecraft mc) {
			Runtime r = Runtime.getRuntime();
			long used = (r.totalMemory() - r.freeMemory()) >> 20, max = r.maxMemory() >> 20;
			return (used * 100 / Math.max(1, max)) + "%  " + used + " / " + max + " MB";
		}
		@Override protected int color(Minecraft mc) {
			Runtime r = Runtime.getRuntime();
			double f = (r.totalMemory() - r.freeMemory()) / (double) r.maxMemory();
			return f < 0.7 ? GOOD : f < 0.9 ? OKAY : BAD;
		}
	};

	public static final HudWidget SPRINT = new TextWidget("sprint", "Sprint Status", "Shows when you're sprinting (and if it's toggled)", false, 0f, 1f) {
		@Override public String label() { return ""; }
		@Override protected String sizingSample() { return "Sprinting"; }
		@Override protected String previewValue() { return "Sprinting (toggled)"; }
		@Override protected String compute(Minecraft mc) {
			if (mc.player == null || !mc.player.isSprinting()) return "";
			return mc.options.toggleSprint().get() ? "Sprinting (toggled)" : "Sprinting";
		}
	};

	public static final HudWidget KEYSTROKES = new KeystrokesWidget();
	public static final HudWidget ARMOR = new ArmorWidget();
	public static final HudWidget POTIONS = new PotionWidget();

	public static final List<HudWidget> ALL = List.of(FPS, PING, SERVER, CPS, KEYSTROKES, ARMOR, POTIONS,
			COORDS, DIRECTION, BIOME, SPEED, SATURATION, CLOCK, PLAYTIME, MEMORY, SPRINT);

	static int latency(Minecraft mc) {
		ClientPacketListener conn = mc.getConnection();
		if (conn == null || mc.player == null) return -1;
		PlayerInfo info = conn.getPlayerInfo(mc.player.getUUID());
		return info == null ? -1 : info.getLatency();
	}

	static String pretty(String path) {
		StringBuilder b = new StringBuilder();
		for (String part : path.split("_")) {
			if (part.isEmpty()) continue;
			if (!b.isEmpty()) b.append(' ');
			b.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
		}
		return b.toString();
	}
}
