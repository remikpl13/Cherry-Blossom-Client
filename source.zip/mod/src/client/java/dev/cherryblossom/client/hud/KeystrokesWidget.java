package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.gui.Theme;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** W A S D, both mouse buttons (with CPS) and the space bar. Keys light up with a quick fade. */
final class KeystrokesWidget extends HudWidget {
	private static final int KEY = 18, GAP = 2;
	private static final int WIDTH = KEY * 3 + GAP * 2;

	private final float[] glow = new float[7];
	private long last = System.nanoTime();

	KeystrokesWidget() {
		super("keystrokes", "Keystrokes", "Movement keys, mouse buttons and CPS", false, 1f, 0.55f);
	}

	@Override public int width(Font font, Minecraft mc, boolean preview) { return WIDTH; }

	@Override public int height(Font font, Minecraft mc, boolean preview) { return KEY * 3 + GAP * 3 + 9; }

	@Override
	protected void render(GuiGraphicsExtractor g, Font font, Minecraft mc, float alpha, boolean preview) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - last) / 1e9f);
		last = now;
		var o = mc.options;
		KeyMapping[] keys = {o.keyUp, o.keyLeft, o.keyDown, o.keyRight, o.keyAttack, o.keyUse, o.keyJump};
		for (int i = 0; i < keys.length; i++) glow[i] = Theme.approach(glow[i], keys[i].isDown() ? 1f : 0f, 22f, dt);

		key(g, font, "W", KEY + GAP, 0, KEY, KEY, glow[0], alpha);
		key(g, font, "A", 0, KEY + GAP, KEY, KEY, glow[1], alpha);
		key(g, font, "S", KEY + GAP, KEY + GAP, KEY, KEY, glow[2], alpha);
		key(g, font, "D", (KEY + GAP) * 2, KEY + GAP, KEY, KEY, glow[3], alpha);

		int half = (WIDTH - GAP) / 2;
		int my = (KEY + GAP) * 2;
		mouse(g, font, "LMB", Stats.cps(true), 0, my, half, KEY, glow[4], alpha);
		mouse(g, font, "RMB", Stats.cps(false), half + GAP, my, WIDTH - half - GAP, KEY, glow[5], alpha);

		int sy = my + KEY + GAP;
		int fill = Theme.mix(Theme.WIDGET_BG, Theme.withAlpha(Theme.accent(), 0.9f), glow[6]);
		Theme.rounded(g, 0, sy, WIDTH, sy + 9, Theme.withAlpha(fill, alpha));
		int bar = Theme.mix(Theme.TEXT, 0xFF2A1520, glow[6]);
		g.fill(WIDTH / 2 - 10, sy + 4, WIDTH / 2 + 10, sy + 5, Theme.withAlpha(bar, alpha));
	}

	private static void key(GuiGraphicsExtractor g, Font font, String label, int x, int y, int w, int h, float lit, float alpha) {
		int fill = Theme.mix(Theme.WIDGET_BG, Theme.withAlpha(Theme.accent(), 0.9f), lit);
		Theme.rounded(g, x, y, x + w, y + h, Theme.withAlpha(fill, alpha));
		int text = Theme.mix(Theme.TEXT, 0xFF2A1520, lit);
		g.text(font, label, x + (w - font.width(label)) / 2 + 1, y + (h - 8) / 2 + 1, Theme.withAlpha(text, alpha),
				CherryConfig.get().textShadow && lit < 0.5f);
	}

	private static void mouse(GuiGraphicsExtractor g, Font font, String label, int cps, int x, int y, int w, int h, float lit, float alpha) {
		int fill = Theme.mix(Theme.WIDGET_BG, Theme.withAlpha(Theme.accent(), 0.9f), lit);
		Theme.rounded(g, x, y, x + w, y + h, Theme.withAlpha(fill, alpha));
		int text = Theme.mix(Theme.TEXT, 0xFF2A1520, lit);
		String s = cps > 0 ? cps + " CPS" : label;
		g.text(font, s, x + (w - font.width(s)) / 2 + 1, y + (h - 8) / 2 + 1, Theme.withAlpha(text, alpha),
				CherryConfig.get().textShadow && lit < 0.5f);
	}
}
