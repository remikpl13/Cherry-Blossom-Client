package dev.cherryblossom.client.friends;

import dev.cherryblossom.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayDeque;

/** Small pink pop-ups in the top right: "Ana is online", friend requests and so on. */
public final class FriendToasts {
	private record Toast(String title, String text, long shownAt) {}

	private static final ArrayDeque<Toast> queue = new ArrayDeque<>();
	private static Toast current;
	private static final long SHOW_MS = 4500;

	private FriendToasts() {}

	public static synchronized void show(String title, String text) {
		if (queue.size() < 6) queue.add(new Toast(title, text, 0));
	}

	public static synchronized void render(GuiGraphicsExtractor g) {
		long now = System.currentTimeMillis();
		if (current == null || now - current.shownAt > SHOW_MS) {
			Toast next = queue.poll();
			current = next == null ? null : new Toast(next.title, next.text, now);
		}
		if (current == null) return;
		Font font = Minecraft.getInstance().font;
		float age = (now - current.shownAt) / 1000f;
		float in = Theme.easeOut(Math.min(1f, age / 0.25f));
		float out = Theme.easeOut(Math.min(1f, (SHOW_MS / 1000f - age) / 0.25f));
		float a = Math.min(in, out);
		int w = Math.max(font.width(current.title), font.width(current.text)) + 24;
		int h = 30;
		int x = g.guiWidth() - w - 6 + Math.round((1 - a) * 24), y = 6;
		Theme.rounded(g, x, y, x + w, y + h, Theme.withAlpha(Theme.PANEL, a));
		g.fill(x, y + 4, x + 2, y + h - 4, Theme.withAlpha(Theme.accent(), a));
		if (a < 0.12f) return;
		g.text(font, current.title, x + 10, y + 6, Theme.withAlpha(Theme.accent(), a), false);
		g.text(font, current.text, x + 10, y + 17, Theme.withAlpha(Theme.TEXT, a), false);
	}
}
