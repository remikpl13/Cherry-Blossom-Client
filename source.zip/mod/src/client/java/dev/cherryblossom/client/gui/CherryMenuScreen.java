package dev.cherryblossom.client.gui;

import dev.cherryblossom.client.compat.Compat;
import com.mojang.blaze3d.platform.InputConstants;
import dev.cherryblossom.client.CherryBlossomClient;
import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.hud.HudWidget;
import dev.cherryblossom.client.hud.Widgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** The Right Shift menu: a grid of HUD widgets, a few features, and the look. */
public final class CherryMenuScreen extends Screen {
	private enum Tab { HUD("HUD"), FEATURES("Features"), LOOK("Look"), FRIENDS("Friends");
		final String label;
		Tab(String label) { this.label = label; }
	}

	private static final int HEADER_H = 30;
	private static final int TILE_H = 26;
	private static final int TILE_GAP = 4;
	private static final int ROW_H = 17;
	private static final int PAD = 10;
	private static final int FOOTER_H = 36;

	private final Screen parent;
	private final long openedAt = System.nanoTime();
	private long lastFrame = System.nanoTime();
	private Tab tab = Tab.HUD;
	private float tabFade = 1f;
	private final float[] tabHover = new float[Tab.values().length];
	private final float[] tileHover = new float[Widgets.ALL.size()];
	private final float[] tileOn = new float[Widgets.ALL.size()];
	private final List<Row> features = new ArrayList<>();
	private final List<Row> look = new ArrayList<>();
	private float buttonHover;
	private boolean buttonHovered;

	/** A setting line: a toggle or a value you click to cycle. */
	private static final class Row {
		final String label;
		final Supplier<Boolean> get;
		final Consumer<Boolean> set;
		final Supplier<String> chip;
		final Runnable cycle;
		float hover, knob;

		Row(String label, Supplier<Boolean> get, Consumer<Boolean> set, Supplier<String> chip, Runnable cycle) {
			this.label = label;
			this.get = get;
			this.set = set;
			this.chip = chip;
			this.cycle = cycle;
			this.knob = get != null && get.get() ? 1f : 0f;
		}

		static Row toggle(String label, Supplier<Boolean> get, Consumer<Boolean> set) { return new Row(label, get, set, null, null); }

		static Row cycle(String label, Supplier<String> chip, Runnable cycle) { return new Row(label, null, null, chip, cycle); }
	}

	public CherryMenuScreen(Screen parent) {
		super(Component.literal("Cherry Blossom Client"));
		this.parent = parent;
		CherryConfig cfg = CherryConfig.get();
		var mc = net.minecraft.client.Minecraft.getInstance();

		features.add(Row.toggle("Toggle sprint", () -> mc.options.toggleSprint().get(), v -> { mc.options.toggleSprint().set(v); mc.options.save(); }));
		features.add(Row.toggle("Zoom: steady camera", () -> cfg.zoomSmoothCamera, v -> cfg.zoomSmoothCamera = v));
		features.add(Row.toggle("Zoom: scroll to adjust", () -> cfg.zoomScroll, v -> cfg.zoomScroll = v));
		features.add(Row.cycle("Zoom strength", () -> Math.round(cfg.zoomFactor) + "x", () -> {
			float[] steps = {2f, 3f, 4f, 6f, 8f};
			int i = 0;
			while (i < steps.length && steps[i] <= cfg.zoomFactor + 0.01f) i++;
			cfg.zoomFactor = steps[i % steps.length];
		}));
		features.add(Row.toggle("Hide vanilla effect icons", () -> cfg.hideVanillaEffects, v -> cfg.hideVanillaEffects = v));
		features.add(Row.toggle("24-hour clock", () -> cfg.clock24h, v -> cfg.clock24h = v));

		look.add(Row.toggle("Widget background", () -> cfg.background, v -> cfg.background = v));
		look.add(Row.toggle("Text shadow", () -> cfg.textShadow, v -> cfg.textShadow = v));
		look.add(Row.toggle("Colour-coded values", () -> cfg.colorCodedValues, v -> cfg.colorCodedValues = v));
		look.add(Row.toggle("Cherry title screen", () -> cfg.cherryTitleScreen, v -> cfg.cherryTitleScreen = v));
		look.add(Row.cycle("Accent colour", () -> cfg.accent.label, () -> cfg.accent = cfg.accent.next()));

		for (int i = 0; i < Widgets.ALL.size(); i++) tileOn[i] = Widgets.ALL.get(i).state().enabled ? 1f : 0f;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		g.fill(0, 0, width, height, Theme.withAlpha(0x660E080B, appear()));
	}

	private float appear() {
		return Theme.easeOut((System.nanoTime() - openedAt) / 1_000_000_000f / 0.22f);
	}

	// ---- layout ----

	private int panelW() { return Math.min(352, width - 16); }

	private int columns() { return panelW() >= 320 ? 4 : 3; }

	private int tileW() { return (panelW() - PAD * 2 - TILE_GAP * (columns() - 1)) / columns(); }

	private int bodyH() {
		int rows = (Widgets.ALL.size() + columns() - 1) / columns();
		int grid = rows * TILE_H + (rows - 1) * TILE_GAP;
		return Math.max(grid, Math.max(features.size(), look.size()) * ROW_H);
	}

	private int panelH() { return HEADER_H + bodyH() + FOOTER_H; }

	private int panelX() { return (width - panelW()) / 2; }

	private int panelY() { return (height - panelH()) / 2 + Math.round((1 - appear()) * 10); }

	private int tabX(int i) {
		int x = panelX() + panelW() - PAD;
		for (int k = Tab.values().length - 1; k >= i; k--) x -= font.width(Tab.values()[k].label) + 12 + (k > i ? 4 : 0);
		return x;
	}

	// ---- drawing ----

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
		lastFrame = now;
		tabFade = Math.min(1f, tabFade + dt / 0.15f);

		float a = appear();
		int px = panelX(), py = panelY(), pw = panelW(), ph = panelH();
		int accent = Theme.accent();

		Theme.rounded(g, px, py, px + pw, py + ph, Theme.withAlpha(Theme.PANEL, a));
		g.fill(px + 1, py, px + pw - 1, py + 2, Theme.withAlpha(accent, a));

		drawBlossom(g, px + PAD + 4, py + 15, Theme.withAlpha(accent, a));
		g.text(font, "Cherry Blossom", px + PAD + 14, py + 11, Theme.withAlpha(Theme.TEXT, a), false);
		if (pw > 300) g.text(font, "Client", px + PAD + 14 + font.width("Cherry Blossom "), py + 11, Theme.withAlpha(accent, a), false);

		for (int i = 0; i < Tab.values().length; i++) {
			Tab t = Tab.values()[i];
			int tx = tabX(i), tw = font.width(t.label) + 12, ty = py + 8;
			boolean hov = mouseX >= tx && mouseX < tx + tw && mouseY >= ty && mouseY < ty + 15;
			tabHover[i] = Theme.approach(tabHover[i], hov ? 1f : 0f, 20f, dt);
			boolean sel = t == tab;
			int fill = sel ? accent : Theme.mix(Theme.PANEL_RAISED, Theme.PANEL_HOVER, tabHover[i]);
			Theme.rounded(g, tx, ty, tx + tw, ty + 15, Theme.withAlpha(fill, a));
			g.text(font, t.label, tx + 6, ty + 4, Theme.withAlpha(sel ? 0xFF2A1520 : Theme.TEXT, a), false);
		}

		int by = py + HEADER_H;
		float ba = a * Theme.easeOut(tabFade);
		switch (tab) {
			case HUD -> drawTiles(g, px + PAD, by, mouseX, mouseY, ba, accent, dt);
			case FEATURES -> drawRows(g, features, px + PAD, by, pw - PAD * 2, mouseX, mouseY, ba, accent, dt);
			case LOOK -> drawRows(g, look, px + PAD, by, pw - PAD * 2, mouseX, mouseY, ba, accent, dt);
		}

		int bx = px + PAD, bty = by + bodyH() + 9, bw = pw - PAD * 2, bh = 18;
		buttonHovered = mouseX >= bx && mouseX < bx + bw && mouseY >= bty && mouseY < bty + bh;
		buttonHover = Theme.approach(buttonHover, buttonHovered ? 1f : 0f, 18f, dt);
		int fill = Theme.mix(Theme.mix(Theme.PANEL_RAISED, accent, 0.85f), accent, buttonHover);
		Theme.rounded(g, bx, bty, bx + bw, bty + bh, Theme.withAlpha(fill, a));
		g.centeredText(font, "Edit HUD Layout", px + pw / 2, bty + 5, Theme.withAlpha(0xFF2A1520, a));

		super.extractRenderState(g, mouseX, mouseY, delta);
	}

	private void drawTiles(GuiGraphicsExtractor g, int x0, int y0, int mouseX, int mouseY, float a, int accent, float dt) {
		int cols = columns(), tw = tileW();
		for (int i = 0; i < Widgets.ALL.size(); i++) {
			HudWidget w = Widgets.ALL.get(i);
			int tx = x0 + (i % cols) * (tw + TILE_GAP), ty = y0 + (i / cols) * (TILE_H + TILE_GAP);
			boolean hov = mouseX >= tx && mouseX < tx + tw && mouseY >= ty && mouseY < ty + TILE_H;
			tileHover[i] = Theme.approach(tileHover[i], hov ? 1f : 0f, 20f, dt);
			boolean on = w.state().enabled;
			tileOn[i] = Theme.approach(tileOn[i], on ? 1f : 0f, 16f, dt);

			int base = Theme.mix(Theme.PANEL_RAISED, Theme.PANEL_HOVER, tileHover[i]);
			Theme.rounded(g, tx, ty, tx + tw, ty + TILE_H, Theme.withAlpha(base, a));
			// a soft accent bar that grows when the widget is on
			int barH = Math.round((TILE_H - 8) * tileOn[i]);
			if (barH > 0) g.fill(tx + 2, ty + (TILE_H - barH) / 2, tx + 4, ty + (TILE_H + barH) / 2, Theme.withAlpha(accent, a));

			String name = w.name;
			while (font.width(name) > tw - 12 && name.length() > 3) name = name.substring(0, name.length() - 1);
			if (!name.equals(w.name)) name = name.substring(0, name.length() - 1) + "…";
			g.text(font, name, tx + 8, ty + 5, Theme.withAlpha(Theme.TEXT, a), false);
			String status = on ? "On" : "Off";
			g.text(font, status, tx + 8, ty + 15, Theme.withAlpha(Theme.mix(Theme.TEXT_DIM, accent, tileOn[i]), a), false);
			if (hov) {
				g.setTooltipForNextFrame(font, Component.literal(w.about), mouseX, mouseY);
			}
		}
	}

	private void drawRows(GuiGraphicsExtractor g, List<Row> rows, int x, int y, int w, int mouseX, int mouseY, float a, int accent, float dt) {
		for (Row r : rows) {
			boolean hov = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + ROW_H;
			r.hover = Theme.approach(r.hover, hov ? 1f : 0f, 20f, dt);
			if (r.hover > 0.01f) Theme.rounded(g, x - 2, y, x + w + 2, y + ROW_H, Theme.withAlpha(Theme.PANEL_HOVER, r.hover * a));
			g.text(font, r.label, x + 2, y + 5, Theme.withAlpha(Theme.TEXT, a), false);
			if (r.get != null) {
				r.knob = Theme.approach(r.knob, r.get.get() ? 1f : 0f, 16f, dt);
				int tx = x + w - 18, ty = y + 4;
				Theme.rounded(g, tx, ty, tx + 18, ty + 9, Theme.withAlpha(Theme.mix(0xFF4A3540, accent, r.knob), a));
				int kx = tx + 1 + Math.round(r.knob * 9);
				Theme.rounded(g, kx, ty + 1, kx + 7, ty + 8, Theme.withAlpha(0xFFFFF6F9, a));
			} else if (r.chip != null) {
				String chip = r.chip.get();
				int cw = font.width(chip) + 12, cx = x + w - cw;
				Theme.rounded(g, cx, y + 2, cx + cw, y + ROW_H - 2, Theme.withAlpha(Theme.PANEL_RAISED, a));
				g.fill(cx + 4, y + 7, cx + 7, y + 10, Theme.withAlpha(accent, a));
				g.text(font, chip, cx + 9, y + 5, Theme.withAlpha(Theme.TEXT, a), false);
			}
			y += ROW_H;
		}
		if (rows == features) {
			String hint = "Zoom: hold C (rebind in Controls)";
			g.text(font, hint, x + 2, y + 6, Theme.withAlpha(Theme.TEXT_DIM, a * 0.8f), false);
		}
	}

	/** Five tiny petals around a centre: a pixel-sized blossom, no texture needed. */
	private static void drawBlossom(GuiGraphicsExtractor g, int cx, int cy, int color) {
		int[][] petals = {{0, -4}, {4, -1}, {2, 3}, {-2, 3}, {-4, -1}};
		for (int[] p : petals) g.fill(cx + p[0] - 1, cy + p[1] - 1, cx + p[0] + 2, cy + p[1] + 2, color);
		g.fill(cx, cy, cx + 1, cy + 1, 0xFFFFF3C4);
	}

	// ---- input ----

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		if (e.button() != InputConstants.MOUSE_BUTTON_LEFT) return super.mouseClicked(e, doubleClick);
		double mx = e.x(), my = e.y();
		int px = panelX(), py = panelY(), pw = panelW();

		for (int i = 0; i < Tab.values().length; i++) {
			int tx = tabX(i), tw = font.width(Tab.values()[i].label) + 12, ty = py + 8;
			if (mx >= tx && mx < tx + tw && my >= ty && my < ty + 15) {
				if (Tab.values()[i] == Tab.FRIENDS) { CherryConfig.get().save(); Compat.setScreen(minecraft, new FriendsScreen(this)); return true; }
				if (tab != Tab.values()[i]) { tab = Tab.values()[i]; tabFade = 0f; }
				return true;
			}
		}
		if (buttonHovered) {
			CherryConfig.get().save();
			Compat.setScreen(minecraft, new HudEditorScreen(this));
			return true;
		}
		int x0 = px + PAD, y0 = py + HEADER_H;
		if (tab == Tab.HUD) {
			int cols = columns(), tw = tileW();
			for (int i = 0; i < Widgets.ALL.size(); i++) {
				int tx = x0 + (i % cols) * (tw + TILE_GAP), ty = y0 + (i / cols) * (TILE_H + TILE_GAP);
				if (mx >= tx && mx < tx + tw && my >= ty && my < ty + TILE_H) {
					HudWidget w = Widgets.ALL.get(i);
					w.state().enabled = !w.state().enabled;
					CherryConfig.get().save();
					return true;
				}
			}
		} else {
			List<Row> rows = tab == Tab.FEATURES ? features : look;
			int y = y0, w = pw - PAD * 2;
			for (Row r : rows) {
				if (mx >= x0 && mx < x0 + w && my >= y && my < y + ROW_H) {
					if (r.set != null) r.set.accept(!r.get.get());
					if (r.cycle != null) r.cycle.run();
					CherryConfig.get().save();
					return true;
				}
				y += ROW_H;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		if (CherryBlossomClient.MENU_KEY.matches(e)) {
			onClose();
			return true;
		}
		return super.keyPressed(e);
	}

	@Override
	public void onClose() {
		CherryConfig.get().save();
		Compat.setScreen(minecraft, parent);
	}
}
