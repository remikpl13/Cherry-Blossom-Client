package dev.cherryblossom.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cherryblossom.client.CherryBlossomClient;
import dev.cherryblossom.client.compat.Compat;
import dev.cherryblossom.client.friends.FriendsLink;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Friends in game: add by name or code, answer requests, see who's online. Opened with U. */
public final class FriendsScreen extends Screen {
	private static final int PAD = 10, ROW = 22, HEADER = 30;

	private final Screen parent;
	private final long openedAt = System.nanoTime();
	private EditBox box;
	private int scroll;

	private record Button(int x, int y, int w, int h, Runnable run) {
		boolean hit(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
	}
	private final List<Button> buttons = new ArrayList<>();

	public FriendsScreen(Screen parent) {
		super(Component.literal("Friends"));
		this.parent = parent;
	}

	private int panelW() { return Math.min(300, width - 16); }
	private int panelH() { return Math.min(260, height - 16); }
	private int panelX() { return (width - panelW()) / 2; }
	private int panelY() { return (height - panelH()) / 2; }

	@Override
	protected void init() {
		String old = box == null ? "" : box.getValue();
		box = new EditBox(font, panelX() + PAD, panelY() + HEADER + 14, panelW() - PAD * 2 - 44, 16, Component.literal("Name or friend code"));
		box.setMaxLength(24);
		box.setValue(old);
		box.setHint(Component.literal("Player name or friend code"));
		addRenderableWidget(box);
	}

	@Override
	public boolean isPauseScreen() { return false; }

	private float appear() { return Theme.easeOut((System.nanoTime() - openedAt) / 1_000_000_000f / 0.2f); }

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		g.fill(0, 0, width, height, Theme.withAlpha(0x660E080B, appear()));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		buttons.clear();
		int px = panelX(), py = panelY(), pw = panelW(), ph = panelH();
		int accent = Theme.accent();
		Theme.rounded(g, px, py, px + pw, py + ph, Theme.PANEL);
		g.fill(px + 1, py, px + pw - 1, py + 2, accent);
		g.text(font, "Friends", px + PAD, py + 11, Theme.TEXT, false);

		if (!FriendsLink.available()) {
			g.text(font, "Start the game from the Cherry launcher", px + PAD, py + HEADER + 4, Theme.TEXT_DIM, false);
			g.text(font, "to use friends.", px + PAD, py + HEADER + 16, Theme.TEXT_DIM, false);
			box.visible = false;
			super.extractRenderState(g, mouseX, mouseY, delta);
			return;
		}
		String code = FriendsLink.connected ? "Your code: " + FriendsLink.code : "Connecting to the launcher…";
		g.text(font, code, px + pw - PAD - font.width(code), py + 11, Theme.TEXT_DIM, false);

		g.text(font, "Add a friend", px + PAD, py + HEADER + 2, Theme.TEXT_DIM, false);
		int bx = px + pw - PAD - 40, by = py + HEADER + 14;
		pill(g, bx, by, 40, 16, "Add", true, mouseX, mouseY, this::send);

		int y = py + HEADER + 36;
		if (!FriendsLink.lastResult.isEmpty()) {
			for (var line : font.split(Component.literal(FriendsLink.lastResult), pw - PAD * 2)) {
				g.text(font, line, px + PAD, y, Theme.TEXT_DIM, false);
				y += 10;
			}
			y += 4;
		}

		int bottom = py + ph - PAD;
		List<Runnable> rows = new ArrayList<>();
		for (FriendsLink.Request r : FriendsLink.incoming) {
			int ry = y;
			if (ry + ROW > bottom) break;
			row(g, px, ry, pw, 0xFFF3D98B, r.name(), "wants to be your friend");
			int rx = px + pw - PAD - 4;
			rx = pill(g, rx - 44, ry + 3, 44, 15, "Decline", false, mouseX, mouseY, () -> FriendsLink.send("decline", r.code()));
			pill(g, rx - 44, ry + 3, 40, 15, "Accept", true, mouseX, mouseY, () -> FriendsLink.send("accept", r.code()));
			y += ROW + 2;
		}
		if (FriendsLink.friends.isEmpty() && FriendsLink.incoming.isEmpty()) {
			g.text(font, "No friends yet. Share your code, or type", px + PAD, y + 4, Theme.TEXT_DIM, false);
			g.text(font, "a name above and press Enter.", px + PAD, y + 15, Theme.TEXT_DIM, false);
		}
		for (FriendsLink.Friend f : FriendsLink.friends) {
			if (y + ROW > bottom) break;
			row(g, px, y, pw, f.online() ? 0xFFA8E6C1 : 0xFF6E5A64, f.name(), f.activity());
			int fy = y;
			pill(g, px + pw - PAD - 4 - 44, fy + 3, 44, 15, "Remove", false, mouseX, mouseY, () -> FriendsLink.send("remove", f.code()));
			y += ROW + 2;
		}
		for (FriendsLink.Request r : FriendsLink.outgoing) {
			if (y + ROW > bottom) break;
			row(g, px, y, pw, 0xFF6E5A64, r.name(), "request sent");
			y += ROW + 2;
		}
		super.extractRenderState(g, mouseX, mouseY, delta);
	}

	private void row(GuiGraphicsExtractor g, int px, int y, int pw, int dot, String name, String sub) {
		Theme.rounded(g, px + PAD, y, px + pw - PAD, y + ROW, Theme.PANEL_RAISED);
		g.fill(px + PAD + 6, y + 9, px + PAD + 10, y + 13, dot);
		g.text(font, name, px + PAD + 15, y + 3, Theme.TEXT, false);
		String s = sub;
		int max = pw - PAD * 2 - 70 - 15;
		while (font.width(s) > max && s.length() > 4) s = s.substring(0, s.length() - 2);
		if (!s.equals(sub)) s += "…";
		g.text(font, s, px + PAD + 15, y + 12, Theme.TEXT_DIM, false);
	}

	private int pill(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, boolean primary, int mx, int my, Runnable run) {
		boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
		int fill = primary ? (hov ? Theme.mix(Theme.accent(), 0xFFFFFFFF, 0.15f) : Theme.accent()) : (hov ? Theme.PANEL_HOVER : 0xFF3A2630);
		Theme.rounded(g, x, y, x + w, y + h, fill);
		g.centeredText(font, label, x + w / 2, y + (h - 8) / 2, primary ? 0xFF2A1520 : Theme.TEXT);
		buttons.add(new Button(x, y, w, h, run));
		return x;
	}

	private void send() {
		String q = box.getValue().trim();
		if (q.isEmpty()) return;
		FriendsLink.lastResult = "Sending…";
		FriendsLink.send("add", q);
		box.setValue("");
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		if (e.button() == InputConstants.MOUSE_BUTTON_LEFT) {
			for (Button b : new ArrayList<>(buttons)) if (b.hit(e.x(), e.y())) { b.run.run(); return true; }
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		if (box.isFocused() && (e.key() == InputConstants.KEY_RETURN || e.key() == InputConstants.KEY_NUMPADENTER)) { send(); return true; }
		if (!box.isFocused() && CherryBlossomClient.FRIENDS_KEY.matches(e)) { onClose(); return true; }
		return super.keyPressed(e);
	}

	@Override
	public void onClose() {
		Compat.setScreen(minecraft, parent);
	}
}
