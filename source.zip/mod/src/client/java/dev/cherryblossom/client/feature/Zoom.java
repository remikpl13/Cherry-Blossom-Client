package dev.cherryblossom.client.feature;

import dev.cherryblossom.client.compat.Compat;
import dev.cherryblossom.client.config.CherryConfig;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/**
 * Hold the zoom key (C by default) to zoom in. Scroll while zooming to adjust.
 * Uses vanilla's cinematic camera while zoomed, like OptiFine, so aiming stays steady.
 */
public final class Zoom {
	private Zoom() {}

	private static KeyMapping key;
	private static boolean active;
	private static float current = 1f;
	private static float target = 1f;
	private static float scrollFactor;
	private static boolean savedSmooth;
	private static long last = System.nanoTime();

	public static void init(KeyMapping k) {
		key = k;
	}

	public static void tick(Minecraft mc) {
		boolean down = key != null && key.isDown() && Compat.screen(mc) == null;
		if (down && !active) {
			active = true;
			scrollFactor = CherryConfig.get().zoomFactor;
			savedSmooth = mc.options.smoothCamera;
			if (CherryConfig.get().zoomSmoothCamera) mc.options.smoothCamera = true;
		} else if (!down && active) {
			active = false;
			mc.options.smoothCamera = savedSmooth;
		}
		target = active ? scrollFactor : 1f;
	}

	public static boolean active() {
		return active;
	}

	/** Called from the scroll mixin. Returns true if the scroll was used for zooming. */
	public static boolean scroll(double amount) {
		if (!active || !CherryConfig.get().zoomScroll || amount == 0) return false;
		scrollFactor = Math.max(1.5f, Math.min(30f, scrollFactor * (amount > 0 ? 1.25f : 0.8f)));
		return true;
	}

	/** Divides the field of view; eased so zooming in and out feels smooth. */
	public static float apply(float fov) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - last) / 1e9f);
		last = now;
		current += (target - current) * (1f - (float) Math.exp(-14f * dt));
		if (Math.abs(current - target) < 0.001f) current = target;
		return current == 1f ? fov : fov / current;
	}
}
