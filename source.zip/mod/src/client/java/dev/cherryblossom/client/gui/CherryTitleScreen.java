package dev.cherryblossom.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.cherryblossom.client.compat.Compat;
import net.minecraft.SharedConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.options.LanguageSelectScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Cherry's own title screen: the vanilla panorama, a pixel blossom, a column of soft dark buttons
 * and a small icon bar. Everything eases in when it opens and reacts smoothly to the mouse.
 */
public final class CherryTitleScreen extends Screen {
	private static final int BTN_W = 204, BTN_H = 20, GAP = 4;

	// 7x7 pixel icons, '#' = filled.
	private static final String[] ICON_PLAYER = {"..###..", "..###..", "..###..", ".......", ".#####.", "#######", "#######"};
	private static final String[] ICON_PLAYERS = {".##..##", ".##..##", ".......", "###.###", "###.###", "#######", "......."};
	private static final String[] ICON_GEAR = {"..#.#..", ".#####.", "##...##", ".#...#.", "##...##", ".#####.", "..#.#.."};
	private static final String[] ICON_POWER = {"...#...", ".#.#.#.", "#..#..#", "#.....#", "#.....#", ".#...#.", "..###.."};
	private static final String[] ICON_PETAL = {"..#.#..", ".##.##.", "###.###", "...#...", "###.###", ".##.##.", "..#.#.."};
	private static final String[] ICON_LAYOUT = {"###.###", "###.###", ".......", "###.###", "###.###", ".......", "#######"};
	private static final String[] ICON_CLOUD = {".......", "..###..", ".#####.", "#######", "#######", ".......", "......."};
	private static final String[] ICON_GLOBE = {"..###..", ".#.#.#.", "#######", "#..#..#", "#######", ".#.#.#.", "..###.."};
	private static final String[] ICON_ACCESS = {"..##...", "..##...", "#######", "..##...", "..##...", ".#..#..", "#....#."};
	private static final String[] LOGO = {
			"......##.##......",
			".....###.###.....",
			".....###.###.....",
			"......##.##......",
			".##....#.#....##.",
			"####....#....####",
			"#####..ooo..#####",
			".####.ooooo.####.",
			"......ooooo......",
			".####.ooooo.####.",
			"#####..ooo..#####",
			"####....#....####",
			".##....#.#....##.",
			"......##.##......",
			".....###.###.....",
			".....###.###.....",
			"......##.##......"};

	private final long openedAt = System.nanoTime();
	private long lastFrame = System.nanoTime();
	private final List<Btn> buttons = new ArrayList<>();
	private final List<Btn> bar = new ArrayList<>();

	/** One button: a big text button or a small icon in the bottom bar. */
	private static final class Btn {
		final String label;
		final String[] icon;
		final Runnable action;
		final boolean accent;
		int x, y, w, h;
		float hover, press, delay;
		boolean pressed;

		Btn(String label, String[] icon, boolean accent, float delay, Runnable action) {
			this.label = label;
			this.icon = icon;
			this.accent = accent;
			this.delay = delay;
			this.action = action;
		}

		boolean over(double mx, double my) {
			return mx >= x && mx < x + w && my >= y && my < y + h;
		}
	}

	public CherryTitleScreen() {
		super(Component.literal("Cherry Blossom Client"));
	}

	@Override
	protected void init() {
		buttons.clear();
		bar.clear();
		buttons.add(new Btn("Singleplayer", ICON_PLAYER, false, 0.10f, () -> Compat.setScreen(minecraft, new SelectWorldScreen(this))));
		buttons.add(new Btn("Multiplayer", ICON_PLAYERS, false, 0.16f, () -> Compat.setScreen(minecraft, new JoinMultiplayerScreen(this))));
		buttons.add(new Btn("Options", ICON_GEAR, false, 0.22f, () -> Compat.setScreen(minecraft, Compat.optionsScreen(this, minecraft))));
		buttons.add(new Btn("Quit", ICON_POWER, true, 0.25f, minecraft::stop));

		bar.add(new Btn("Cherry menu", ICON_PETAL, true, 0.30f, () -> Compat.setScreen(minecraft, new CherryMenuScreen(this))));
		bar.add(new Btn("Edit HUD layout", ICON_LAYOUT, false, 0.33f, () -> Compat.setScreen(minecraft, new HudEditorScreen(this))));
		bar.add(new Btn("Realms", ICON_CLOUD, false, 0.36f, () -> Compat.setScreen(minecraft, new com.mojang.realmsclient.RealmsMainScreen(this))));
		bar.add(new Btn("Language", ICON_GLOBE, false, 0.39f, () -> Compat.setScreen(minecraft, new LanguageSelectScreen(this, minecraft.options, minecraft.getLanguageManager()))));
		bar.add(new Btn("Accessibility", ICON_ACCESS, false, 0.42f, () -> Compat.setScreen(minecraft, new AccessibilityOptionsScreen(this, minecraft.options))));
		layout();
	}

	private int logoScale() {
		return height < 260 ? 2 : 3;
	}

	private void layout() {
		int cx = width / 2;
		int logoH = LOGO.length * logoScale();
		int blockH = logoH + 18 + 12 + BTN_H * 3 + GAP * 2;
		int top = Math.max(20, (height - blockH) / 2 - 10);
		int y = top + logoH + 30;
		for (int i = 0; i < 2; i++) {
			Btn b = buttons.get(i);
			b.x = cx - BTN_W / 2;
			b.y = y;
			b.w = BTN_W;
			b.h = BTN_H;
			y += BTN_H + GAP;
		}
		int half = (BTN_W - GAP) / 2;
		Btn opt = buttons.get(2), quit = buttons.get(3);
		opt.x = cx - BTN_W / 2; opt.y = y; opt.w = half; opt.h = BTN_H;
		quit.x = cx - BTN_W / 2 + half + GAP; quit.y = y; quit.w = BTN_W - half - GAP; quit.h = BTN_H;

		int s = 18, bw = bar.size() * s + (bar.size() - 1) * 3;
		int bx = cx - bw / 2, by = height - s - 14;
		for (Btn b : bar) {
			b.x = bx; b.y = by; b.w = s; b.h = s;
			bx += s + 3;
		}
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private float seconds() {
		return (System.nanoTime() - openedAt) / 1e9f;
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		extractPanorama(g, delta);
		// soft plum vignette so the buttons read well over any panorama
		g.fillGradient(0, 0, width, height / 3, 0x55100810, 0x00100810);
		g.fillGradient(0, height * 2 / 3, width, height, 0x00100810, 0x88100810);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - lastFrame) / 1e9f);
		lastFrame = now;
		float t = seconds();
		int accent = Theme.accent();

		// logo: fades and settles in, then floats gently
		float la = Theme.easeOut(t / 0.6f);
		int sc = logoScale();
		int lw = LOGO[0].length() * sc;
		int lx = width / 2 - lw / 2;
		int ly = buttons.get(0).y - 30 - LOGO.length * sc + Math.round((1 - la) * 10 + (float) Math.sin(t * 1.6) * 1.5f);
		for (int r = 0; r < LOGO.length; r++) {
			for (int c = 0; c < LOGO[r].length(); c++) {
				char ch = LOGO[r].charAt(c);
				if (ch == '.') continue;
				int col = ch == 'o' ? 0xFFFFF1C9 : Theme.mix(0xFFFFE3EC, accent, r / (float) LOGO.length * 0.6f + 0.4f);
				g.fill(lx + c * sc, ly + r * sc, lx + (c + 1) * sc, ly + (r + 1) * sc, Theme.withAlpha(col, la));
			}
		}
		String name = "Cherry Blossom";
		int ty = ly + LOGO.length * sc + 7;
		g.centeredText(font, name, width / 2, ty, Theme.withAlpha(Theme.TEXT, la));

		for (Btn b : buttons) drawButton(g, b, mouseX, mouseY, t, dt, accent);
		for (Btn b : bar) drawIcon(g, b, mouseX, mouseY, t, dt, accent);

		// account chip, top left
		float ca = Theme.easeOut((t - 0.2f) / 0.5f);
		String user = minecraft.getUser().getName();
		int cw = font.width(user) + 22;
		int cy = 8 - Math.round((1 - ca) * 6);
		Theme.rounded(g, 8, cy, 8 + cw, cy + 16, Theme.withAlpha(0xC01A0F15, ca));
		g.fill(11, cy + 3, 21, cy + 13, Theme.withAlpha(accent, ca));
		g.text(font, user.substring(0, 1).toUpperCase(), 14, cy + 4, Theme.withAlpha(0xFF2A1520, ca), false);
		g.text(font, user, 25, cy + 4, Theme.withAlpha(Theme.TEXT, ca), false);

		// corner notes
		float na = Theme.easeOut((t - 0.4f) / 0.6f);
		g.text(font, "Cherry Blossom Client " + SharedConstants.getCurrentVersion().name(), 4, height - 12, Theme.withAlpha(Theme.TEXT_DIM, na * 0.8f), true);
		String legal = "Not affiliated with Mojang or Microsoft";
		g.text(font, legal, width - font.width(legal) - 4, height - 12, Theme.withAlpha(Theme.TEXT_DIM, na * 0.6f), true);

		// tooltip for the icon bar
		for (Btn b : bar) if (b.over(mouseX, mouseY)) g.setTooltipForNextFrame(font, Component.literal(b.label), mouseX, mouseY);

		// fade in from black on first open
		float fade = 1f - Theme.easeOut(t / 0.45f);
		if (fade > 0.01f) g.fill(0, 0, width, height, Theme.withAlpha(0xFF0E080B, fade));
		super.extractRenderState(g, mouseX, mouseY, delta);
	}

	private void step(Btn b, int mouseX, int mouseY, float dt) {
		b.hover = Theme.approach(b.hover, b.over(mouseX, mouseY) ? 1f : 0f, 16f, dt);
		b.press = Theme.approach(b.press, b.pressed ? 1f : 0f, 30f, dt);
	}

	private void drawButton(GuiGraphicsExtractor g, Btn b, int mouseX, int mouseY, float t, float dt, int accent) {
		step(b, mouseX, mouseY, dt);
		float in = Theme.easeOut((t - b.delay) / 0.45f);
		if (in <= 0) return;
		int y = b.y + Math.round((1 - in) * 12);
		float h = b.hover;
		int base = b.accent ? Theme.mix(0xD0201218, Theme.withAlpha(accent, 0.85f), 0.35f + 0.65f * h) : Theme.mix(0xC81A0F15, 0xE82C1A23, h);
		base = Theme.mix(base, 0xFF120A0E, b.press * 0.4f);
		Theme.rounded(g, b.x, y, b.x + b.w, y + b.h, Theme.withAlpha(base, in));
		// a hairline of accent that brightens on hover
		g.fill(b.x + 2, y + b.h - 1, b.x + b.w - 2, y + b.h, Theme.withAlpha(accent, in * (0.15f + 0.6f * h)));
		// accent bar on the left grows with hover
		int barH = Math.round((b.h - 8) * h);
		if (barH > 0 && !b.accent) g.fill(b.x + 2, y + (b.h - barH) / 2, b.x + 4, y + (b.h + barH) / 2, Theme.withAlpha(accent, in));

		int textColor = b.accent ? Theme.mix(Theme.TEXT, 0xFF2A1520, h) : Theme.mix(0xFFE9DDE3, 0xFFFFFFFF, h);
		int tw = font.width(b.label) + 11;
		int tx = b.x + (b.w - tw) / 2 + Math.round(h * 1.5f);
		icon(g, b.icon, tx, y + (b.h - 7) / 2, 1, Theme.withAlpha(b.accent ? textColor : Theme.mix(accent, 0xFFFFFFFF, h * 0.3f), in));
		g.text(font, b.label, tx + 11, y + (b.h - 8) / 2 + 1, Theme.withAlpha(textColor, in), false);
	}

	private void drawIcon(GuiGraphicsExtractor g, Btn b, int mouseX, int mouseY, float t, float dt, int accent) {
		step(b, mouseX, mouseY, dt);
		float in = Theme.easeOut((t - b.delay) / 0.45f);
		if (in <= 0) return;
		float h = b.hover;
		int lift = Math.round(h * 2 + (1 - in) * 10);
		int y = b.y - lift;
		int base = b.accent ? Theme.mix(0xC8201218, Theme.withAlpha(accent, 0.9f), 0.3f + 0.7f * h) : Theme.mix(0xC81A0F15, 0xE82C1A23, h);
		Theme.rounded(g, b.x, y, b.x + b.w, y + b.h, Theme.withAlpha(base, in));
		int col = b.accent ? Theme.mix(accent, 0xFF2A1520, h) : Theme.mix(0xFFD9C8D0, accent, h);
		icon(g, b.icon, b.x + (b.w - 7) / 2, y + (b.h - 7) / 2, 1, Theme.withAlpha(col, in));
		if (b.accent) g.fill(b.x + b.w / 2 - 1, y + b.h + 2, b.x + b.w / 2 + 1, y + b.h + 3, Theme.withAlpha(accent, in * 0.8f));
	}

	private static void icon(GuiGraphicsExtractor g, String[] bitmap, int x, int y, int s, int color) {
		for (int r = 0; r < bitmap.length; r++) {
			for (int c = 0; c < bitmap[r].length(); c++) {
				if (bitmap[r].charAt(c) == '#') g.fill(x + c * s, y + r * s, x + (c + 1) * s, y + (r + 1) * s, color);
			}
		}
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		if (e.button() == InputConstants.MOUSE_BUTTON_LEFT) {
			for (Btn b : all()) if (b.over(e.x(), e.y())) { b.pressed = true; return true; }
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent e) {
		if (e.button() == InputConstants.MOUSE_BUTTON_LEFT) {
			for (Btn b : all()) {
				boolean fire = b.pressed && b.over(e.x(), e.y());
				b.pressed = false;
				if (fire) {
					minecraft.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
							net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.0f));
					b.action.run();
					return true;
				}
			}
		}
		return super.mouseReleased(e);
	}

	private List<Btn> all() {
		List<Btn> l = new ArrayList<>(buttons);
		l.addAll(bar);
		return l;
	}
}
