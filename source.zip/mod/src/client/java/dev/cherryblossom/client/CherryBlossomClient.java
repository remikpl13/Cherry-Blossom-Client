package dev.cherryblossom.client;

import dev.cherryblossom.client.compat.Compat;
import com.mojang.blaze3d.platform.InputConstants;
import dev.cherryblossom.CherryBlossom;
import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.feature.Zoom;
import dev.cherryblossom.client.gui.CherryMenuScreen;
import dev.cherryblossom.client.gui.CherryTitleScreen;
import dev.cherryblossom.client.gui.Theme;
import dev.cherryblossom.client.hud.HudRenderer;
import dev.cherryblossom.client.hud.Stats;
import dev.cherryblossom.client.hud.Widgets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;

public final class CherryBlossomClient implements ClientModInitializer {
	private static final KeyMapping.Category CATEGORY =
			KeyMapping.Category.register(Identifier.fromNamespaceAndPath(CherryBlossom.MOD_ID, "main"));

	public static final KeyMapping MENU_KEY = new KeyMapping("key.cherryblossom.menu", InputConstants.KEY_RSHIFT, CATEGORY);
	public static final KeyMapping ZOOM_KEY = new KeyMapping("key.cherryblossom.zoom", InputConstants.KEY_C, CATEGORY);
	public static final KeyMapping FRIENDS_KEY = new KeyMapping("key.cherryblossom.friends", InputConstants.KEY_U, CATEGORY);

	@Override
	public void onInitializeClient() {
		CherryConfig.load();
		KeyMappingHelper.registerKeyMapping(MENU_KEY);
		KeyMappingHelper.registerKeyMapping(ZOOM_KEY);
		KeyMappingHelper.registerKeyMapping(FRIENDS_KEY);
		dev.cherryblossom.client.friends.FriendsLink.start();
		// Friends see which server you're on.
		net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			var data = client.getCurrentServer();
			dev.cherryblossom.client.friends.FriendsLink.reportServer(data == null || data.isLan() ? "singleplayer" : data.ip);
		});
		net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
				dev.cherryblossom.client.friends.FriendsLink.reportServer(""));
		Zoom.init(ZOOM_KEY);

		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(CherryBlossom.MOD_ID, "hud"), HudRenderer::render);

		// Our Potion Effects widget replaces the vanilla icons in the corner (unless you turn it off).
		HudElementRegistry.replaceElement(VanillaHudElements.MOB_EFFECTS, vanilla -> (g, delta) -> {
			CherryConfig cfg = CherryConfig.get();
			if (cfg.hideVanillaEffects && Widgets.POTIONS.state().enabled) return;
			vanilla.extractRenderState(g, delta);
		});

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			Stats.tick(mc);
			Zoom.tick(mc);
			while (FRIENDS_KEY.consumeClick()) {
				if (Compat.screen(mc) == null) Compat.setScreen(mc, new dev.cherryblossom.client.gui.FriendsScreen(null));
			}
			while (MENU_KEY.consumeClick()) {
				if (Compat.screen(mc) == null) Compat.setScreen(mc, new CherryMenuScreen(null));
			}
		});

		// Swap the vanilla title screen for Cherry's (can be turned off in the Look tab).
		ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
			// friend pop-ups show on menus too
			ScreenEvents.afterExtract(screen).register((s, g, mx, my, delta) -> dev.cherryblossom.client.friends.FriendToasts.render(g));
			if (screen.getClass() != TitleScreen.class) return;
			if (CherryConfig.get().cherryTitleScreen) {
				mc.execute(() -> { if (Compat.screen(mc) == screen) Compat.setScreen(mc, new CherryTitleScreen()); });
			} else {
				ScreenEvents.afterExtract(screen).register((s, g, mx, my, delta) ->
						g.text(mc.font, "Cherry Blossom Client", 4, 4, Theme.accent(), true));
			}
		});
	}
}
