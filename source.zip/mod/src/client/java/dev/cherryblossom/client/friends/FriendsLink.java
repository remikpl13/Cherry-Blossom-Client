package dev.cherryblossom.client.friends;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Talks to the Cherry launcher, which runs the friends list. The launcher passes
 * -Dcherry.friends=port:token; without it (game started some other way) friends are simply off.
 */
public final class FriendsLink {
	public record Friend(String code, String name, boolean online, String activity, String server) {}
	public record Request(String code, String name) {}

	private static volatile OutputStream out;
	public static volatile boolean connected;
	public static volatile String code = "";
	public static volatile List<Friend> friends = List.of();
	public static volatile List<Request> incoming = List.of();
	public static volatile List<Request> outgoing = List.of();
	public static volatile String lastResult = "";
	private static volatile String pendingServer;

	private FriendsLink() {}

	public static boolean available() {
		return System.getProperty("cherry.friends") != null;
	}

	public static void start() {
		String spec = System.getProperty("cherry.friends");
		if (spec == null || !spec.contains(":")) return;
		int port = Integer.parseInt(spec.substring(0, spec.indexOf(':')));
		String token = spec.substring(spec.indexOf(':') + 1);
		Thread t = new Thread(() -> {
			while (true) {
				try (Socket s = new Socket(InetAddress.getLoopbackAddress(), port)) {
					out = s.getOutputStream();
					write(token);
					connected = true;
					if (pendingServer != null) send("server", pendingServer);
					BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
					String line;
					while ((line = in.readLine()) != null) handle(JsonParser.parseString(line).getAsJsonObject());
				} catch (Exception ignored) {
				}
				connected = false;
				out = null;
				try { Thread.sleep(5000); } catch (InterruptedException e) { return; }
			}
		}, "cherry-friends-link");
		t.setDaemon(true);
		t.start();
	}

	private static void handle(JsonObject m) {
		String type = str(m, "type");
		switch (type) {
			case "state" -> {
				code = str(m, "code");
				List<Friend> fl = new ArrayList<>();
				for (JsonElement e : arr(m, "friends")) {
					JsonObject f = e.getAsJsonObject();
					fl.add(new Friend(str(f, "code"), str(f, "name"), f.has("online") && f.get("online").getAsBoolean(), str(f, "activity"), str(f, "server")));
				}
				friends = fl;
				incoming = reqs(arr(m, "incoming"));
				outgoing = reqs(arr(m, "outgoing"));
			}
			case "toast" -> FriendToasts.show(str(m, "title"), str(m, "text"));
			case "result" -> lastResult = str(m, "text");
			default -> {}
		}
	}

	public static void send(String cmd, String arg) {
		JsonObject o = new JsonObject();
		o.addProperty("cmd", cmd);
		o.addProperty("arg", arg == null ? "" : arg);
		try { write(o.toString()); } catch (Exception ignored) {}
	}

	/** The game tells friends which server you're on ("" = menus, "singleplayer"). */
	public static void reportServer(String server) {
		pendingServer = server;
		if (out != null) send("server", server);
	}

	private static synchronized void write(String line) throws Exception {
		OutputStream o = out;
		if (o == null) return;
		o.write((line + "\n").getBytes(StandardCharsets.UTF_8));
		o.flush();
	}

	private static List<Request> reqs(JsonArray a) {
		List<Request> out = new ArrayList<>();
		for (JsonElement e : a) out.add(new Request(str(e.getAsJsonObject(), "code"), str(e.getAsJsonObject(), "name")));
		return out;
	}

	private static String str(JsonObject o, String k) {
		return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
	}

	private static JsonArray arr(JsonObject o, String k) {
		return o.has(k) && o.get(k).isJsonArray() ? o.getAsJsonArray(k) : new JsonArray();
	}
}
