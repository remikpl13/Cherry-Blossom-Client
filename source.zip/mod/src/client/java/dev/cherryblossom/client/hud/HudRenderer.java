package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.compat.Compat;
import dev.cherryblossom.client.gui.HudEditorScreen;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Draws enabled widgets on the in-game HUD. */
public final class HudRenderer {
	private HudRenderer() {}

	public static void render(GuiGraphicsExtractor g, DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return;
		if (Compat.screen(mc) == null) dev.cherryblossom.client.friends.FriendToasts.render(g);
		if (Compat.screen(mc) instanceof HudEditorScreen) return; // the editor draws its own copies
		if (mc.getDebugOverlay().showDebugScreen()) return; // stay out of F3's way

		Font font = mc.font;
		int sw = g.guiWidth();
		int sh = g.guiHeight();
		for (HudWidget w : Widgets.ALL) {
			if (!w.state().enabled || !w.hasContent(mc)) continue;
			w.draw(g, font, mc, w.screenX(font, mc, sw, false), w.screenY(font, mc, sh, false), 1f, false);
		}
	}
}
