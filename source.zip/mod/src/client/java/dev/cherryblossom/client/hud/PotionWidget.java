package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.compat.Compat;
import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.ArrayList;
import java.util.List;

/** Active effects with icon, level and time left. Blinks gently in the last 10 seconds. */
final class PotionWidget extends HudWidget {
	private static final int ROW = 20;
	private static final String[] ROMAN = {"", " II", " III", " IV", " V", " VI", " VII", " VIII", " IX", " X"};
	private List<MobEffectInstance> sample;

	PotionWidget() {
		super("potions", "Potion Effects", "Active effects and how long they last", true, 1f, 0.25f);
	}

	private List<MobEffectInstance> effects(Minecraft mc, boolean preview) {
		List<MobEffectInstance> out = new ArrayList<>();
		if (mc.player != null) out.addAll(mc.player.getActiveEffects());
		if (out.isEmpty() && preview) {
			if (sample == null) sample = List.of(new MobEffectInstance(MobEffects.SPEED, 20 * 95, 1),
					new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 312, 0));
			return sample;
		}
		return out;
	}

	@Override
	public boolean hasContent(Minecraft mc) {
		return mc.player != null && !mc.player.getActiveEffects().isEmpty();
	}

	private static String name(MobEffectInstance e) {
		int amp = e.getAmplifier();
		return e.getEffect().value().getDisplayName().getString() + (amp > 0 && amp < ROMAN.length ? ROMAN[amp] : amp > 0 ? " " + (amp + 1) : "");
	}

	private static String time(MobEffectInstance e) {
		if (e.isInfiniteDuration()) return "∞";
		int s = e.getDuration() / 20;
		return s >= 3600 ? (s / 3600) + "h " + String.format("%02dm", (s / 60) % 60) : (s / 60) + ":" + String.format("%02d", s % 60);
	}

	@Override
	public int width(Font font, Minecraft mc, boolean preview) {
		int w = 0;
		for (MobEffectInstance e : effects(mc, preview)) w = Math.max(w, Math.max(font.width(name(e)), font.width(time(e))));
		return 18 + 4 + Math.max(w, 40) + 4;
	}

	@Override
	public int height(Font font, Minecraft mc, boolean preview) {
		return Math.max(ROW, effects(mc, preview).size() * ROW) - 2;
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Font font, Minecraft mc, float alpha, boolean preview) {
		CherryConfig cfg = CherryConfig.get();
		int y = 0, w = width(font, mc, preview);
		for (MobEffectInstance e : effects(mc, preview)) {
			if (cfg.background) Theme.rounded(g, 0, y, w, y + ROW - 2, Theme.withAlpha(Theme.WIDGET_BG, alpha));
			float a = alpha;
			if (!e.isInfiniteDuration() && e.getDuration() < 200) {
				a *= 0.55f + 0.45f * (float) Math.abs(Math.sin(System.currentTimeMillis() / 250.0));
			}
			g.blitSprite(RenderPipelines.GUI_TEXTURED, Compat.effectSprite(e.getEffect()), 1, y, 18, 18);
			g.text(font, name(e), 22, y + 1, Theme.withAlpha(Theme.accent(), a), cfg.textShadow);
			g.text(font, time(e), 22, y + 10, Theme.withAlpha(Theme.TEXT_DIM, a), cfg.textShadow);
			y += ROW;
		}
	}
}
