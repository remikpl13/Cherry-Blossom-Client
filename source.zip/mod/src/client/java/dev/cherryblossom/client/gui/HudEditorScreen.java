package dev.cherryblossom.client.gui;

import dev.cherryblossom.client.compat.Compat;
import com.mojang.blaze3d.platform.InputConstants;
import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.hud.HudWidget;
import dev.cherryblossom.client.hud.Widgets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Drag widgets anywhere. Snaps to the centre lines and to other widgets,
 * scroll to resize, right-click to hide, R to reset, Esc to save.
 */
public final class HudEditorScreen extends Screen {
	private static final int SNAP = 4;

	private final Screen parent;
	private final long openedAt = System.nanoTime();
	private long lastFrame = System.nanoTime();
	private final Map<HudWidget, Float> hover = new HashMap<>();

	private HudWidget dragging;
	private double grabX, grabY;
	private Integer guideX, guideY;
	private boolean doneHovered;
	private float doneHover;

	public HudEditorScreen(Screen parent) {
		super(Component.literal("Edit HUD Layout"));
		this.parent = parent;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		// The game stays visible and unblurred while you arrange things.
	}

	private float secondsOpen() {
		return (System.nanoTime() - openedAt) / 1_000_000_000f;
	}

	private int x(HudWidget w) { return w.screenX(font, minecraft, width, true); }

	private int y(HudWidget w) { return w.screenY(font, minecraft, height, true); }

	private int w(HudWidget w) { return w.scaledWidth(font, minecraft, true); }

	private int h(HudWidget w) { return w.scaledHeight(font, minecraft, true); }

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
		lastFrame = now;
		float appear = Theme.easeOut(secondsOpen() / 0.25f);

		if (dragging != null) {
			if (guideX != null) g.fill(guideX, 0, guideX + 1, height, Theme.withAlpha(Theme.accent(), 0.7f));
			if (guideY != null) g.fill(0, guideY, width, guideY + 1, Theme.withAlpha(Theme.accent(), 0.7f));
		}

		HudWidget hovered = dragging != null ? dragging : widgetAt(mouseX, mouseY);
		for (HudWidget w : Widgets.ALL) {
			if (!w.state().enabled) continue;
			int x = x(w), y = y(w), ww = w(w), hh = h(w);
			float h = Theme.approach(hover.getOrDefault(w, 0f), w == hovered ? 1f : 0f, 18f, dt);
			hover.put(w, h);

			int outline = Theme.mix(Theme.withAlpha(0xFFFFFFFF, 0.25f), Theme.accent(), h);
			g.outline(x - 2, y - 2, ww + 4, hh + 4, Theme.withAlpha(outline, appear));
			w.draw(g, font, minecraft, x, y, appear, true);

			if (h > 0.05f) {
				String tag = w.name + "  " + Math.round(w.state().scale * 100) + "%";
				int ty = y + hh + 5 + font.lineHeight > height ? y - font.lineHeight - 4 : y + hh + 4;
				int tx = Math.min(x, width - font.width(tag) - 2);
				g.text(font, tag, tx, ty, Theme.withAlpha(Theme.TEXT_DIM, h * appear), true);
			}
		}

		drawHints(g, mouseX, mouseY, appear, dt);
		super.extractRenderState(g, mouseX, mouseY, delta);
	}

	private void drawHints(GuiGraphicsExtractor g, int mouseX, int mouseY, float appear, float dt) {
		String hint = "Drag to move  ·  Scroll to resize  ·  Right-click to hide  ·  R to reset  ·  Esc to save";
		if (font.width(hint) + 16 > width) hint = "Drag · Scroll to resize · Right-click hide · Esc";
		int hw = font.width(hint) + 16;
		int hx = (width - hw) / 2;
		int hy = height - 30 + Math.round((1 - appear) * 8);
		Theme.rounded(g, hx, hy, hx + hw, hy + 16, Theme.withAlpha(Theme.PANEL, appear));
		g.centeredText(font, hint, width / 2, hy + 4, Theme.withAlpha(Theme.TEXT_DIM, appear));

		int bw = 60, bh = 16, bx = (width - bw) / 2, by = 10 - Math.round((1 - appear) * 8);
		doneHovered = mouseX >= bx && mouseX < bx + bw && mouseY >= by && mouseY < by + bh;
		doneHover = Theme.approach(doneHover, doneHovered ? 1f : 0f, 18f, dt);
		int fill = Theme.mix(Theme.PANEL_RAISED, Theme.accent(), 0.25f + 0.75f * doneHover);
		Theme.rounded(g, bx, by, bx + bw, by + bh, Theme.withAlpha(fill, appear));
		int textColor = Theme.mix(Theme.TEXT, 0xFF2A1520, doneHover);
		g.centeredText(font, "Done", width / 2, by + 4, Theme.withAlpha(textColor, appear));
	}

	private HudWidget widgetAt(double mx, double my) {
		for (int i = Widgets.ALL.size() - 1; i >= 0; i--) {
			HudWidget w = Widgets.ALL.get(i);
			if (!w.state().enabled) continue;
			int x = x(w), y = y(w);
			if (mx >= x - 2 && mx < x + w(w) + 2 && my >= y - 2 && my < y + h(w) + 2) return w;
		}
		return null;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
		if (e.button() == InputConstants.MOUSE_BUTTON_LEFT) {
			if (doneHovered) {
				onClose();
				return true;
			}
			HudWidget w = widgetAt(e.x(), e.y());
			if (w != null) {
				dragging = w;
				grabX = e.x() - x(w);
				grabY = e.y() - y(w);
				return true;
			}
		} else if (e.button() == InputConstants.MOUSE_BUTTON_RIGHT) {
			HudWidget w = widgetAt(e.x(), e.y());
			if (w != null) {
				w.state().enabled = false;
				return true;
			}
		}
		return super.mouseClicked(e, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
		if (dragging == null) return super.mouseDragged(e, dx, dy);
		int ww = w(dragging), hh = h(dragging);
		int x = (int) Math.round(e.x() - grabX);
		int y = (int) Math.round(e.y() - grabY);

		guideX = null;
		guideY = null;
		if (Math.abs(x + ww / 2 - width / 2) <= SNAP) { x = width / 2 - ww / 2; guideX = width / 2; }
		if (Math.abs(y + hh / 2 - height / 2) <= SNAP) { y = height / 2 - hh / 2; guideY = height / 2; }
		for (HudWidget o : Widgets.ALL) {
			if (o == dragging || !o.state().enabled) continue;
			int ox = x(o), oy = y(o), ow = w(o), oh = h(o);
			if (guideX == null && Math.abs(x - ox) <= SNAP) { x = ox; guideX = ox; }
			if (guideX == null && Math.abs(x + ww - (ox + ow)) <= SNAP) { x = ox + ow - ww; guideX = ox + ow; }
			if (guideY == null && Math.abs(y - (oy + oh + 2)) <= SNAP) { y = oy + oh + 2; }
			if (guideY == null && Math.abs(y + hh + 2 - oy) <= SNAP) { y = oy - hh - 2; }
		}
		dragging.setScreenPos(font, minecraft, x, y, width, height);
		return true;
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent e) {
		if (dragging != null && e.button() == InputConstants.MOUSE_BUTTON_LEFT) {
			dragging = null;
			guideX = guideY = null;
			return true;
		}
		return super.mouseReleased(e);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double h, double v) {
		HudWidget w = widgetAt(mx, my);
		if (w == null || v == 0) return super.mouseScrolled(mx, my, h, v);
		CherryConfig.WidgetState s = w.state();
		int x = x(w), y = y(w);
		s.scale = Math.round(Math.max(0.5f, Math.min(2f, s.scale + (v > 0 ? 0.1f : -0.1f))) * 10f) / 10f;
		w.setScreenPos(font, minecraft, x, y, width, height);
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent e) {
		if (e.key() == InputConstants.KEY_R) {
			Widgets.ALL.forEach(HudWidget::resetPosition);
			return true;
		}
		return super.keyPressed(e);
	}

	@Override
	public void onClose() {
		CherryConfig.get().save();
		Compat.setScreen(minecraft, parent);
	}
}
