package dev.cherryblossom.client.mixin;

import dev.cherryblossom.client.compat.Compat;
import com.mojang.blaze3d.platform.InputConstants;
import dev.cherryblossom.client.feature.Zoom;
import dev.cherryblossom.client.hud.Stats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Counts clicks for the CPS widgets and lets the scroll wheel adjust zoom. */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
	@Inject(method = "onButton", at = @At("HEAD"))
	private void cherryblossom$countClick(long window, MouseButtonInfo info, int action, CallbackInfo ci) {
		if (action != InputConstants.PRESS || Compat.screen(Minecraft.getInstance()) != null) return;
		if (info.button() == InputConstants.MOUSE_BUTTON_LEFT) Stats.click(true);
		else if (info.button() == InputConstants.MOUSE_BUTTON_RIGHT) Stats.click(false);
	}

	@Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
	private void cherryblossom$zoomScroll(long window, double x, double y, CallbackInfo ci) {
		if (Compat.screen(Minecraft.getInstance()) == null && Zoom.scroll(y)) ci.cancel();
	}
}
