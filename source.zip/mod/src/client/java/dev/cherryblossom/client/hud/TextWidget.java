package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * The classic "LABEL value" pill. Values are recomputed at most 10 times a second,
 * so even a dozen widgets cost next to nothing per frame on slow PCs.
 */
public abstract class TextWidget extends HudWidget {
	public static final int PAD_X = 5;
	public static final int PAD_Y = 3;
	public static final int GAP = 4;
	private static final long REFRESH_NS = 100_000_000L;

	private String cached = "";
	private int cachedColor = Theme.TEXT;
	private long cachedAt;

	protected TextWidget(String id, String name, String about, boolean enabled, float x, float y) {
		super(id, name, about, enabled, x, y);
	}

	public abstract String label();

	/** The live value. */
	protected abstract String compute(Minecraft mc);

	/** A value as wide as the widest we expect, so the pill doesn't wobble as digits change. */
	protected abstract String sizingSample();

	/** Shown in the layout editor when there's no live value yet. */
	protected String previewValue() {
		return sizingSample();
	}

	protected int color(Minecraft mc) {
		return Theme.TEXT;
	}

	private void refresh(Minecraft mc) {
		long now = System.nanoTime();
		if (now - cachedAt < REFRESH_NS && cachedAt != 0) return;
		cachedAt = now;
		String v = compute(mc);
		cached = v == null ? "" : v;
		cachedColor = color(mc);
	}

	protected String value(Minecraft mc, boolean preview) {
		refresh(mc);
		return preview && cached.isEmpty() ? previewValue() : cached;
	}

	@Override
	public boolean hasContent(Minecraft mc) {
		refresh(mc);
		return !cached.isEmpty();
	}

	@Override
	public int width(Font font, Minecraft mc, boolean preview) {
		int valueW = Math.max(font.width(value(mc, preview)), font.width(sizingSample()));
		String label = label();
		return PAD_X * 2 + (label.isEmpty() ? 0 : font.width(label) + GAP) + valueW;
	}

	@Override
	public int height(Font font, Minecraft mc, boolean preview) {
		return font.lineHeight - 1 + PAD_Y * 2;
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Font font, Minecraft mc, float alpha, boolean preview) {
		CherryConfig cfg = CherryConfig.get();
		int w = width(font, mc, preview), h = height(font, mc, preview);
		if (cfg.background) Theme.rounded(g, 0, 0, w, h, Theme.withAlpha(Theme.WIDGET_BG, alpha));
		int x = PAD_X;
		String label = label();
		if (!label.isEmpty()) {
			g.text(font, label, x, PAD_Y, Theme.withAlpha(Theme.accent(), alpha), cfg.textShadow);
			x += font.width(label) + GAP;
		}
		int color = cfg.colorCodedValues ? cachedColor : Theme.TEXT;
		g.text(font, value(mc, preview), x, PAD_Y, Theme.withAlpha(color, alpha), cfg.textShadow);
	}
}
