package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.config.CherryConfig;
import dev.cherryblossom.client.gui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Armour and held item with their durability, so you know when to repair. */
final class ArmorWidget extends HudWidget {
	private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
			EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
	private static final int ROW = 17;
	private List<ItemStack> sample;

	ArmorWidget() {
		super("armor", "Armor Status", "Armour and held item durability", true, 1f, 1f);
	}

	private List<ItemStack> items(Minecraft mc, boolean preview) {
		List<ItemStack> out = new ArrayList<>();
		if (mc.player != null) {
			for (EquipmentSlot s : SLOTS) {
				ItemStack st = mc.player.getItemBySlot(s);
				if (!st.isEmpty()) out.add(st);
			}
		}
		if (out.isEmpty() && preview) {
			if (sample == null) {
				sample = List.of(new ItemStack(Items.DIAMOND_HELMET), new ItemStack(Items.DIAMOND_CHESTPLATE),
						new ItemStack(Items.DIAMOND_SWORD));
			}
			return sample;
		}
		return out;
	}

	@Override
	public boolean hasContent(Minecraft mc) {
		return !items(mc, false).isEmpty();
	}

	private static String label(ItemStack st) {
		if (st.isDamageableItem()) return Integer.toString(st.getMaxDamage() - st.getDamageValue());
		return st.getCount() > 1 ? Integer.toString(st.getCount()) : "";
	}

	@Override
	public int width(Font font, Minecraft mc, boolean preview) {
		int w = 0;
		for (ItemStack st : items(mc, preview)) w = Math.max(w, font.width(label(st)));
		return 16 + (w > 0 ? 4 + w : 0) + 4;
	}

	@Override
	public int height(Font font, Minecraft mc, boolean preview) {
		return Math.max(ROW, items(mc, preview).size() * ROW);
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Font font, Minecraft mc, float alpha, boolean preview) {
		CherryConfig cfg = CherryConfig.get();
		int y = 0;
		for (ItemStack st : items(mc, preview)) {
			g.item(st, 0, y);
			String text = label(st);
			if (!text.isEmpty()) {
				int color = Theme.TEXT;
				if (st.isDamageableItem() && cfg.colorCodedValues) {
					float f = 1f - st.getDamageValue() / (float) Math.max(1, st.getMaxDamage());
					color = f > 0.6f ? Widgets.GOOD : f > 0.25f ? Widgets.OKAY : Widgets.BAD;
				}
				g.text(font, text, 20, y + 4, Theme.withAlpha(color, alpha), cfg.textShadow);
			}
			y += ROW;
		}
	}
}
