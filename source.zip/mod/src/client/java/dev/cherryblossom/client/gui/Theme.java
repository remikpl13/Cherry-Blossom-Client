package dev.cherryblossom.client.gui;

import dev.cherryblossom.client.config.CherryConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Colours and small drawing helpers shared by the HUD and the menus. */
public final class Theme {
	private Theme() {}

	/** Accent presets the player can cycle through in the menu. */
	public enum Accent {
		BLOSSOM("Blossom", 0xFFF7A8C4),
		SAKURA("Sakura", 0xFFFFC4D6),
		ROSE("Rose", 0xFFE8728F),
		LILAC("Lilac", 0xFFC9A7F0);

		public final String label;
		public final int color;

		Accent(String label, int color) {
			this.label = label;
			this.color = color;
		}

		public Accent next() {
			return values()[(ordinal() + 1) % values().length];
		}
	}

	public static final int TEXT = 0xFFF8EEF2;
	public static final int TEXT_DIM = 0xFFB9A3AD;
	public static final int PANEL = 0xF0201419;
	public static final int PANEL_RAISED = 0xFF2B1B22;
	public static final int PANEL_HOVER = 0xFF36232C;
	public static final int LINE = 0x33FFFFFF;
	public static final int WIDGET_BG = 0x8C1C0E15;

	public static int accent() {
		return CherryConfig.get().accent.color;
	}

	public static int withAlpha(int argb, float alpha) {
		int a = Math.round(((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, alpha)));
		return (a << 24) | (argb & 0x00FFFFFF);
	}

	public static int mix(int a, int b, float t) {
		t = Math.max(0f, Math.min(1f, t));
		int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
		int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
		return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
				| ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
	}

	/** A rectangle with softened 1px corners, the closest thing to rounded we get cheaply. */
	public static void rounded(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
		if (x2 - x1 < 3 || y2 - y1 < 3) {
			g.fill(x1, y1, x2, y2, color);
			return;
		}
		g.fill(x1 + 1, y1, x2 - 1, y1 + 1, color);
		g.fill(x1, y1 + 1, x2, y2 - 1, color);
		g.fill(x1 + 1, y2 - 1, x2 - 1, y2, color);
	}

	/** Smooth ease-out used by every animation in the client. */
	public static float easeOut(float t) {
		t = Math.max(0f, Math.min(1f, t));
		float inv = 1f - t;
		return 1f - inv * inv * inv;
	}

	/** Frame-rate independent approach towards a target value. */
	public static float approach(float current, float target, float speedPerSecond, float dtSeconds) {
		float k = 1f - (float) Math.exp(-speedPerSecond * dtSeconds);
		return current + (target - current) * k;
	}
}
