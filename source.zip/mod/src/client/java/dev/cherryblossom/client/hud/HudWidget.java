package dev.cherryblossom.client.hud;

import dev.cherryblossom.client.config.CherryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * One movable element on the HUD. Handles position, scale and fading;
 * subclasses only say how big they are and how to draw themselves.
 */
public abstract class HudWidget {
	/** Gap kept between widgets and the screen edge. */
	public static final int MARGIN = 3;

	public final String id;
	public final String name;
	public final String about;
	private final CherryConfig.WidgetState defaults;

	protected HudWidget(String id, String name, String about, boolean enabled, float x, float y) {
		this.id = id;
		this.name = name;
		this.about = about;
		this.defaults = new CherryConfig.WidgetState(enabled, x, y);
	}

	/** Size in unscaled GUI pixels. {@code preview} is true inside the layout editor. */
	public abstract int width(Font font, Minecraft mc, boolean preview);

	public abstract int height(Font font, Minecraft mc, boolean preview);

	/** Draw at (0,0); position, scale and fade are already applied. */
	protected abstract void render(GuiGraphicsExtractor g, Font font, Minecraft mc, float alpha, boolean preview);

	/** Some widgets (potions, sprint) only show when there's something to show. */
	public boolean hasContent(Minecraft mc) {
		return true;
	}

	public CherryConfig.WidgetState state() {
		return CherryConfig.get().widget(id, new CherryConfig.WidgetState(defaults.enabled, defaults.x, defaults.y));
	}

	public void resetPosition() {
		CherryConfig.WidgetState s = state();
		s.x = defaults.x;
		s.y = defaults.y;
		s.scale = 1f;
	}

	public int scaledWidth(Font font, Minecraft mc, boolean preview) {
		return Math.round(width(font, mc, preview) * state().scale);
	}

	public int scaledHeight(Font font, Minecraft mc, boolean preview) {
		return Math.round(height(font, mc, preview) * state().scale);
	}

	/** Top-left position in GUI pixels. Stored as fractions of free space so layouts survive resizing. */
	public int screenX(Font font, Minecraft mc, int screenW, boolean preview) {
		int w = scaledWidth(font, mc, preview);
		return MARGIN + Math.round(state().x * Math.max(0, screenW - w - MARGIN * 2));
	}

	public int screenY(Font font, Minecraft mc, int screenH, boolean preview) {
		int h = scaledHeight(font, mc, preview);
		return MARGIN + Math.round(state().y * Math.max(0, screenH - h - MARGIN * 2));
	}

	public void setScreenPos(Font font, Minecraft mc, int px, int py, int screenW, int screenH) {
		CherryConfig.WidgetState s = state();
		float freeW = screenW - scaledWidth(font, mc, true) - MARGIN * 2;
		float freeH = screenH - scaledHeight(font, mc, true) - MARGIN * 2;
		s.x = freeW <= 0 ? 0 : Math.max(0f, Math.min(1f, (px - MARGIN) / freeW));
		s.y = freeH <= 0 ? 0 : Math.max(0f, Math.min(1f, (py - MARGIN) / freeH));
	}

	public void draw(GuiGraphicsExtractor g, Font font, Minecraft mc, int x, int y, float alpha, boolean preview) {
		float scale = state().scale;
		g.pose().pushMatrix();
		g.pose().translate(x, y);
		if (scale != 1f) g.pose().scale(scale, scale);
		render(g, font, mc, alpha, preview);
		g.pose().popMatrix();
	}
}
