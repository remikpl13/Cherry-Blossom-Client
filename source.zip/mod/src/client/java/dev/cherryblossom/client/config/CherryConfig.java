package dev.cherryblossom.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.cherryblossom.CherryBlossom;
import dev.cherryblossom.client.gui.Theme;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;

/** Small JSON config stored in .minecraft/config/cherryblossom.json. */
public final class CherryConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cherryblossom.json");
	private static CherryConfig instance;

	/** Where a widget sits. x/y are fractions of the free screen space so layouts survive resolution changes. */
	public static final class WidgetState {
		public boolean enabled = true;
		public float x;
		public float y;
		public float scale = 1f;

		public WidgetState() {}

		public WidgetState(boolean enabled, float x, float y) {
			this.enabled = enabled;
			this.x = x;
			this.y = y;
		}
	}

	public Map<String, WidgetState> widgets = new LinkedHashMap<>();
	public boolean background = true;
	public boolean textShadow = true;
	public boolean colorCodedValues = true;
	public Theme.Accent accent = Theme.Accent.BLOSSOM;
	public boolean clock24h = true;
	public boolean zoomSmoothCamera = true;
	public boolean zoomScroll = true;
	public float zoomFactor = 4f;
	public boolean hideVanillaEffects = true;
	public boolean cherryTitleScreen = true;

	public static CherryConfig get() {
		if (instance == null) load();
		return instance;
	}

	public WidgetState widget(String id, WidgetState defaults) {
		return widgets.computeIfAbsent(id, k -> defaults);
	}

	public static void load() {
		CherryConfig loaded = null;
		if (Files.exists(FILE)) {
			try (Reader r = Files.newBufferedReader(FILE)) {
				loaded = GSON.fromJson(r, CherryConfig.class);
			} catch (Exception e) {
				CherryBlossom.LOG.warn("Could not read {}, using defaults", FILE, e);
			}
		}
		if (loaded == null) loaded = new CherryConfig();
		if (loaded.widgets == null) loaded.widgets = new LinkedHashMap<>();
		if (loaded.accent == null) loaded.accent = Theme.Accent.BLOSSOM;
		if (loaded.zoomFactor < 1.5f || loaded.zoomFactor > 30f) loaded.zoomFactor = 4f;
		instance = loaded;
	}

	public void save() {
		try {
			Files.createDirectories(FILE.getParent());
			Path tmp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
			try (Writer w = Files.newBufferedWriter(tmp)) {
				GSON.toJson(this, w);
			}
			Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
		} catch (Exception e) {
			CherryBlossom.LOG.warn("Could not save {}", FILE, e);
		}
	}
}
