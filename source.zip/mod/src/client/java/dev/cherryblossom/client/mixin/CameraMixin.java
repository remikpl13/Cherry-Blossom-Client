package dev.cherryblossom.client.mixin;

import dev.cherryblossom.client.feature.Zoom;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies the zoom to the world field of view (not the hand). */
@Mixin(Camera.class)
public abstract class CameraMixin {
	@Inject(method = "calculateFov", at = @At("RETURN"), cancellable = true)
	private void cherryblossom$zoom(float partialTick, CallbackInfoReturnable<Float> cir) {
		cir.setReturnValue(Zoom.apply(cir.getReturnValueF()));
	}
}
