package dev.cherryblossom;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class CherryBlossom implements ModInitializer {
	public static final String MOD_ID = "cherryblossom";
	public static final Logger LOG = LoggerFactory.getLogger("Cherry Blossom");

	@Override
	public void onInitialize() {
		LOG.info("Cherry Blossom Client loaded");
	}
}
