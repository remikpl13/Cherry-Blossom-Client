package dev.cherryblossom.client.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;

/** The few calls that differ between Minecraft versions. Each version family has its own copy of this file. */
public final class Compat {
	private Compat() {}

	public static Screen screen(Minecraft mc) {
		return mc.gui.screen();
	}

	public static void setScreen(Minecraft mc, Screen s) {
		mc.gui.setScreen(s);
	}

	public static Identifier effectSprite(Holder<MobEffect> effect) {
		return Hud.getMobEffectSprite(effect);
	}

	public static Screen optionsScreen(Screen parent, Minecraft mc) {
		return new net.minecraft.client.gui.screens.options.OptionsScreen(parent, mc.options, false);
	}
}
