#!/bin/bash
# buildhud121.sh <mc_version> <fabric_api_version> : build the 1.21.x port
set -e
V=$1; F=$2
D=/home/claude/cherry/hudbuilds/$V
mkdir -p $D
rm -rf $D/src; cp -r /home/claude/cherry/mod/src /home/claude/cherry/mod/settings.gradle /home/claude/cherry/mod/gradle.properties $D/
cp /home/claude/cherry/mod/variants-build/1.21/build.gradle $D/build.gradle
python3 /home/claude/cherry/port121.py $D/src $3
sed -i "s/^minecraft_version=.*/minecraft_version=$V/; s/^fabric_api_version=.*/fabric_api_version=$F/" $D/gradle.properties
rm -rf $D/build/libs; cd $D && JAVA_HOME=/opt/jdk25 /opt/gradle97/gradle-9.7.1/bin/gradle build --no-daemon -q 2>&1 | grep -v "Picked up" | grep -E "error:|warning: \[|FAIL|What went wrong" -A2 | head -${LINES_OUT:-60}
mkdir -p /home/claude/cherry/hudjars && cp $D/build/libs/cherry-blossom-hud-2.0.0.jar /home/claude/cherry/hudjars/$V.jar && echo "OK $V"
